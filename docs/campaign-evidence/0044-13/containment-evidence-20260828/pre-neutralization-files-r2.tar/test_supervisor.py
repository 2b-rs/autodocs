#!/usr/bin/env python3
"""Tests for supervisor mailbox archiving and session management."""
import argparse
import base64
import fcntl
import hashlib
import http.client
import importlib.util
import io
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import urllib.error
from unittest import mock
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("agent_supervisor", HERE / "supervisor.py")
SUPERVISOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SUPERVISOR)


class SupervisorArchiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.config = root / "config"
        self.store = root / "store"
        self.archive = root / "archive"
        self.state = root / "state"
        self.workspace = root / "workspace"
        self.config.mkdir()
        self.workspace.mkdir()
        shutil.copy2(HERE / "agents.json", self.config / "agents.json")
        self.args = argparse.Namespace(
            inbox=self.config, store=self.store, archive_dir=self.archive,
            state_dir=self.state, workspace=self.workspace, agent=None,
            wake_broadcasts=False, allow_integrators=False, max_parallel=1,
            cooldown=1, max_backoff=10, interval=1, replace_running=False,
            codex_profiles=root / "codex", claude_profiles=root / "claude",
            agy_profiles=root / "agy", cursor_profiles=root / "cursor", grok_profiles=root / "grok", check=False,
        )

    def configure_agent(self, name, **updates):
        path = self.config / "agents.json"
        roster = json.loads(path.read_text())
        roster["agents"][name].update(updates)
        path.write_text(json.dumps(roster))

    def tearDown(self):
        self.tmp.cleanup()

    @staticmethod
    def message(message_id, day, recipient="data"):
        return {"id": message_id, "ts": f"{day}T12:00:00Z", "sender": "picard",
                "to": recipient, "subject": "s", "body": message_id, "thread": ""}

    def write_lines(self, path, records):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("".join(json.dumps(record) + "\n" for record in records))

    def test_archive_is_complete_deduplicated_and_daily(self):
        first = self.message("1700000000000-00000001", "2026-08-20", "DATA")
        second = self.message("1700000000001-00000002", "2026-08-21")
        self.write_lines(self.store / "data/messages.jsonl", [first, second])
        self.write_lines(self.config / "data/messages.jsonl", [first])
        supervisor = SUPERVISOR.Supervisor(self.args)
        self.assertEqual(supervisor.archive_messages(), 2)
        self.assertEqual(supervisor.archive_messages(), 0)
        day_one = (self.archive / "messages-2026-08-20.jsonl").read_text().splitlines()
        day_two = (self.archive / "messages-2026-08-21.jsonl").read_text().splitlines()
        self.assertEqual([json.loads(line)["id"] for line in day_one], [first["id"]])
        self.assertEqual([json.loads(line)["id"] for line in day_two], [second["id"]])
        self.assertEqual(self.archive.stat().st_mode & 0o777, 0o700)
        self.assertEqual((self.archive / "messages-2026-08-21.jsonl").stat().st_mode & 0o600, 0o600)

    def test_archive_still_reaches_messages_pruned_out_of_the_live_log(self):
        pruned = self.message("1700000000002-00000004", "2026-08-22")
        self.write_lines(self.store / "data/messages.archive.jsonl", [pruned])
        supervisor = SUPERVISOR.Supervisor(self.args)
        self.assertEqual(supervisor.archive_messages(), 1)
        self.assertEqual(supervisor.archive_messages(), 0)
        day = (self.archive / "messages-2026-08-22.jsonl").read_text().splitlines()
        self.assertEqual([json.loads(line)["id"] for line in day], [pruned["id"]])

    def test_case_insensitive_ack_state_suppresses_wake(self):
        record = self.message("1700000000000-00000003", "2026-08-21", "Data")
        self.write_lines(self.store / "data/messages.jsonl", [record])
        read = self.config / "data/read/Data.json"
        read.parent.mkdir(parents=True)
        read.write_text(json.dumps({"agent": "DATA", "acked": [record["id"]]}))
        supervisor = SUPERVISOR.Supervisor(self.args)
        self.assertEqual(supervisor.unread("data"), [])

    def test_roster_case_collision_fails_closed(self):
        path = self.config / "agents.json"
        roster = json.loads(path.read_text())
        roster["agents"]["Data"] = dict(roster["agents"]["data"])
        path.write_text(json.dumps(roster))
        with self.assertRaisesRegex(RuntimeError, "case-insensitive (roster )?collision"):
            SUPERVISOR.Supervisor(self.args)


class SupervisorNativeSessionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.config = root / "config"
        self.store = root / "store"
        self.archive = root / "archive"
        self.state = root / "state"
        self.workspace = root / "workspace"
        self.config.mkdir()
        self.workspace.mkdir()
        shutil.copy2(HERE / "agents.json", self.config / "agents.json")
        self.args = argparse.Namespace(
            inbox=self.config, store=self.store, archive_dir=self.archive,
            state_dir=self.state, workspace=self.workspace, agent=None,
            wake_broadcasts=False, allow_integrators=False, max_parallel=1,
            cooldown=1, max_backoff=10, interval=1, replace_running=False,
            codex_profiles=root / "codex", claude_profiles=root / "claude",
            agy_profiles=root / "agy", cursor_profiles=root / "cursor", grok_profiles=root / "grok", check=False,
        )

    def configure_agent(self, name, **updates):
        path = self.config / "agents.json"
        roster = json.loads(path.read_text())
        roster["agents"][name].update(updates)
        path.write_text(json.dumps(roster))

    def tearDown(self):
        self.tmp.cleanup()

    def supervisor(self):
        return SUPERVISOR.Supervisor(self.args)

    def test_pending_priority_offers_tracks_only_active_unresolved_tier(self):
        events = [
            {"event": "created", "offer_id": "offer-old",
             "priority_groups": [
                 {"priority": 1, "agents": ["data"]},
                 {"priority": 2, "agents": ["geordi"]},
             ]},
            {"event": "activated", "offer_id": "offer-old", "priority": 1},
            {"event": "expired", "offer_id": "offer-old", "agent": "data"},
            {"event": "activated", "offer_id": "offer-old", "priority": 2},
            {"event": "created", "offer_id": "offer-live",
             "priority_groups": [
                 {"priority": 1, "agents": ["DATA", "tom"]},
             ]},
            {"event": "activated", "offer_id": "offer-live", "priority": 1},
            {"event": "declined", "offer_id": "offer-live", "agent": "tom"},
        ]
        path = self.store / "data/offers.jsonl"
        path.parent.mkdir(parents=True)
        path.write_text("".join(json.dumps(event) + "\n" for event in events))
        self.assertEqual(self.supervisor().pending_priority_offers(), {
            "geordi": ["offer-old"], "data": ["offer-live"],
        })

    def test_offer_command_uses_fresh_context_instead_of_resuming_agent(self):
        supervisor = self.supervisor()
        supervisor.agent_state("jadzia")["conversation_id"] = "old-conversation"
        command = supervisor.offer_command(
            "jadzia", supervisor.agents["jadzia"], "agy", "decide")
        self.assertIn("--agent", command)
        self.assertIn("jadzia", command)
        self.assertNotIn("--conversation", command)
        self.assertNotIn("old-conversation", command)

    def test_offer_prompt_is_bounded_to_exact_decision_call(self):
        prompt = SUPERVISOR.Supervisor.offer_wake_prompt(
            "jadzia", "OFFER offer-1\nContract:\ncoordinate")
        self.assertIn("decision='accept'", prompt)
        self.assertIn("Do not call inbox", prompt)
        self.assertIn("end this turn", prompt)

    def test_offer_turn_can_launch_while_normal_agent_process_is_running(self):
        supervisor = self.supervisor()
        supervisor.processes["jadzia"] = {"normal": True}
        process = mock.Mock(pid=4321)
        with mock.patch.object(
                supervisor, "_run_inbox_tool",
                return_value="1 actionable priority offer(s)\nOFFER offer-1"), \
                mock.patch.object(supervisor, "offer_command", return_value=["agy"]), \
                mock.patch.object(supervisor, "git_identity_environment", return_value={}), \
                mock.patch.object(SUPERVISOR.subprocess, "Popen", return_value=process):
            self.assertTrue(supervisor.launch_offer(
                "jadzia", supervisor.agents["jadzia"], "agy", ["offer-1"]))
        self.assertIn("jadzia", supervisor.offer_processes)
        supervisor.offer_processes["jadzia"]["log"].close()

    def test_resolved_offer_stops_only_isolated_offer_process(self):
        supervisor = self.supervisor()
        process = mock.Mock(pid=4321)
        supervisor.offer_processes["jadzia"] = {
            "process": process, "log": mock.Mock(), "offer_ids": ["offer-1"],
        }
        supervisor.processes["jadzia"] = {"normal": True}
        with mock.patch.object(SUPERVISOR.os, "killpg") as killpg:
            supervisor.stop_resolved_offer_processes({})
        killpg.assert_called_once_with(4321, SUPERVISOR.signal.SIGTERM)
        self.assertIn("jadzia", supervisor.processes)

    def test_resolved_offer_escalates_to_kill_after_two_seconds(self):
        supervisor = self.supervisor()
        process = mock.Mock(pid=4321)
        process.poll.return_value = None
        supervisor.offer_processes["jadzia"] = {
            "process": process, "log": mock.Mock(), "offer_ids": ["offer-1"],
            "termination_requested": 100.0,
        }
        with mock.patch.object(SUPERVISOR.time, "time", return_value=102.0), \
                mock.patch.object(SUPERVISOR.os, "killpg") as killpg:
            supervisor.stop_resolved_offer_processes({})
        killpg.assert_called_once_with(4321, SUPERVISOR.signal.SIGKILL)

    def test_codex_chat_resumes_supervisor_thread_natively(self):
        self.configure_agent("data", provider="codex")
        supervisor = self.supervisor()
        supervisor.agent_state("data")["thread_id"] = "11111111-1111-1111-1111-111111111111"
        with mock.patch.object(supervisor, "runtime", return_value="codex"):
            name, command = supervisor.chat_command("DATA")
        self.assertEqual(name, "data")
        self.assertEqual(command[:3], ["codex", "--profile", "data"])
        self.assertIn("--dangerously-bypass-approvals-and-sandbox", command)
        self.assertIn("resume", command)
        self.assertIn("--include-non-interactive", command)
        self.assertEqual(command[-1], "11111111-1111-1111-1111-111111111111")

    def test_claude_chat_resumes_supervisor_session_natively(self):
        self.configure_agent("tom", provider="claude")
        supervisor = self.supervisor()
        supervisor.agent_state("tom").update(
            session_id="22222222-2222-2222-2222-222222222222",
            claude_initialized=True,
        )
        with mock.patch.object(supervisor, "runtime", return_value="claude"):
            name, command = supervisor.chat_command("TOM")
        self.assertEqual(name, "tom")
        self.assertEqual(command[0], "claude")
        self.assertIn("--dangerously-skip-permissions", command)
        self.assertIn("--resume", command)
        self.assertIn("22222222-2222-2222-2222-222222222222", command)
        self.assertNotIn("-p", command)
        self.assertNotIn("--output-format", command)

    def test_claude_persisted_session_repairs_lost_initialized_flag(self):
        self.configure_agent("tom", provider="claude")
        supervisor = self.supervisor()
        session_id = "22222222-2222-2222-2222-222222222222"
        session_file = (
            self.args.claude_profiles.parent / "projects" / "workspace" /
            f"{session_id}.jsonl"
        )
        session_file.parent.mkdir(parents=True)
        session_file.write_text('{"type":"agent-name","agentName":"tom"}\n')
        supervisor.agent_state("tom")["session_id"] = session_id

        command = supervisor.command(
            "tom", supervisor.agents["tom"], "claude", "wake")

        self.assertIn("--resume", command)
        self.assertNotIn("--session-id", command)
        self.assertTrue(supervisor.agent_state("tom")["claude_initialized"])

    def test_claude_session_recovery_clears_session_conflict_backoff(self):
        supervisor = self.supervisor()
        session_id = "22222222-2222-2222-2222-222222222222"
        session_file = (
            self.args.claude_profiles.parent / "projects" / "workspace" /
            f"{session_id}.jsonl"
        )
        session_file.parent.mkdir(parents=True)
        session_file.write_text("persisted\n")
        conflict_log = Path(self.tmp.name) / "conflict.log"
        conflict_log.write_text(f"Error: Session ID {session_id} is already in use.\n")
        state = supervisor.agent_state("tom")
        state.update(
            session_id=session_id, attempts=7, next_wake=9999,
            wake_outcome="error", wake_backoff_index=6,
            last_log=str(conflict_log),
        )

        self.assertTrue(supervisor.recover_claude_session("tom"))
        self.assertEqual(state["attempts"], 0)
        self.assertEqual(state["next_wake"], 0)
        self.assertNotIn("wake_backoff_index", state)

    def test_chat_starts_fresh_interactive_session_when_no_resumable_thread(self):
        self.configure_agent("data", provider="codex")
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "runtime", return_value="codex"):
            name, command = supervisor.chat_command("data")
        self.assertEqual(name, "data")
        self.assertEqual(command, [
            "codex", "--profile", "data",
            "--dangerously-bypass-approvals-and-sandbox",
            "-C", str(self.workspace.resolve()),
        ])

    def test_profile_is_reloaded_once_per_supervisor_generation_while_sessions_resume(self):
        supervisor = self.supervisor()
        supervisor.begin_profile_generation("run")

        supervisor.agent_state("data")["thread_id"] = "codex-thread"
        codex = supervisor.command("data", supervisor.agents["data"], "codex", "wake")
        self.assertEqual(codex[:3], ["codex", "--profile", "data"])
        self.assertIn("resume", codex)
        supervisor.mark_profile_applied("data")
        codex = supervisor.command("data", supervisor.agents["data"], "codex", "wake")
        self.assertEqual(codex[0], "codex")
        self.assertIn("--dangerously-bypass-approvals-and-sandbox", codex)
        self.assertIn("exec", codex)
        self.assertIn("resume", codex)
        self.assertNotIn("--profile", codex)

        supervisor.agent_state("tom").update(session_id="claude-session", claude_initialized=True)
        claude = supervisor.command("tom", supervisor.agents["tom"], "claude", "wake")
        self.assertIn("--resume", claude)
        self.assertIn("--agent", claude)
        supervisor.mark_profile_applied("tom")
        claude = supervisor.command("tom", supervisor.agents["tom"], "claude", "wake")
        self.assertIn("--resume", claude)
        self.assertNotIn("--agent", claude)

        supervisor.agent_state("worf")["conversation_id"] = "agy-conversation"
        agy = supervisor.command("worf", supervisor.agents["worf"], "agy", "wake")
        self.assertNotIn("--conversation", agy)
        self.assertIn("--agent", agy)
        self.assertNotIn("conversation_id", supervisor.agent_state("worf"))
        supervisor.agent_state("worf")["conversation_id"] = "agy-conversation-new"
        supervisor.mark_profile_applied("worf")
        agy = supervisor.command("worf", supervisor.agents["worf"], "agy", "wake")
        self.assertIn("--conversation", agy)
        self.assertIn("agy-conversation-new", agy)
        self.assertNotIn("--agent", agy)

        supervisor.agent_state("michael")["cursor_session_id"] = "cursor-session"
        cursor = supervisor.command(
            "michael", supervisor.agents["michael"], "cursor", "wake")
        self.assertIn("--resume", cursor)
        self.assertNotIn("--agent", cursor)
        self.assertTrue(SUPERVISOR.command_loads_profile("cursor", cursor))
        supervisor.mark_profile_applied("michael")
        cursor = supervisor.command(
            "michael", supervisor.agents["michael"], "cursor", "wake")
        self.assertIn("--resume", cursor)
        self.assertNotIn("--agent", cursor)

        supervisor.agent_state("leahcim")["grok_session_id"] = "grok-session"
        grok = supervisor.command(
            "leahcim", supervisor.agents["leahcim"], "grok", "wake")
        self.assertIn("--resume", grok)
        self.assertIn("--agent", grok)
        self.assertTrue(SUPERVISOR.command_loads_profile("grok", grok))
        supervisor.mark_profile_applied("leahcim")
        grok = supervisor.command(
            "leahcim", supervisor.agents["leahcim"], "grok", "wake")
        self.assertIn("--resume", grok)
        self.assertNotIn("--agent", grok)

        supervisor.begin_profile_generation("reload")
        self.assertIn("--profile", supervisor.command(
            "data", supervisor.agents["data"], "codex", "wake"))
        self.assertIn("--agent", supervisor.command(
            "tom", supervisor.agents["tom"], "claude", "wake"))
        agy_refresh = supervisor.command(
            "worf", supervisor.agents["worf"], "agy", "wake")
        self.assertIn("--agent", agy_refresh)
        self.assertNotIn("--conversation", agy_refresh)
        self.assertNotIn("--agent", supervisor.command(
            "michael", supervisor.agents["michael"], "cursor", "wake"))
        self.assertIn("--agent", supervisor.command(
            "leahcim", supervisor.agents["leahcim"], "grok", "wake"))

        stale_generation = SUPERVISOR.profile_generation(self.state)
        supervisor.begin_profile_generation("concurrent-reload")
        supervisor.mark_profile_applied("data", stale_generation)
        self.assertTrue(supervisor.profile_refresh_required("data"))

    def test_permission_bypass_defaults_to_non_sandboxed_agents_and_is_provider_specific(self):
        supervisor = self.supervisor()
        codex = supervisor.command("data", supervisor.agents["data"], "codex", "wake")
        claude = supervisor.command("tom", supervisor.agents["tom"], "claude", "wake")
        agy = supervisor.command("jake", supervisor.agents["jake"], "agy", "wake")
        cursor = supervisor.command("michael", supervisor.agents["michael"], "cursor", "wake")
        grok = supervisor.command("leahcim", supervisor.agents["leahcim"], "grok", "wake")
        self.assertIn("--dangerously-bypass-approvals-and-sandbox", codex)
        self.assertIn("--dangerously-skip-permissions", claude)
        self.assertIn("--dangerously-skip-permissions", agy)
        self.assertEqual(agy[agy.index("--mode") + 1], "accept-edits")
        self.assertIn("--force", cursor)
        self.assertIn("--always-approve", grok)

        sandboxed_config = dict(supervisor.agents["odo"])
        sandboxed_config["capability_class"] = "sandboxed-grunt"
        odo = supervisor.command("odo", sandboxed_config, "agy", "wake")
        self.assertNotIn("--dangerously-skip-permissions", odo)
        self.assertNotIn("--mode", odo)

        self.args.dangerously_skip_permissions = True
        codex = supervisor.command("data", supervisor.agents["data"], "codex", "wake")
        claude = supervisor.command("tom", supervisor.agents["tom"], "claude", "wake")
        agy = supervisor.command("jake", supervisor.agents["jake"], "agy", "wake")
        cursor = supervisor.command("michael", supervisor.agents["michael"], "cursor", "wake")
        grok = supervisor.command("leahcim", supervisor.agents["leahcim"], "grok", "wake")
        self.assertIn("--dangerously-bypass-approvals-and-sandbox", codex)
        self.assertIn("--dangerously-skip-permissions", claude)
        self.assertIn("--dangerously-skip-permissions", agy)
        self.assertEqual(agy[agy.index("--mode") + 1], "accept-edits")
        self.assertNotIn("--sandbox", agy)
        self.assertNotIn("--mode", claude)
        self.assertIn("--force", cursor)
        self.assertIn("--always-approve", grok)
        self.assertEqual(agy[-1], "-p=wake")

        default = SUPERVISOR.build_parser().parse_args(["restart"])
        opted_in = SUPERVISOR.build_parser().parse_args([
            "restart", "--dangerously-skip-permissions",
        ])
        yolo = SUPERVISOR.build_parser().parse_args(["restart", "--yolo"])
        self.assertFalse(default.dangerously_skip_permissions)
        self.assertTrue(opted_in.dangerously_skip_permissions)
        self.assertTrue(yolo.dangerously_skip_permissions)

    def test_codex_chat_recovers_missing_thread_id_from_mixed_runtime_log(self):
        self.configure_agent("data", provider="codex")
        supervisor = self.supervisor()
        log_path = Path(self.tmp.name) / "data.jsonl"
        log_path.write_text(
            "Reading additional input from stdin...\n"
            "not json either\n"
            '{"type":"thread.started","thread_id":"44444444-4444-4444-4444-444444444444"}\n'
        )
        supervisor.agent_state("data")["last_log"] = str(log_path)
        with mock.patch.object(supervisor, "runtime", return_value="codex"):
            name, command = supervisor.chat_command("data")
        self.assertEqual(name, "data")
        self.assertEqual(command[-1], "44444444-4444-4444-4444-444444444444")
        self.assertEqual(
            supervisor.agent_state("data")["thread_id"],
            "44444444-4444-4444-4444-444444444444",
        )

    def test_codex_rollout_rotation_thresholds(self):
        root = self.args.codex_profiles / "sessions" / "2026" / "08" / "23"
        root.mkdir(parents=True)
        current = root / "rollout-2026-08-23T00-00-00-thread.jsonl"
        with open(current, "wb") as rollout:
            rollout.truncate(SUPERVISOR.CODEX_ROLLOUT_MAX_BYTES)
        instant = SUPERVISOR.datetime(2026, 8, 23, 23, 59, tzinfo=SUPERVISOR.timezone.utc)
        self.assertIsNone(SUPERVISOR.codex_rotation_reason(current, instant))
        with open(current, "ab") as rollout:
            rollout.write(b"x")
        self.assertEqual(SUPERVISOR.codex_rotation_reason(current, instant), "size")

        previous = root / "rollout-2026-08-22T23-59-59-other.jsonl"
        previous.write_text("small\n")
        self.assertEqual(
            SUPERVISOR.codex_rotation_reason(previous, instant),
            "utc-midnight",
        )

    def test_codex_rotation_archives_and_starts_next_wake_fresh(self):
        supervisor = self.supervisor()
        thread_id = "44444444-4444-4444-4444-444444444444"
        rollout = (
            self.args.codex_profiles / "sessions" / "2026" / "08" / "22" /
            f"rollout-2026-08-22T23-59-59-{thread_id}.jsonl"
        )
        rollout.parent.mkdir(parents=True)
        rollout.write_text("old thread\n")
        old_log = Path(self.tmp.name) / "old-runtime.jsonl"
        old_log.write_text(json.dumps({
            "type": "thread.started", "thread_id": thread_id,
        }) + "\n")
        supervisor.agent_state("data")["last_log"] = str(old_log)
        instant = SUPERVISOR.datetime(2026, 8, 23, tzinfo=SUPERVISOR.timezone.utc)
        completed = subprocess.CompletedProcess(
            ["codex", "archive", thread_id], 0, stdout="", stderr="")
        with mock.patch.object(SUPERVISOR.subprocess, "run", return_value=completed) as run:
            self.assertTrue(supervisor.rotate_codex_rollout("data", instant))

        run.assert_called_once()
        state = supervisor.agent_state("data")
        self.assertNotIn("thread_id", state)
        self.assertIn(thread_id, state["retired_thread_ids"])
        self.assertEqual(state["codex_rotations"][-1]["reason"], "utc-midnight")
        self.assertIsNone(supervisor.codex_thread_id("data"))
        command = supervisor.command("data", supervisor.agents["data"], "codex", "wake")
        self.assertNotIn("resume", command)

    def test_codex_rotation_leaves_thread_active_when_archive_fails(self):
        supervisor = self.supervisor()
        thread_id = "55555555-5555-5555-5555-555555555555"
        rollout = (
            self.args.codex_profiles / "sessions" / "2026" / "08" / "22" /
            f"rollout-2026-08-22T00-00-00-{thread_id}.jsonl"
        )
        rollout.parent.mkdir(parents=True)
        rollout.write_text("old thread\n")
        supervisor.agent_state("data")["thread_id"] = thread_id
        instant = SUPERVISOR.datetime(2026, 8, 23, tzinfo=SUPERVISOR.timezone.utc)
        failed = subprocess.CompletedProcess(
            ["codex", "archive", thread_id], 2, stdout="", stderr="busy")
        with mock.patch.object(SUPERVISOR.subprocess, "run", return_value=failed):
            self.assertFalse(supervisor.rotate_codex_rollout("data", instant))
        self.assertEqual(supervisor.agent_state("data")["thread_id"], thread_id)

    def test_codex_rotation_waits_for_interactive_agent_lock(self):
        supervisor = self.supervisor()
        thread_id = "66666666-6666-6666-6666-666666666666"
        rollout = (
            self.args.codex_profiles / "sessions" / "2026" / "08" / "22" /
            f"rollout-2026-08-22T00-00-00-{thread_id}.jsonl"
        )
        rollout.parent.mkdir(parents=True)
        rollout.write_text("old thread\n")
        supervisor.agent_state("data")["thread_id"] = thread_id
        agent_lock = SUPERVISOR._try_agent_lock(self.state, "data")
        self.assertIsNotNone(agent_lock)
        instant = SUPERVISOR.datetime(2026, 8, 23, tzinfo=SUPERVISOR.timezone.utc)
        try:
            with mock.patch.object(SUPERVISOR.subprocess, "run") as run:
                self.assertFalse(supervisor.rotate_codex_rollout("data", instant))
            run.assert_not_called()
        finally:
            SUPERVISOR._release_lock(agent_lock)
        self.assertEqual(supervisor.agent_state("data")["thread_id"], thread_id)

    def test_per_agent_locking_allows_concurrent_chat_and_run_for_other_agents(self):
        supervisor = self.supervisor()
        # Acquire agent lock for geordi
        geordi_lock = SUPERVISOR._try_agent_lock(self.state, "geordi")
        self.assertIsNotNone(geordi_lock)

        # Supervisor trying to launch geordi while locked returns False (skips)
        unread = [{"id": "m1", "to": "geordi", "sender": "picard"}]
        with mock.patch.object(supervisor, "runtime", return_value="codex"):
            res = supervisor.launch("geordi", supervisor.agents["geordi"], "codex", unread)
        self.assertFalse(res)

        class DummyProcess:
            def __init__(self, pid):
                self.pid = pid
            def poll(self):
                return 0

        # Supervisor trying to launch data (whose lock is free) succeeds
        unread_data = [{"id": "m2", "to": "data", "sender": "picard"}]
        with mock.patch.object(supervisor, "runtime", return_value="codex"), \
             mock.patch("subprocess.Popen", side_effect=lambda *a, **kw: DummyProcess(9999)):
            res_data = supervisor.launch("data", supervisor.agents["data"], "codex", unread_data)
        self.assertTrue(res_data)
        self.assertIn("data", supervisor.processes)

        # Release geordi lock
        SUPERVISOR._release_lock(geordi_lock)

        # Now launching geordi succeeds
        with mock.patch.object(supervisor, "runtime", return_value="codex"), \
             mock.patch("subprocess.Popen", side_effect=lambda *a, **kw: DummyProcess(9998)):
            res_geordi_after = supervisor.launch("geordi", supervisor.agents["geordi"], "codex", unread)
        self.assertTrue(res_geordi_after)
        self.assertIn("geordi", supervisor.processes)

        supervisor.shutdown()

    def test_format_log_line_renders_clean_human_readable_output(self):
        self.assertIn("thread 123", SUPERVISOR.format_log_line('{"type": "thread.started", "thread_id": "123"}'))
        self.assertIn("$ echo hello", SUPERVISOR.format_log_line('{"type": "item.started", "item": {"type": "command_execution", "command": "echo hello"}}'))
        self.assertIn("Grok reply", SUPERVISOR.format_log_line(
            '{"type":"text","data":"Grok reply"}'))
        self.assertIn("read_file", SUPERVISOR.format_log_line(
            '{"type":"tool_call","toolName":"read_file","rawInput":{"path":"x"}}'))
        self.assertIn("call_mcp_tool", SUPERVISOR.format_log_line(json.dumps({
            "event": "step_update",
            "step_update": {
                "state": "ACTIVE", "step_type": "tool",
                "tool_name": "call_mcp_tool",
                "tool_info": {"parameters": {"ToolName": "inbox"}},
            },
        })))
        agy_result = SUPERVISOR.format_log_line(json.dumps({
            "event": "result",
            "result": {
                "status": "SUCCESS", "response": "DS9 reporting in.",
                "num_turns": 2, "duration_seconds": 3.5,
            },
        }))
        self.assertIn("DS9 reporting in.", agy_result)
        self.assertIn("turn success", agy_result)
        self.assertIn("hello", SUPERVISOR.format_log_line('{"type": "item.completed", "item": {"type": "command_execution", "aggregated_output": "hello\\n", "exit_code": 0}}'))
        self.assertIn("[mcp:agent-inbox] inbox", SUPERVISOR.format_log_line('{"type": "item.started", "item": {"type": "mcp_tool_call", "server": "agent-inbox", "tool": "inbox", "arguments": {}}}'))
        self.assertIn("Review done", SUPERVISOR.format_log_line('{"type": "item.completed", "item": {"type": "agent_message", "text": "Review done"}}'))
        self.assertIn("thinking about fix", SUPERVISOR.format_log_line('{"type": "item.completed", "item": {"type": "reasoning", "text": "thinking about fix"}}'))
        self.assertIn("Claude msg", SUPERVISOR.format_log_line('{"type": "assistant", "message": {"content": [{"type": "text", "text": "Claude msg"}]}}'))
        self.assertEqual("Plain log line", SUPERVISOR.format_log_line("Plain log line"))

        cursor_read = SUPERVISOR.format_log_line(json.dumps({
            "type": "tool_call", "subtype": "started",
            "tool_call": {"readToolCall": {"args": {"path": "/tmp/mailbox.jsonl"}}},
        }))
        self.assertIn("[tool] Read(", cursor_read)
        self.assertIn("/tmp/mailbox.jsonl", cursor_read)
        cursor_done = SUPERVISOR.format_log_line(json.dumps({
            "type": "tool_call", "subtype": "completed",
            "tool_call": {"readToolCall": {
                "args": {"path": "/tmp/mailbox.jsonl"},
                "result": {"success": {"content": "hello mailbox"}},
            }},
        }))
        self.assertIn("hello mailbox", cursor_done)
        cursor_shell = SUPERVISOR.format_log_line(json.dumps({
            "type": "tool_call", "subtype": "started",
            "tool_call": {"shellToolCall": {"args": {
                "command": "git status",
                "toolCallId": "noise",
                "parsingResult": {"executableCommands": []},
            }}},
        }))
        self.assertIn("[tool] Shell(", cursor_shell)
        self.assertIn("git status", cursor_shell)
        self.assertNotIn("parsingResult", cursor_shell)
        self.assertIn("Timed out after 25s", SUPERVISOR.format_log_line(json.dumps({
            "type": "tool_call", "subtype": "completed",
            "tool_call": {"grepToolCall": {
                "result": {"error": {"error": "Timed out after 25s"}},
            }},
        })))

    def test_observe_selection_accepts_lists_plural_s_and_connectives(self):
        target, categories = SUPERVISOR.parse_observe_selection(
            "tools,", ("thoughts", "and", "comms"))
        self.assertIsNone(target)
        self.assertEqual(categories, frozenset(("tool", "thought", "comm")))

        target, categories = SUPERVISOR.parse_observe_selection(
            "Michael", ("mails, broadcasts",))
        self.assertEqual(target, "michael")
        self.assertEqual(categories, frozenset(("mail", "broadcast")))

        self.assertEqual(
            SUPERVISOR.parse_observe_selection("all")[1],
            SUPERVISOR.OBSERVE_CATEGORIES,
        )
        with self.assertRaisesRegex(RuntimeError, "unknown observe selector.*noise"):
            SUPERVISOR.parse_observe_selection("all", ("noise",))

    def test_observe_selection_accepts_name_genitives_and_deppenapostrophes(self):
        names = SUPERVISOR.load_roster(self.config / "agents.json")["agents"]
        for possessive in ("michaels", "michael's", "michael’s"):
            target, categories = SUPERVISOR.parse_observe_selection(
                possessive, ("mail,", "comm's", "and", "thoughts"), names)
            self.assertEqual(target, "michael")
            self.assertEqual(
                categories, frozenset(("mail", "comm", "thought")))

        self.assertEqual(
            SUPERVISOR.parse_observe_selection("kes", (), names)[0],
            "kes",
        )
        self.assertEqual(
            SUPERVISOR.parse_observe_selection("kes'", (), names)[0],
            "kes",
        )

    def test_observe_parser_keeps_agent_scope_and_trailing_filters(self):
        args = SUPERVISOR.build_parser().parse_args([
            "observe", "michael", "tools,", "thoughts", "and", "comms",
        ])
        self.assertEqual(args.target, "michael")
        self.assertEqual(args.observe_filters, ["tools,", "thoughts", "and", "comms"])
        self.assertIn("thought", SUPERVISOR.build_parser().format_help())

    def test_format_log_line_filters_structured_event_categories(self):
        tool = json.dumps({
            "type": "item.started",
            "item": {"type": "command_execution", "command": "echo hello"},
        })
        thought = json.dumps({
            "type": "item.completed",
            "item": {"type": "reasoning", "text": "check the invariant"},
        })
        comm = json.dumps({
            "type": "item.completed",
            "item": {"type": "agent_message", "text": "done"},
        })
        self.assertIn("echo hello", SUPERVISOR.format_log_line(tool, {"tool"}))
        self.assertIsNone(SUPERVISOR.format_log_line(tool, {"thought"}))
        self.assertIn("check the invariant", SUPERVISOR.format_log_line(
            thought, {"thought"}))
        self.assertIsNone(SUPERVISOR.format_log_line(thought, {"comm"}))
        self.assertIn("done", SUPERVISOR.format_log_line(comm, {"comm"}))
        self.assertIsNone(SUPERVISOR.format_log_line(comm, {"tool"}))
        self.assertIsNone(SUPERVISOR.format_log_line("plain diagnostic", {"tool"}))

    def test_provider_thought_events_are_rendered_when_exported(self):
        claude = json.dumps({
            "type": "assistant",
            "message": {"content": [
                {"type": "thinking", "thinking": "consider the race"},
                {"type": "text", "text": "final answer"},
                {"type": "tool_use", "name": "Read", "input": {"path": "x"}},
            ]},
        })
        rendered = SUPERVISOR.format_log_line(claude, {"thought"})
        self.assertIn("consider the race", rendered)
        self.assertNotIn("final answer", rendered)
        self.assertNotIn("Read", rendered)

        agy = json.dumps({
            "event": "step_update",
            "step_update": {
                "state": "DONE", "step_type": "agent_response",
                "usage": {"thinking_tokens": 61},
            },
        })
        self.assertIn("61 tokens", SUPERVISOR.format_log_line(agy, {"thought"}))
        self.assertIsNone(SUPERVISOR.format_log_line(agy, {"comm"}))

        app_server = json.dumps({
            "method": "item/completed",
            "params": {"item": {
                "type": "reasoning",
                "summary": [{"type": "summary_text", "text": "Codex summary"}],
            }},
        })
        self.assertIn("Codex summary", SUPERVISOR.format_log_line(
            app_server, {"thought"}))

    def test_structured_log_observer_coalesces_grok_token_fragments(self):
        comms = SUPERVISOR.StructuredLogObserver({"comm"})
        self.assertEqual(comms.feed('{"type":"thought","data":"Need"}'), [])
        self.assertEqual(comms.feed('{"type":"thought","data":" inbox"}'), [])
        self.assertEqual(comms.feed('{"type":"text","data":"S"}'), [])
        self.assertEqual(comms.feed('{"type":"text","data":"aru"}'), [])
        self.assertEqual(comms.feed('{"type":"text","data":" confirms."}'), [])
        self.assertEqual(comms.feed('{"type":"usage","usage":{}}'), [
            "Saru confirms.",
        ])

        thoughts = SUPERVISOR.StructuredLogObserver({"thought"})
        self.assertEqual(thoughts.feed('{"type":"thought","data":"Need"}'), [])
        self.assertEqual(thoughts.feed('{"type":"thought","data":" inbox."}'), [])
        self.assertEqual(thoughts.feed('{"type":"usage","usage":{}}'), [
            "[thinking] Need inbox.",
        ])

        cursor = SUPERVISOR.StructuredLogObserver({"thought"})
        self.assertEqual(cursor.feed(
            '{"type":"thinking","subtype":"delta","text":"Need"}'), [])
        self.assertEqual(cursor.feed(
            '{"type":"thinking","subtype":"delta","text":" inbox."}'), [])
        self.assertEqual(cursor.feed(
            '{"type":"thinking","subtype":"completed"}'), [
                "[thinking] Need inbox.",
            ])

    def test_carried_over_agy_conversation_error_is_demoted_to_stale(self):
        observer = SUPERVISOR.StructuredLogObserver({"comm"})
        rendered = observer.feed(json.dumps({
            "event": "result",
            "result": {
                "status": "ERROR", "response": "(Standby.)",
                "error": "ValueError: 'scope' is required and must be a non-empty string",
                "num_turns": 172,
            },
        }))
        self.assertEqual(len(rendered), 1)
        self.assertIn("stale error from an earlier turn", rendered[0])
        self.assertIn("'scope' is required", rendered[0])
        self.assertNotIn("[error]", rendered[0])

    def test_error_produced_by_this_session_stays_a_real_error(self):
        observer = SUPERVISOR.StructuredLogObserver({"comm", "tool"})
        observer.feed(json.dumps({
            "event": "step_update",
            "step_update": {
                "state": "DONE", "step_type": "tool",
                "tool_name": "call_mcp_tool",
                "tool_info": {
                    "parameters": {"ToolName": "memory_append"},
                    "output": "ValueError: 'scope' is required and must be a non-empty string",
                },
            },
        }))
        rendered = observer.feed(json.dumps({
            "event": "result",
            "result": {
                "status": "ERROR", "response": "(Standby.)",
                "error": "ValueError: 'scope' is required and must be a non-empty string",
            },
        }))
        self.assertEqual(len(rendered), 1)
        self.assertIn("[error]", rendered[0])
        self.assertNotIn("stale error", rendered[0])

    def test_turn_without_response_keeps_its_error_as_current(self):
        observer = SUPERVISOR.StructuredLogObserver({"comm"})
        rendered = observer.feed(json.dumps({
            "event": "result",
            "result": {"status": "ERROR", "response": "", "error": "API quota exhausted"},
        }))
        self.assertEqual(len(rendered), 1)
        self.assertIn("[error] API quota exhausted", rendered[0])

    def test_format_log_line_strips_terminal_cursor_and_screen_controls(self):
        raw = (
            "\x1b]0;autodocs\x07\x1b[?1049h\x1b[2J\x1b[60;3H"
            "visible agent output\x1b[0m\x1b[?25h\r\n"
        )
        rendered = SUPERVISOR.format_log_line(raw)
        self.assertEqual(rendered, "visible agent output")
        self.assertNotIn("\x1b", rendered)
        self.assertIsNone(SUPERVISOR.format_log_line("\x1b[2J\x1b[60;3H───\r\n"))
        self.assertTrue(SUPERVISOR.terminal_segment_is_noise("Wor"))
        self.assertEqual(
            SUPERVISOR.terminal_segment_key("Working (1m 38s)"),
            SUPERVISOR.terminal_segment_key("Working (2m 04s)"),
        )

    def test_structured_log_and_mail_fields_cannot_control_observe_terminal(self):
        raw = json.dumps({
            "type": "item.completed",
            "item": {
                "type": "command_execution",
                "aggregated_output": "first\n\x1b[2Jsecond\x07X\bY",
                "exit_code": 0,
            },
        })
        rendered = SUPERVISOR.format_log_line(raw)
        self.assertEqual(rendered, "  | first\n  | secondY")
        self.assertNotIn("\x1b", rendered)
        self.assertNotIn("\x07", rendered)
        self.assertNotIn("\033", SUPERVISOR.format_log_line(
            '{"type":"turn.started"}'))

        mail = SUPERVISOR.format_mail_message({
            "sender": "data\x1b[2J", "to": "all",
            "subject": "safe\x07", "body": "one\r\ntwo\x1b[H",
        })
        self.assertEqual(mail, ["data -> all | safe", "one", "two"])

    def test_interactive_prompt_observer_emits_only_submitted_complete_prompt(self):
        observer = SUPERVISOR.InteractivePromptObserver()
        self.assertEqual(observer.feed(["> Entw"]), [])
        self.assertEqual(observer.feed(["> Entwickle den Patch"]), [])
        self.assertEqual(observer.feed(["  und teste ihn", "Working..."]), [
            "> Entwickle den Patch und teste ihn",
        ])
        self.assertEqual(observer.feed(["Ent", "Entwurf", "Working..."]), [])

        observer.feed(["? for shortcuts"])
        self.assertEqual(observer.feed(["> Entwickle den Patch", "Working..."]), [
            "> Entwickle den Patch",
        ])

    def test_interactive_prompt_observer_accepts_grok_prompt_markers(self):
        observer = SUPERVISOR.InteractivePromptObserver()
        self.assertEqual(observer.feed(["❯ Check the mailbox"]), [])
        self.assertEqual(observer.feed(["Working"]), ["> Check the mailbox"])
        observer.feed(["Type a message and press Enter to send it."])
        self.assertEqual(observer.feed(["› Continue the task"]), [])
        self.assertEqual(observer.feed(["Thinking"]), ["> Continue the task"])

    def test_interactive_prompt_observer_emits_grok_timestamped_prompt_once(self):
        observer = SUPERVISOR.InteractivePromptObserver()
        self.assertEqual(observer.feed([
            "❯ lead 004",
            "❯ lead 0041 and 0033",
            "❯ /usage View usage",
        ]), [])
        self.assertEqual(observer.feed([
            "❯ lead 0041 and 0033 to completion 10:45 PM",
            "⠋ Waiting for response… 0.0s",
            "◆ Thinking…",
            "❯ lead 0041 and 0033 to completion 10:45 PM",
        ]), ["> lead 0041 and 0033 to completion"])
        self.assertEqual(observer.feed([
            "❯ list open features 10:48 PM",
        ]), ["> list open features"])
        self.assertEqual(observer.feed([
            "Michael Burnham session: four-team roster roles",
            "> lead 0041 and 0033 to completion",
            "Resume this session with:",
        ]), ["> lead 0041 and 0033 to completion"])

    def test_observe_all_does_not_replay_logs_older_than_initial_tail(self):
        log_dir = self.state / "logs"
        log_dir.mkdir(parents=True)
        for index in range(7):
            path = log_dir / f"agent-{index}-20260823T12000{index}.jsonl"
            path.write_text(f"historical-{index}\n")
            os.utime(path, (index + 1, index + 1))

        args = argparse.Namespace(state_dir=self.state, target="all")
        output = io.StringIO()
        with mock.patch("sys.stdout", output), mock.patch.object(
                SUPERVISOR.time, "sleep", side_effect=KeyboardInterrupt):
            self.assertEqual(SUPERVISOR.observe(args), 0)

        rendered = output.getvalue()
        self.assertNotIn("historical-0", rendered)
        self.assertNotIn("historical-1", rendered)
        for index in range(2, 7):
            self.assertIn(f"historical-{index}", rendered)

    def test_observe_comm_coalesces_grok_stream_into_one_response(self):
        log_dir = self.state / "logs"
        log_dir.mkdir(parents=True)
        log = log_dir / "saru-20260824T232019.jsonl"
        log.write_text("\n".join((
            '{"type":"thought","data":"Need"}',
            '{"type":"thought","data":" inbox."}',
            '{"type":"text","data":"S"}',
            '{"type":"text","data":"aru"}',
            '{"type":"text","data":" confirms"}',
            '{"type":"text","data":" the hold."}',
            '{"type":"usage","usage":{}}',
            '{"type":"end","num_turns":1}',
        )) + "\n")
        args = argparse.Namespace(
            state_dir=self.state, store=self.store, inbox=self.config,
            target="all", observe_filters=["comms"],
        )
        output = io.StringIO()
        with mock.patch("sys.stdout", output), mock.patch.object(
                SUPERVISOR.time, "sleep", side_effect=KeyboardInterrupt):
            self.assertEqual(SUPERVISOR.observe(args), 0)

        rendered = output.getvalue()
        self.assertIn("Saru confirms the hold.", rendered)
        self.assertNotIn("Need inbox", rendered)
        self.assertEqual(rendered.count("[saru]"), 2)

    def test_mailbox_tail_skips_history_and_returns_all_new_messages(self):
        journal = self.store / "data/messages.jsonl"
        old = {"id": "old", "sender": "picard", "to": "all", "body": "old"}
        direct = {"id": "direct", "sender": "picard", "to": "data", "body": "direct"}
        live = {"id": "live", "sender": "picard", "to": "all", "body": "live"}
        live.update(subject="Important", thread="0045", body="first\nsecond")
        journal.parent.mkdir(parents=True)
        journal.write_text(json.dumps(old) + "\n")

        tail = SUPERVISOR.MailboxTail(journal)
        tail.start()
        with open(journal, "a", encoding="utf-8") as output:
            output.write(json.dumps(direct) + "\n")
            output.write(json.dumps(live) + "\n")
        try:
            self.assertEqual(
                [message["id"] for message in tail.read()], ["direct", "live"])
            self.assertEqual(tail.read(), [])
            self.assertEqual(
                SUPERVISOR.format_mail_message(live),
                ["picard -> all | Important | thread=0045", "first", "second"],
            )
        finally:
            tail.close()

    def test_mailbox_tail_keeps_messages_across_atomic_rewrite(self):
        journal = self.store / "data/messages.jsonl"
        journal.parent.mkdir(parents=True)
        old = {"id": "old", "sender": "picard", "to": "data", "body": "old"}
        trigger = {"id": "trigger", "sender": "data", "to": "all", "body": "trigger"}
        following = {"id": "following", "sender": "sisko", "to": "picard", "body": "following"}
        journal.write_text(json.dumps(old) + "\n")
        tail = SUPERVISOR.MailboxTail(journal)
        tail.start()
        with open(journal, "a", encoding="utf-8") as output:
            output.write(json.dumps(trigger) + "\n")
        replacement = journal.with_suffix(".tmp")
        replacement.write_text("".join(
            json.dumps(message) + "\n" for message in (old, trigger, following)))
        os.replace(replacement, journal)
        try:
            self.assertEqual(
                [message["id"] for message in tail.read()],
                ["trigger", "following"],
            )
        finally:
            tail.close()

    def test_observe_all_prints_live_direct_mail_and_broadcast_body(self):
        journal = self.store / "data/messages.jsonl"
        old = {"id": "old", "sender": "picard", "to": "all", "body": "old"}
        direct = {"id": "direct", "sender": "data", "to": "picard",
                  "subject": "Direct subject", "body": "direct body"}
        live = {"id": "live", "sender": "picard", "to": "all", "body": "live"}
        live.update(subject="Live subject", body="complete live body")
        journal.parent.mkdir(parents=True)
        journal.write_text(json.dumps(old) + "\n")
        args = argparse.Namespace(state_dir=self.state, store=self.store, target="all")
        output = io.StringIO()
        sleeps = 0

        def append_then_stop(_seconds):
            nonlocal sleeps
            sleeps += 1
            if sleeps == 1:
                with open(journal, "a", encoding="utf-8") as mailbox:
                    mailbox.write(json.dumps(direct) + "\n")
                    mailbox.write(json.dumps(live) + "\n")
                return
            raise KeyboardInterrupt

        with mock.patch("sys.stdout", output), mock.patch.object(
                SUPERVISOR.time, "sleep", side_effect=append_then_stop):
            self.assertEqual(SUPERVISOR.observe(args), 0)

        rendered = output.getvalue()
        self.assertIn("[MAIL]", rendered)
        self.assertIn("data -> picard | Direct subject", rendered)
        self.assertIn("direct body", rendered)
        self.assertIn("[BROADCAST]", rendered)
        self.assertIn("Live subject", rendered)
        self.assertIn("complete live body", rendered)
        self.assertNotIn("old ->", rendered)

    def test_observe_mail_filter_limits_direct_mail_to_target(self):
        journal = self.store / "data/messages.jsonl"
        journal.parent.mkdir(parents=True)
        journal.write_text(json.dumps({
            "id": "old", "sender": "picard", "to": "data", "body": "old",
        }) + "\n")
        relevant_in = {
            "id": "in", "sender": "picard", "to": "data", "body": "incoming",
        }
        relevant_out = {
            "id": "out", "sender": "data", "to": "geordi", "body": "outgoing",
        }
        unrelated = {
            "id": "other", "sender": "tom", "to": "harry", "body": "unrelated",
        }
        broadcast = {
            "id": "broadcast", "sender": "picard", "to": "all", "body": "global",
        }
        args = argparse.Namespace(
            state_dir=self.state, store=self.store, target="data",
            observe_filters=["mails"],
        )
        output = io.StringIO()
        sleeps = 0

        def append_then_stop(_seconds):
            nonlocal sleeps
            sleeps += 1
            if sleeps == 1:
                with open(journal, "a", encoding="utf-8") as mailbox:
                    for message in (relevant_in, relevant_out, unrelated, broadcast):
                        mailbox.write(json.dumps(message) + "\n")
                return
            raise KeyboardInterrupt

        with mock.patch("sys.stdout", output), mock.patch.object(
                SUPERVISOR.time, "sleep", side_effect=append_then_stop):
            self.assertEqual(SUPERVISOR.observe(args), 0)

        rendered = output.getvalue()
        self.assertIn("incoming", rendered)
        self.assertIn("outgoing", rendered)
        self.assertNotIn("unrelated", rendered)
        self.assertNotIn("global", rendered)
        self.assertNotIn("old ->", rendered)

    def test_observe_all_follows_active_interactive_log_outside_initial_five(self):
        log_dir = self.state / "logs"
        log_dir.mkdir(parents=True)
        active_log = log_dir / "data-20260824T010000000000.jsonl"
        active_log.write_text("old interactive output\n")
        os.utime(active_log, (1, 1))
        for index in range(6):
            path = log_dir / f"agent-{index}-20260824T02000{index}.jsonl"
            path.write_text(f"other-{index}\n")
            os.utime(path, (index + 10, index + 10))
        sessions = self.state / "sessions"
        sessions.mkdir()
        (sessions / "data.json").write_text(json.dumps({
            "agent": "data", "mode": "talk", "log": str(active_log),
            "pid": os.getpid(),
        }))

        args = argparse.Namespace(state_dir=self.state, store=self.store, target="all")
        output = io.StringIO()
        sleeps = 0

        def append_then_stop(_seconds):
            nonlocal sleeps
            sleeps += 1
            if sleeps == 1:
                with open(active_log, "a", encoding="utf-8") as transcript:
                    transcript.write("\x1b[2J\x1b[60;3H> prü\x1b[0m\r\n")
                    transcript.write("> prüfe die Inbox\x1b[0m\r\n")
                    transcript.write("  und berichte knapp\x1b[0m\r\n")
                    transcript.write("Working...\x1b[0m\r\n")
                    transcript.write("partielle Antwort\x1b[0m\r\n")
                return
            raise KeyboardInterrupt

        with mock.patch("sys.stdout", output), mock.patch.object(
                SUPERVISOR.time, "sleep", side_effect=append_then_stop):
            self.assertEqual(SUPERVISOR.observe(args), 0)

        rendered = output.getvalue()
        self.assertIn("[data]", rendered)
        self.assertIn("> prüfe die Inbox und berichte knapp", rendered)
        self.assertEqual(rendered.count("> prüfe die Inbox und berichte knapp"), 1)
        self.assertNotIn("partielle Antwort", rendered)
        self.assertNotIn("> prü", rendered.replace("> prüfe die Inbox und berichte knapp", ""))
        self.assertNotIn("[2J", rendered)
        self.assertNotIn("[60;3H", rendered)
        self.assertNotIn("old interactive output", rendered)

    def test_chat_records_native_interactive_session_for_observe(self):
        args = argparse.Namespace(**vars(self.args))
        args.command = "talk"
        args.target = "data"
        captured = {}

        def run_recorded(command, cwd, **kwargs):
            captured["command"] = command
            captured["cwd"] = cwd
            session = json.loads((self.state / "sessions/data.json").read_text())
            captured["session"] = session
            Path(session["log"]).write_text("interactive transcript\n")
            return 0

        with mock.patch.object(SUPERVISOR, "_require_foreground_terminal"), \
             mock.patch.object(SUPERVISOR.Supervisor, "interactive_command",
                               return_value=("data", ["native-cli", "--resume", "session"])), \
             mock.patch.object(SUPERVISOR.subprocess, "call", side_effect=run_recorded):
            self.assertEqual(SUPERVISOR.chat(args), 0)

        command = captured["command"]
        self.assertEqual(command[:3], ["/usr/bin/script", "-q", "-F"])
        self.assertEqual(command[4:], ["native-cli", "--resume", "session"])
        self.assertEqual(command[3], captured["session"]["log"])
        self.assertEqual(captured["session"]["agent"], "data")
        self.assertFalse((self.state / "sessions/data.json").exists())

    def test_provider_usage_formats_are_normalized(self):
        codex = SUPERVISOR.parse_codex_usage_result({"rateLimits": {
            "limitId": "codex",
            "primary": {"usedPercent": 86, "windowDurationMins": 10080,
                        "resetsAt": 1787515743},
        }})
        self.assertEqual(codex["windows"][0]["label"], "7d")
        self.assertEqual(codex["windows"][0]["remaining_percent"], 14)

        claude = SUPERVISOR.parse_claude_usage_output(json.dumps({
            "result": (
                "Current session: 12% used · resets Aug 24 at 2:19am (Europe/Berlin)\n"
                "Current week (all models): 22% used · resets Aug 30 at 5:59am "
                "(Europe/Berlin)"
            ),
        }))
        self.assertEqual(
            [window["remaining_percent"] for window in claude["windows"]],
            [88, 78],
        )

        agy = SUPERVISOR.parse_agy_usage_output(json.dumps({
            "command": {"data": {"groups": [{
                "name": "Gemini Models",
                "buckets": [{"window": "weekly", "remaining_fraction": 0.97,
                             "reset_time": "2026-08-30T11:15:32Z"}],
            }]}},
        }))
        self.assertAlmostEqual(agy["windows"][0]["remaining_percent"], 97)

        cursor = SUPERVISOR.parse_cursor_usage_summary({
            "billingCycleEnd": "2026-09-24T19:32:03.000Z",
            "membershipType": "pro_plus",
            "individualUsage": {"plan": {
                "used": 700, "limit": 7000,
                "autoPercentUsed": 10, "apiPercentUsed": 40, "totalPercentUsed": 14,
            }},
        })
        self.assertEqual(cursor["provider"], "cursor")
        self.assertEqual(
            [round(window["remaining_percent"]) for window in cursor["windows"]],
            [86, 90],
        )
        self.assertEqual([window["label"] for window in cursor["windows"]], ["plan", "auto"])
        self.assertEqual(cursor["windows"][0]["resets_at"], "2026-09-24T19:32:03.000Z")

    def test_cursor_session_cookie_uses_jwt_sub(self):
        token = self._cursor_jwt("user_01TEST")
        cookie = SUPERVISOR.cursor_session_cookie(token)
        self.assertTrue(cookie.startswith("user_01TEST%3A%3A"))
        self.assertNotIn("::", cookie)

    def test_cursor_usage_reads_sqlite_token_and_usage_summary(self):
        token = self._cursor_jwt("user_01TEST")
        db = Path(self.tmp.name) / "state.vscdb"
        connection = sqlite3.connect(db)
        connection.execute("CREATE TABLE ItemTable (key TEXT, value TEXT)")
        connection.execute(
            "INSERT INTO ItemTable VALUES (?, ?)",
            ("cursorAuth/accessToken", token),
        )
        connection.commit()
        connection.close()

        class Response:
            def read(self):
                return json.dumps({
                    "billingCycleEnd": "2026-09-01T00:00:00.000Z",
                    "individualUsage": {"plan": {"totalPercentUsed": 25}},
                }).encode()

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        captured = {}

        def urlopen(request, timeout=None):
            captured["url"] = request.full_url
            captured["cookie"] = request.get_header("Cookie")
            return Response()

        snapshot = SUPERVISOR.query_cursor_usage(
            self.workspace, token=None, urlopen=urlopen, state_db=db,
            env={}, keychain=False,
        )
        self.assertEqual(snapshot["windows"][0]["remaining_percent"], 75)
        self.assertIn("usage-summary", captured["url"])
        self.assertIn("user_01TEST%3A%3A", captured["cookie"])
        self.assertNotIn(token, json.dumps(snapshot))

    def test_grok_billing_credits_matches_grok_com_usage_tab(self):
        grok = SUPERVISOR.parse_grok_billing_credits({
            "config": {
                "creditUsagePercent": 1.0,
                "isUnifiedBillingUser": True,
                "currentPeriod": {
                    "type": "USAGE_PERIOD_TYPE_WEEKLY",
                    "start": "2026-08-24T18:49:00.623036+00:00",
                    "end": "2026-08-31T18:49:00.623036+00:00",
                },
                "productUsage": [{"product": "GrokBuild", "usagePercent": 1.0}],
            },
        })
        self.assertEqual(grok["provider"], "grok")
        self.assertEqual(grok["source"], "billing/credits")
        self.assertEqual(
            [(window["label"], round(window["remaining_percent"]))
             for window in grok["windows"]],
            [("7d", 99), ("7d/build", 99)],
        )
        self.assertEqual(
            grok["windows"][0]["resets_at"], "2026-08-31T18:49:00.623036+00:00")

    def test_grok_usage_reads_auth_json_and_billing_credits(self):
        token = "grok-session-token-secret"
        auth = Path(self.tmp.name) / "auth.json"
        auth.write_text(json.dumps({
            "https://auth.x.ai::example": {
                "key": token,
                "expires_at": "2026-08-26T16:33:39.149001Z",
            },
        }))

        class Response:
            def read(self):
                return json.dumps({
                    "config": {
                        "creditUsagePercent": 1.0,
                        "currentPeriod": {
                            "type": "USAGE_PERIOD_TYPE_WEEKLY",
                            "end": "2026-08-31T18:49:00Z",
                        },
                    },
                }).encode()

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        captured = {}

        def urlopen(request, timeout=None):
            captured["url"] = request.full_url
            captured["auth"] = request.get_header("Authorization")
            return Response()

        snapshot = SUPERVISOR.query_grok_usage(
            self.workspace, token=None, urlopen=urlopen, auth_path=auth, env={},
        )
        self.assertEqual(snapshot["windows"][0]["remaining_percent"], 99)
        self.assertIn("billing?format=credits", captured["url"])
        self.assertEqual(captured["auth"], f"Bearer {token}")
        self.assertNotIn(token, json.dumps(snapshot))

    def test_grok_usage_redacts_token_on_http_error(self):
        token = "grok-session-token-secret"

        def urlopen(request, timeout=None):
            raise urllib.error.HTTPError(
                request.full_url, 401, "unauthenticated", hdrs=None,
                fp=io.BytesIO(b"denied " + token.encode()),
            )

        with self.assertRaises(ValueError) as raised:
            SUPERVISOR.query_grok_usage(
                self.workspace, token=token, urlopen=urlopen, env={},
            )
        self.assertNotIn(token, str(raised.exception))
        self.assertIn("<redacted>", str(raised.exception))

    def test_project_leader_for_grok_is_leahcim(self):
        supervisor = self.supervisor()
        self.assertEqual(supervisor.project_leader("grok"), "leahcim")

    def test_cursor_usage_falls_back_to_auth_usage(self):
        token = self._cursor_jwt("user_01TEST")

        class Response:
            def __init__(self, payload):
                self.payload = payload

            def read(self):
                return json.dumps(self.payload).encode()

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        def urlopen(request, timeout=None):
            if "usage-summary" in request.full_url:
                raise urllib.error.HTTPError(
                    request.full_url, 401, "unauthenticated", hdrs=None, fp=io.BytesIO(b"nope"))
            return Response({
                "gpt-4": {"numRequests": 20, "maxRequestUsage": 100},
                "startOfMonth": "2026-08-01T00:00:00.000Z",
            })

        snapshot = SUPERVISOR.query_cursor_usage(
            self.workspace, token=token, urlopen=urlopen, keychain=False, env={},
        )
        self.assertEqual(snapshot["source"], "auth/usage")
        self.assertEqual(snapshot["windows"][0]["remaining_percent"], 80)

    def _cursor_jwt(self, sub):
        payload = base64.urlsafe_b64encode(json.dumps({"sub": sub, "type": "session"}).encode()).rstrip(b"=").decode()
        return f"eyJhbGciOiJub25lIn0.{payload}.sig"

    def test_run_usage_poll_is_immediate_then_every_ten_minutes(self):
        supervisor = self.supervisor()
        supervisor.args.command = "run"

        remaining = {"codex": 80, "claude": 70, "agy": 60, "cursor": 50, "grok": 40}

        def snapshot(provider, _workspace):
            value = remaining[provider]
            return {
                "provider": provider, "checked_at": "2026-08-23T20:00:00+00:00",
                "windows": [{"label": "7d", "used_percent": 100 - value,
                             "remaining_percent": value}],
            }

        with mock.patch.object(
            SUPERVISOR, "query_provider_usage", side_effect=snapshot,
        ) as query, mock.patch.object(
            supervisor, "notify_project_leader_about_usage", return_value=True,
        ) as notify:
            self.assertTrue(supervisor.poll_usage(timestamp=1000))
            self.assertFalse(supervisor.poll_usage(timestamp=1599))
            self.assertTrue(supervisor.poll_usage(timestamp=1600))
            self.assertEqual(query.call_count, 10)
            self.assertEqual(notify.call_count, 10)

            remaining["codex"] = 20
            self.assertTrue(supervisor.poll_usage(timestamp=2200))
            self.assertEqual(query.call_count, 15)
            self.assertEqual(notify.call_count, 15)
            notified_providers = [call.args[0] for call in notify.call_args_list[-5:]]
            self.assertEqual(notified_providers, ["agy", "claude", "codex", "cursor", "grok"])

    def test_reset_epoch_parses_epoch_millis_iso_and_rejects_prose(self):
        self.assertEqual(SUPERVISOR._reset_epoch(1787830000), 1787830000.0)
        self.assertEqual(SUPERVISOR._reset_epoch(1787830000000), 1787830000.0)
        self.assertEqual(SUPERVISOR._reset_epoch("1787830000"), 1787830000.0)
        expected = SUPERVISOR.datetime(
            2026, 9, 24, 19, 32, 3, tzinfo=SUPERVISOR.timezone.utc).timestamp()
        self.assertEqual(
            SUPERVISOR._reset_epoch("2026-09-24T19:32:03.000Z"), expected)
        self.assertIsNone(SUPERVISOR._reset_epoch("Aug 30 at 6am (Europe/Berlin)"))
        self.assertIsNone(SUPERVISOR._reset_epoch(None))

    def test_poll_usage_rechecks_one_minute_after_the_next_window_reset(self):
        supervisor = self.supervisor()

        def snapshot(provider, _workspace):
            window = {"label": "5h", "used_percent": 95.0,
                      "remaining_percent": 5.0}
            if provider == "codex":
                window["resets_at"] = 1120
            return {
                "provider": provider, "checked_at": "2026-08-27T12:00:00+00:00",
                "windows": [window],
            }

        with mock.patch.object(
                SUPERVISOR, "query_provider_usage", side_effect=snapshot) as query:
            self.assertTrue(supervisor.poll_usage(timestamp=1000, notify=False))
            self.assertEqual(query.call_count, 5)
            # Only the provider whose window resets is pulled forward to one
            # minute after that reset; the others keep the regular interval.
            self.assertEqual(supervisor.next_usage_checks["codex"], 1120 + 60)
            for other in ("agy", "claude", "cursor", "grok"):
                self.assertEqual(supervisor.next_usage_checks[other], 1600)
            # At the recheck moment only codex is due, so only codex is polled.
            self.assertTrue(supervisor.poll_usage(timestamp=1200, notify=False))
            self.assertEqual(query.call_count, 6)
            self.assertEqual(query.call_args.args[0], "codex")
            self.assertFalse(supervisor.poll_usage(timestamp=1300, notify=False))

    def test_poll_usage_clears_stale_cursor_unsupported(self):
        supervisor = self.supervisor()
        supervisor.state["usage"] = {"cursor": {
            "provider": "cursor",
            "unsupported": "the installed Cursor CLI has no scriptable rate-limit snapshot",
            "windows": [],
        }}

        def snapshot(provider, _workspace):
            return {
                "provider": provider, "checked_at": "t",
                "windows": [{"label": "plan", "used_percent": 11,
                             "remaining_percent": 89}],
            }

        with mock.patch.object(SUPERVISOR, "query_provider_usage", side_effect=snapshot), \
                mock.patch.object(supervisor, "notify_project_leader_about_usage",
                                  return_value=True):
            self.assertTrue(supervisor.poll_usage(timestamp=1))
        entry = supervisor.state["usage"]["cursor"]
        self.assertNotIn("unsupported", entry)
        self.assertEqual(entry["windows"][0]["remaining_percent"], 89)
        self.assertIn("89% left", SUPERVISOR.format_usage_snapshot(entry))

    def test_poll_usage_clears_stale_grok_unsupported(self):
        supervisor = self.supervisor()
        supervisor.state["usage"] = {"grok": {
            "provider": "grok",
            "unsupported": "the installed Grok CLI exposes /usage only inside its interactive TUI",
            "windows": [],
        }}

        def snapshot(provider, _workspace):
            return {
                "provider": provider, "checked_at": "t",
                "windows": [{"label": "7d", "used_percent": 1,
                             "remaining_percent": 99}],
            }

        with mock.patch.object(SUPERVISOR, "query_provider_usage", side_effect=snapshot), \
                mock.patch.object(supervisor, "notify_project_leader_about_usage",
                                  return_value=True):
            self.assertTrue(supervisor.poll_usage(timestamp=1))
        entry = supervisor.state["usage"]["grok"]
        self.assertNotIn("unsupported", entry)
        self.assertEqual(entry["windows"][0]["remaining_percent"], 99)
        self.assertIn("99% left", SUPERVISOR.format_usage_snapshot(entry))

    def test_leahcim_wake_prompt_includes_grok_usage(self):
        supervisor = self.supervisor()
        supervisor.state["usage"] = {"grok": {
            "provider": "grok",
            "windows": [{"label": "7d", "used_percent": 1,
                         "remaining_percent": 99,
                         "resets_at": "2026-08-31T18:49:00Z"}],
        }}
        prompt = supervisor.wake_prompt(
            "leahcim", supervisor.agents["leahcim"], ["m1"])
        self.assertIn("Current provider usage", prompt)
        self.assertIn("99% left", prompt)

    def test_project_lead_wake_prompt_includes_latest_provider_usage(self):
        supervisor = self.supervisor()
        supervisor.state["usage"] = {"codex": {
            "provider": "codex",
            "windows": [{"label": "7d", "used_percent": 86,
                         "remaining_percent": 14, "resets_at": 1787515743}],
        }}
        prompt = supervisor.wake_prompt(
            "jean-luc", supervisor.agents["jean-luc"], ["m1"])
        self.assertIn("Current provider usage", prompt)
        self.assertIn("14% left", prompt)

    def test_low_usage_never_blocks_agent_scheduling(self):
        supervisor = self.supervisor()
        supervisor.args.command = "once"
        supervisor.args.max_parallel = 10
        supervisor.state["usage"] = {"codex": {
            "provider": "codex",
            "windows": [{"label": "7d", "used_percent": 95,
                         "remaining_percent": 5}],
        }}
        selected = [
            ("data", supervisor.agents["data"], "codex"),
            ("jean-luc", supervisor.agents["jean-luc"], "codex"),
        ]
        launched = []

        def launch(name, _config, _runtime, _unread):
            launched.append(name)
            return True

        with mock.patch.object(supervisor, "selected", return_value=selected), \
                mock.patch.object(supervisor, "rotate_codex_rollouts"), \
                mock.patch.object(supervisor, "archive_messages"), \
                mock.patch.object(supervisor, "unread", return_value=[{"id": "m1"}]), \
                mock.patch.object(supervisor, "retry_ready", return_value=True), \
                mock.patch.object(supervisor, "launch", side_effect=launch):
            supervisor.tick()
        self.assertEqual(launched, ["data", "jean-luc"])

    def test_native_codex_writer_lock_is_detected(self):
        thread_id = "33333333-3333-3333-3333-333333333333"
        lock_path = (
            self.args.codex_profiles / "thread-writer-locks" /
            f"{thread_id}.lock"
        )
        lock_path.parent.mkdir(parents=True)
        with open(lock_path, "a+") as holder:
            fcntl.flock(holder, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.assertTrue(SUPERVISOR.codex_thread_has_active_writer(
                self.args.codex_profiles, thread_id,
            ))
            fcntl.flock(holder, fcntl.LOCK_UN)
        self.assertFalse(SUPERVISOR.codex_thread_has_active_writer(
            self.args.codex_profiles, thread_id,
        ))

    def test_external_codex_writer_uses_owning_app_server(self):
        supervisor = self.supervisor()
        thread_id = "33333333-3333-3333-3333-333333333333"
        supervisor.agent_state("data")["thread_id"] = thread_id
        with mock.patch.object(
            SUPERVISOR, "codex_thread_has_active_writer", return_value=True,
        ), mock.patch.object(SUPERVISOR.subprocess, "Popen") as popen:
            process = popen.return_value
            process.pid = 12345
            self.assertTrue(supervisor.launch(
                "data", supervisor.agents["data"], "codex", [{"id": "m1"}],
            ))
        command = popen.call_args.args[0]
        self.assertEqual(Path(command[1]).name, "codex_app_server_turn.py")
        self.assertIn(thread_id, command)
        self.assertTrue(any(part.endswith("data.config.toml") for part in command))
        state = supervisor.agent_state("data")
        self.assertEqual(state["external_writer_thread"], thread_id)
        self.assertEqual(state["pid"], 12345)
        supervisor.processes["data"]["log"].close()
        SUPERVISOR._release_lock(supervisor.processes["data"]["lock"])
        supervisor.processes.clear()

    def test_external_writer_detection_preserves_fibonacci_schedule(self):
        supervisor = self.supervisor()
        state = supervisor.agent_state("data")
        state.update(attempts=3, next_wake=4321, wake_backoff_index=2)
        supervisor.note_external_codex_writer("data", "thread-1")
        self.assertEqual(state["attempts"], 3)
        self.assertEqual(state["next_wake"], 4321)
        self.assertEqual(state["wake_backoff_index"], 2)

    def test_app_server_log_notifications_are_visible_in_observe(self):
        completed_item = json.dumps({
            "method": "item/completed",
            "params": {"item": {"type": "agentMessage", "text": "handled"}},
        })
        completed_turn = json.dumps({
            "method": "turn/completed",
            "params": {"turn": {"status": "completed", "durationMs": 2500}},
        })
        self.assertIn("handled", SUPERVISOR.format_log_line(completed_item))
        self.assertIn("turn completed, 2.5s", SUPERVISOR.format_log_line(completed_turn))

    def test_status_reports_external_codex_writer(self):
        thread_id = "33333333-3333-3333-3333-333333333333"
        self.state.mkdir(parents=True)
        SUPERVISOR.atomic_json(self.state / "state.json", {
            "agents": {"data": {"thread_id": thread_id}},
        })
        output = io.StringIO()
        with mock.patch.object(
            SUPERVISOR, "codex_thread_has_active_writer", return_value=True,
        ), mock.patch.object(
            SUPERVISOR, "_instance_info", return_value={},
        ), mock.patch("sys.stdout", output):
            self.assertEqual(SUPERVISOR.status(self.args), 0)
        self.assertIn(
            f"status=externally-active(thread={thread_id})", output.getvalue(),
        )

    def test_active_writer_failure_does_not_enter_retry_loop(self):
        supervisor = self.supervisor()
        thread_id = "33333333-3333-3333-3333-333333333333"
        supervisor.agent_state("data")["thread_id"] = thread_id
        log_path = Path(self.tmp.name) / "writer-conflict.jsonl"
        log_path.write_text(
            f"Error: thread {thread_id} already has an active writer\n"
        )

        class Process:
            pid = 12345

            def poll(self):
                return 1

        supervisor.processes["data"] = {
            "process": Process(), "log": mock.Mock(), "path": log_path,
            "runtime": "codex", "signature": "m1", "lock": None,
        }
        with mock.patch.object(supervisor, "schedule_retry") as retry:
            supervisor.reap()
        retry.assert_not_called()
        state = supervisor.agent_state("data")
        self.assertEqual(state["external_writer_thread"], thread_id)
        self.assertEqual(state["attempts"], 0)
        self.assertEqual(state["next_wake"], 0)

    def test_successful_turn_starts_redelivery_at_five_seconds(self):
        supervisor = self.supervisor()
        log_path = Path(self.tmp.name) / "successful.jsonl"
        log_path.write_text("")

        class Process:
            pid = 12345

            def poll(self):
                return 0

        supervisor.processes["data"] = {
            "process": Process(), "log": mock.Mock(), "path": log_path,
            "runtime": "codex", "signature": "m1", "lock": None,
        }
        with mock.patch.object(SUPERVISOR.time, "time", return_value=1000):
            supervisor.reap()

        state = supervisor.agent_state("data")
        self.assertEqual(state["attempts"], 0)
        self.assertEqual(state["next_wake"], 1005)
        self.assertEqual(state["wake_outcome"], "success")
        self.assertEqual(state["wake_backoff_index"], 0)
        self.assertFalse(supervisor.retry_ready("data", "m1", 1004.9))
        self.assertTrue(supervisor.retry_ready("data", "m1", 1005))

    def test_wake_curve_starts_in_seconds_and_caps_at_ninety_minutes(self):
        supervisor = self.supervisor()
        expected = [5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610,
                    987, 1597, 2584, 4181, 5400, 5400]
        for outcome in ("success", "error"):
            supervisor.clear_wake_schedule("data")
            observed = []
            for _index in range(len(expected)):
                with mock.patch.object(SUPERVISOR.time, "time", return_value=1000):
                    supervisor.schedule_outcome_wake(
                        "data", "m1", outcome,
                        0 if outcome == "success" else 1,
                        "" if outcome == "success" else "offline",
                    )
                observed.append(
                    supervisor.agent_state("data")["next_wake"] - 1000)
            self.assertEqual(observed, expected)

    def test_outcome_change_resets_fibonacci_without_waiting_for_ack(self):
        supervisor = self.supervisor()
        with mock.patch.object(SUPERVISOR.time, "time", return_value=1000):
            supervisor.schedule_retry("data", "m1", 1, "offline")
            supervisor.schedule_retry("data", "m1", 1, "offline")
            supervisor.schedule_unacked_redelivery("data", "m1")
        state = supervisor.agent_state("data")
        self.assertEqual(state["wake_outcome"], "success")
        self.assertEqual(state["wake_backoff_index"], 0)
        self.assertEqual(state["next_wake"], 1005)

        with mock.patch.object(SUPERVISOR.time, "time", return_value=2000):
            supervisor.schedule_unacked_redelivery("data", "m1")
            supervisor.schedule_retry("data", "m1", 1, "offline")
        self.assertEqual(state["wake_outcome"], "error")
        self.assertEqual(state["wake_backoff_index"], 0)
        self.assertEqual(state["next_wake"], 2005)

    def test_new_message_signature_wakes_immediately_and_ack_clears_timer(self):
        supervisor = self.supervisor()
        state = supervisor.agent_state("data")
        state.update(
            signature="m1", attempts=4, next_wake=9999,
            wake_outcome="error", wake_backoff_index=4,
        )
        self.assertTrue(supervisor.retry_ready("data", "m1|m2", 1000))
        self.assertEqual(state["attempts"], 0)
        self.assertEqual(state["next_wake"], 0)
        # New mail restarts the backoff curve; the old index priced mail
        # the agent had already been ignoring, not this delivery.
        self.assertNotIn("wake_outcome", state)
        self.assertNotIn("wake_backoff_index", state)

        selected = [("data", supervisor.agents["data"], "codex")]
        state.update(attempts=2, next_wake=1180)
        with mock.patch.object(supervisor, "selected", return_value=selected), \
                mock.patch.object(supervisor, "rotate_codex_rollouts"), \
                mock.patch.object(supervisor, "archive_messages"), \
                mock.patch.object(supervisor, "unread", return_value=[]):
            supervisor.tick()
        self.assertEqual(state["attempts"], 0)
        self.assertEqual(state["next_wake"], 0)
        self.assertNotIn("wake_outcome", state)
        self.assertNotIn("wake_backoff_index", state)

    def test_talk_block_waits_one_one_two_minutes_before_termination(self):
        supervisor = self.supervisor()
        session = {"agent": "data", "pid": 4242}
        state = supervisor.agent_state("data")

        with mock.patch.object(supervisor, "terminate_interactive_session",
                               return_value=True) as terminate:
            supervisor.note_talk_blocked("data", "m1", 1000, session)
            self.assertEqual(state["talk_block"]["backoff_index"], 0)
            self.assertEqual(state["next_wake"], 1060)

            supervisor.note_talk_blocked("data", "m1", 1060, session)
            self.assertEqual(state["talk_block"]["backoff_index"], 1)
            self.assertEqual(state["next_wake"], 1120)

            supervisor.note_talk_blocked("data", "m1", 1120, session)
            self.assertEqual(state["talk_block"]["backoff_index"], 2)
            self.assertEqual(state["next_wake"], 1240)
            terminate.assert_not_called()

            supervisor.note_talk_blocked("data", "m1", 1239.9, session)
            terminate.assert_not_called()
            supervisor.note_talk_blocked("data", "m1", 1240, session)

        terminate.assert_called_once_with("data", session)
        self.assertEqual(state["talk_block"]["termination_requested_at"], 1240)
        self.assertEqual(state["next_wake"], 0)

    def test_new_mail_does_not_reset_or_advance_talk_block_cadence(self):
        supervisor = self.supervisor()
        session = {"agent": "data", "pid": 4242}
        state = supervisor.agent_state("data")

        supervisor.note_talk_blocked("data", "m1", 1000, session)
        supervisor.note_talk_blocked("data", "m1", 1060, session)
        self.assertEqual(state["next_wake"], 1120)
        supervisor.note_talk_blocked("data", "m1|m2", 1090, session)

        blocked = state["talk_block"]
        self.assertEqual(blocked["started_at"], 1000)
        self.assertEqual(blocked["backoff_index"], 1)
        self.assertEqual(blocked["next_attempt"], 1120)
        self.assertEqual(blocked["last_signature"], "m1|m2")
        self.assertEqual(state["next_wake"], 1120)

    def test_talk_block_resets_on_ack_or_when_talk_ends(self):
        supervisor = self.supervisor()
        session = {"agent": "data", "pid": 4242}
        state = supervisor.agent_state("data")
        supervisor.note_talk_blocked("data", "m1", 1000, session)

        with mock.patch.object(supervisor, "interactive_session", return_value=None):
            self.assertFalse(supervisor.refresh_talk_block("data"))
        self.assertNotIn("talk_block", state)
        self.assertEqual(state["next_wake"], 0)

        supervisor.note_talk_blocked("data", "m1", 2000, session)
        supervisor.clear_wake_schedule("data")
        self.assertNotIn("talk_block", state)
        self.assertEqual(state["next_wake"], 0)

    def test_live_talk_is_bounded_independently_of_normal_cooldown(self):
        supervisor = self.supervisor()
        supervisor.args.max_parallel = 0
        state = supervisor.agent_state("data")
        state.update(
            signature="m1", next_wake=9999,
            wake_outcome="success", wake_backoff_index=11,
        )
        selected = [("data", supervisor.agents["data"], "codex")]
        session = {"agent": "data", "pid": 4242}

        with mock.patch.object(SUPERVISOR.time, "time", return_value=1000), \
                mock.patch.object(supervisor, "selected", return_value=selected), \
                mock.patch.object(supervisor, "rotate_codex_rollouts"), \
                mock.patch.object(supervisor, "archive_messages"), \
                mock.patch.object(supervisor, "unread", return_value=[{"id": "m1"}]), \
                mock.patch.object(supervisor, "interactive_session",
                                  return_value=session), \
                mock.patch.object(supervisor, "launch") as launch:
            supervisor.tick()

        launch.assert_not_called()
        self.assertEqual(state["talk_block"]["started_at"], 1000)
        self.assertEqual(state["next_wake"], 1060)
        self.assertEqual(state["wake_backoff_index"], 11)

    def test_restore_interactive_terminal_resets_tty_and_emulator_modes(self):
        written = []
        stdin = mock.Mock()
        stdin.fileno.return_value = 0
        stdout = mock.Mock()
        stdout.fileno.return_value = 1
        with mock.patch.object(SUPERVISOR.sys, "stdin", stdin), \
                mock.patch.object(SUPERVISOR.sys, "stdout", stdout), \
                mock.patch.object(SUPERVISOR.os, "isatty", return_value=True), \
                mock.patch.object(SUPERVISOR.termios, "tcsetattr") as tcsetattr, \
                mock.patch.object(SUPERVISOR.os, "write",
                                  side_effect=lambda fd, data: written.append(data)):
            self.assertTrue(SUPERVISOR._restore_interactive_terminal("saved"))
        tcsetattr.assert_called_once_with(
            0, SUPERVISOR.termios.TCSADRAIN, "saved")
        payload = written[0].decode("ascii")
        for sequence in ("\x1b[?1003l", "\x1b[?1006l", "\x1b[?2004l",
                         "\x1b[?1049l", "\x1b[?25h"):
            self.assertIn(sequence, payload)

    def test_restore_interactive_terminal_skips_non_terminals(self):
        stdin = mock.Mock()
        stdin.fileno.return_value = 0
        with mock.patch.object(SUPERVISOR.sys, "stdin", stdin), \
                mock.patch.object(SUPERVISOR.os, "isatty", return_value=False):
            self.assertFalse(SUPERVISOR._restore_interactive_terminal(None))

    def test_chat_restores_the_terminal_after_the_recorder_exits(self):
        args = argparse.Namespace(**vars(self.args), command="talk", target="data")
        with mock.patch.object(SUPERVISOR, "_require_foreground_terminal"), \
                mock.patch.object(SUPERVISOR.Supervisor, "interactive_command",
                                  return_value=("data", ["claude"])), \
                mock.patch.object(SUPERVISOR, "interactive_recording_command",
                                  return_value=["/usr/bin/true"]), \
                mock.patch.object(SUPERVISOR, "_capture_terminal_state",
                                  return_value="saved-state"), \
                mock.patch.object(SUPERVISOR, "_restore_interactive_terminal") as restore, \
                mock.patch.object(SUPERVISOR.subprocess, "call",
                                  return_value=0), \
                mock.patch.object(SUPERVISOR.os, "ttyname", side_effect=OSError):
            self.assertEqual(SUPERVISOR.chat(args), 0)
        restore.assert_called_once_with("saved-state")

    def test_chat_restores_the_terminal_when_the_recorder_is_killed(self):
        args = argparse.Namespace(**vars(self.args), command="talk", target="data")
        with mock.patch.object(SUPERVISOR, "_require_foreground_terminal"), \
                mock.patch.object(SUPERVISOR.Supervisor, "interactive_command",
                                  return_value=("data", ["claude"])), \
                mock.patch.object(SUPERVISOR, "interactive_recording_command",
                                  return_value=["/usr/bin/true"]), \
                mock.patch.object(SUPERVISOR, "_capture_terminal_state",
                                  return_value="saved-state"), \
                mock.patch.object(SUPERVISOR, "_restore_interactive_terminal") as restore, \
                mock.patch.object(SUPERVISOR.subprocess, "call",
                                  side_effect=KeyboardInterrupt), \
                mock.patch.object(SUPERVISOR.os, "ttyname", side_effect=OSError):
            with self.assertRaises(KeyboardInterrupt):
                SUPERVISOR.chat(args)
        restore.assert_called_once_with("saved-state")

    def test_talk_termination_targets_verified_terminal_recorder(self):
        supervisor = self.supervisor()
        session = {
            "agent": "data", "pid": 4242,
            "log": "/tmp/data-talk.jsonl",
        }
        pgrep = subprocess.CompletedProcess(
            ["pgrep"], 0, stdout="4343\n", stderr="")
        ps = subprocess.CompletedProcess(
            ["ps"], 0,
            stdout=" 4242 /usr/bin/script -q -F /tmp/data-talk.jsonl codex\n",
            stderr="",
        )
        with mock.patch.object(SUPERVISOR, "_pid_alive", return_value=True), \
                mock.patch.object(SUPERVISOR.subprocess, "run",
                                  side_effect=[pgrep, ps]), \
                mock.patch.object(SUPERVISOR.os, "kill") as kill:
            self.assertTrue(supervisor.terminate_interactive_session(
                "data", session))
        kill.assert_called_once_with(4343, SUPERVISOR.signal.SIGTERM)

    def test_usage_notice_leaves_the_decision_to_the_project_lead(self):
        supervisor = self.supervisor()
        snapshot = {
            "provider": "codex", "checked_at": "2026-08-23T20:00:00+00:00",
            "windows": [{"label": "7d", "used_percent": 95,
                         "remaining_percent": 5}],
        }
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            self.assertTrue(supervisor.notify_project_leader_about_usage(
                "codex", snapshot))
        subject, body = send.call_args.args[1:3]
        self.assertIn("5% remaining", subject)
        self.assertIn("As Project Lead, decide", body)
        self.assertIn("will not hold or redirect turns", body)

    def _usage_state(self, supervisor, **remaining_by_provider):
        usage = supervisor.state.setdefault("usage", {})
        for provider, remaining in remaining_by_provider.items():
            usage[provider] = {"provider": provider, "windows": [
                {"label": "7d", "remaining_percent": remaining}]}
        return usage

    def test_usage_notice_names_the_healthiest_peer_lead(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, codex=80, claude=55, cursor=30)
        snapshot = {"provider": "agy", "checked_at": "2026-08-26T20:00:00+00:00",
                    "windows": [{"label": "5h", "remaining_percent": 8}]}
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            self.assertTrue(supervisor.notify_project_leader_about_usage(
                "agy", snapshot))
        body = send.call_args.args[2]
        self.assertIn("cross-provider delegate", body)
        self.assertIn("'jean-luc' (codex, 80% left)", body)

    def test_blackout_mandate_prefers_the_announced_cross_provider_delegate(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, codex=80, claude=55)
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "roster.json").write_text(json.dumps({
            "jadzia": {"status": "standby", "delegate": "kathryn"},
        }), encoding="utf-8")
        entry = {"provider": "agy", "windows": [
            {"label": "5h", "remaining_percent": 0.0}]}
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_blackout("agy", entry)
            supervisor.notify_blackout("agy", entry)  # flagged: mandate once
        self.assertEqual(send.call_count, 1)
        recipient, subject, body = send.call_args.args[:3]
        self.assertEqual(recipient, "kathryn")
        self.assertIn("BLACKOUT agy", subject)
        self.assertIn("takeover authority", body)
        self.assertIn("DeepSpace9", body)
        self.assertTrue(entry["blackout_notified_at"])

    def test_blackout_falls_back_to_healthiest_peer_and_clears_on_recovery(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, codex=12, claude=70)
        entry = {"provider": "agy", "windows": [
            {"label": "5h", "remaining_percent": 0.5}]}
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_blackout("agy", entry)
        self.assertEqual(send.call_args.args[0], "kathryn")  # claude, 70%
        entry["windows"][0]["remaining_percent"] = 40
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_blackout("agy", entry)
        recipient, subject = send.call_args.args[:2]
        self.assertEqual(recipient, "jadzia")
        self.assertIn("recovered", subject)
        self.assertNotIn("blackout_notified_at", entry)

    def test_health_checks_exhausted_and_stale_standby_once(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, cursor=62, agy=5)
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "roster.json").write_text(json.dumps({
            "hugh": {"status": "exhausted", "delegate": "michael",
                     "status_since": "2026-08-26T17:28:13Z"},
            "paul": {"status": "standby", "delegate": "michael",
                     "status_since": "2026-08-26T17:00:00Z"},
            "jadzia": {"status": "exhausted", "delegate": "kathryn",
                         "status_since": "2026-08-26T17:00:00Z"},
        }), encoding="utf-8")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_implausible_standby()
            supervisor.nudge_implausible_standby()  # same announcement: once
        # benjamin: agy really is depleted; the other two need one check each.
        self.assertEqual(send.call_count, 2)
        calls = {call.args[0]: call.args[1:3]
                 for call in send.call_args_list}
        self.assertEqual(set(calls), {"hugh", "paul"})
        self.assertIn("quota left", calls["hugh"][0])
        self.assertIn("confirm your global hold", calls["paul"][0])
        for _subject, body in calls.values():
            self.assertIn("announce 'idle'", body)
            self.assertIn("'standby'", body)

    def test_exhausted_nudge_repeats_per_announcement_and_clears_on_idle(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, cursor=62)
        (self.store / "data").mkdir(parents=True)
        roster = self.store / "data" / "roster.json"
        entry = {"status": "exhausted", "delegate": "michael",
                 "status_since": "2026-08-26T17:28:13Z"}
        roster.write_text(json.dumps({"hugh": entry}), encoding="utf-8")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_implausible_standby()
            entry["status_since"] = "2026-08-26T18:00:00Z"
            roster.write_text(json.dumps({"hugh": entry}), encoding="utf-8")
            supervisor.nudge_implausible_standby()
        self.assertEqual(send.call_count, 2)
        roster.write_text(json.dumps({
            "hugh": {"status": "idle"}}), encoding="utf-8")
        supervisor.nudge_implausible_standby()
        self.assertNotIn("hugh", supervisor.state.get("standby_nudges", {}))

    def test_stale_standby_is_nudged_for_every_role(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, agy=74)
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "roster.json").write_text(json.dumps({
            "jadzia": {"status": "standby", "delegate": "data",
                       "status_since": "2026-08-27T10:00:00Z"},
            "obrien": {"status": "standby", "delegate": "benjamin",
                       "status_since": "2026-08-27T10:00:00Z"},
        }), encoding="utf-8")
        with mock.patch.object(SUPERVISOR.time, "time", return_value=SUPERVISOR.iso_to_epoch(
                "2026-08-27T12:00:01Z")), mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_implausible_standby()
            supervisor.nudge_implausible_standby()
        self.assertEqual(send.call_count, 2)
        self.assertEqual({call.args[0] for call in send.call_args_list},
                         {"jadzia", "obrien"})
        for call in send.call_args_list:
            _recipient, subject, body = call.args[:3]
            self.assertIn("confirm your global hold", subject)
            self.assertIn("task-local", body)
            self.assertIn("announce 'idle'", body)

    def test_recent_standby_is_not_nudged(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, agy=74)
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "roster.json").write_text(json.dumps({
            "jadzia": {"status": "standby", "delegate": "data",
                       "status_since": "2026-08-27T11:30:00Z"},
        }), encoding="utf-8")
        with mock.patch.object(SUPERVISOR.time, "time", return_value=SUPERVISOR.iso_to_epoch(
                "2026-08-27T12:00:00Z")), mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_implausible_standby()
        send.assert_not_called()

    def test_quota_recovery_notifies_past_exhausted_even_after_idle(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, agy=5)
        (self.store / "data").mkdir(parents=True)
        roster = self.store / "data" / "roster.json"
        roster.write_text(json.dumps({
            "jadzia": {"status": "exhausted", "delegate": "kathryn",
                         "status_since": "2026-08-27T00:30:39Z"},
        }), encoding="utf-8")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_quota_recovery()  # quota low: remember, no mail
        self.assertEqual(send.call_count, 0)
        # the announcer bounced back to idle via a restart, then quota returned
        roster.write_text(json.dumps({
            "jadzia": {"status": "idle",
                         "status_since": "2026-08-27T10:02:34Z"},
        }), encoding="utf-8")
        self._usage_state(supervisor, agy=74)
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_quota_recovery()
            supervisor.notify_quota_recovery()  # memory cleared: mail once
        self.assertEqual(send.call_count, 1)
        recipient, subject, body = send.call_args.args[:3]
        self.assertEqual(recipient, "jadzia")
        self.assertIn("Quota recovered: agy", subject)
        self.assertIn("rescind", body)
        self.assertIn("re-announce", body)

    def test_quota_recovery_remembers_legacy_standby_for_every_role(self):
        supervisor = self.supervisor()
        self._usage_state(supervisor, agy=5)
        (self.store / "data").mkdir(parents=True)
        roster = self.store / "data" / "roster.json"
        roster.write_text(json.dumps({
            "jadzia": {"status": "standby", "delegate": "data",
                       "status_since": "2026-08-27T10:00:00Z"},
            "obrien": {"status": "standby", "delegate": "benjamin",
                       "status_since": "2026-08-27T10:00:00Z"},
        }), encoding="utf-8")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_quota_recovery()
        send.assert_not_called()
        self._usage_state(supervisor, agy=74)
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.notify_quota_recovery()
        self.assertEqual(
            {call.args[0] for call in send.call_args_list},
            {"jadzia", "obrien"},
        )
        self.assertTrue(all("task-local" in call.args[2]
                            for call in send.call_args_list))

    def test_usage_is_a_supported_command(self):
        self.assertEqual(
            SUPERVISOR.build_parser().parse_args(["usage"]).command, "usage")

    def test_usage_notification_uses_canonical_mailbox_store(self):
        supervisor = self.supervisor()
        self.assertTrue(supervisor.send_supervisor_message(
            "jean-luc", "Usage warning", "14% remaining", "supervisor-usage-codex"))
        journal = self.store / "data/messages.jsonl"
        records = [json.loads(line) for line in journal.read_text().splitlines()]
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["sender"], "supervisor")
        self.assertEqual(records[0]["to"], "jean-luc")
        mailbox = self.store / "data/mailboxes/jean-luc.jsonl"
        self.assertIn(records[0]["id"], mailbox.read_text())

    def test_usage_notice_skips_a_retired_project_lead(self):
        supervisor = self.supervisor()
        retired = self.store / "data" / "retired.json"
        retired.parent.mkdir(parents=True, exist_ok=True)
        retired.write_text(json.dumps({"jadzia": {"agent": "jadzia"}}))
        snapshot = {
            "provider": "agy", "checked_at": "2026-08-26T12:00:00+00:00",
            "windows": [{"label": "5h", "used_percent": 0, "remaining_percent": 100}],
        }
        err = io.StringIO()
        with mock.patch.object(supervisor, "send_supervisor_message") as send, \
                mock.patch("sys.stderr", err):
            self.assertFalse(supervisor.notify_project_leader_about_usage(
                "agy", snapshot))
        send.assert_not_called()
        self.assertIn("Project Lead jadzia is retired", err.getvalue())
        self.assertNotIn("Traceback", err.getvalue())

    def test_supervisor_message_to_retired_agent_is_one_line(self):
        supervisor = self.supervisor()
        retired = self.store / "data" / "retired.json"
        retired.parent.mkdir(parents=True, exist_ok=True)
        retired.write_text(json.dumps({"benjamin": {"agent": "benjamin"}}))
        err = io.StringIO()
        with mock.patch("sys.stderr", err):
            self.assertFalse(supervisor.send_supervisor_message(
                "benjamin", "Provider usage agy", "100% remaining",
                "supervisor-usage-agy"))
        text = err.getvalue()
        self.assertIn("recipient 'benjamin' is retired", text)
        self.assertNotIn("Traceback", text)

    def test_reactivate_roster_identities_restores_crew_and_keeps_aliases(self):
        supervisor = self.supervisor()
        retired = self.store / "data" / "retired.json"
        retired.parent.mkdir(parents=True, exist_ok=True)
        retired.write_text(json.dumps({
            "benjamin": {"agent": "benjamin", "retired_at": "2026-08-26T02:41:51Z"},
            "riker": {"agent": "riker", "retired_at": "2026-08-24T09:20:18Z"},
        }))
        restored = supervisor.reactivate_roster_identities()
        self.assertEqual(restored, ["benjamin"])
        remaining = json.loads(retired.read_text())
        self.assertNotIn("benjamin", remaining)
        self.assertIn("riker", remaining)
        self.assertNotIn("benjamin", supervisor.retired_identities())

    def test_run_once_and_restart_reactivate_roster_identities(self):
        source = (HERE / "supervisor.py").read_text()
        self.assertIn(
            'if requested_command in ("run", "once", "restart"):',
            source,
        )
        self.assertIn("supervisor.reactivate_roster_identities()", source)
        self.assertLess(
            source.index("supervisor = Supervisor(args)"),
            source.index("supervisor.reactivate_roster_identities()"),
        )

    def test_ping_queues_standard_ackable_wake(self):
        args = argparse.Namespace(
            **vars(self.args), command="ping", target="DATA", message=None,
        )
        output = io.StringIO()
        with mock.patch("sys.stdout", output):
            self.assertEqual(SUPERVISOR.manual_message(args), 0)
        records = [
            json.loads(line) for line in
            (self.store / "data/messages.jsonl").read_text().splitlines()
        ]
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["sender"], "supervisor")
        self.assertEqual(records[0]["to"], "data")
        self.assertEqual(records[0]["subject"], "Manual wake-up")
        self.assertIn("acknowledge this ping", records[0]["body"])
        self.assertIn("wake deferred", output.getvalue())

    def test_mail_prompts_without_message_and_send_is_an_alias(self):
        for command, body in (("mail", "interactive body"),
                              ("send", "command-line body")):
            args = argparse.Namespace(
                **vars(self.args), command=command, target="data",
                message=None if command == "mail" else body,
            )
            with mock.patch.object(
                    SUPERVISOR, "_require_foreground_terminal"), \
                    mock.patch("builtins.input", return_value=body):
                self.assertEqual(SUPERVISOR.manual_message(args), 0)
        records = [
            json.loads(line) for line in
            (self.store / "data/messages.jsonl").read_text().splitlines()
        ]
        self.assertEqual([record["body"] for record in records], [
            "interactive body", "command-line body",
        ])
        self.assertTrue(all(
            record["subject"] == "Manual message" for record in records))

    def test_ping_mail_and_send_parser_forms(self):
        parser = SUPERVISOR.build_parser()
        ping = parser.parse_args(["ping", "data"])
        mail = parser.parse_args(["mail", "data"])
        send = parser.parse_args(["send", "data", "-m", "hello"])
        self.assertIsNone(ping.message)
        self.assertIsNone(mail.message)
        self.assertEqual(send.message, "hello")

    def test_foreground_commands_require_a_tty(self):
        fake = mock.Mock()
        fake.isatty.return_value = False
        with mock.patch.object(SUPERVISOR.sys, "stdin", fake), \
             mock.patch.object(SUPERVISOR.sys, "stdout", fake):
            with self.assertRaisesRegex(RuntimeError, "interactive foreground terminal"):
                SUPERVISOR._require_foreground_terminal("run")

    def test_shell_background_process_group_is_rejected(self):
        stdin = mock.Mock()
        stdout = mock.Mock()
        stdin.isatty.return_value = True
        stdout.isatty.return_value = True
        stdin.fileno.return_value = 0
        with mock.patch.object(SUPERVISOR.sys, "stdin", stdin), \
             mock.patch.object(SUPERVISOR.sys, "stdout", stdout), \
             mock.patch.object(SUPERVISOR.os, "tcgetpgrp", return_value=100), \
             mock.patch.object(SUPERVISOR.os, "getpgrp", return_value=200):
            with self.assertRaisesRegex(RuntimeError, "foreground process group"):
                SUPERVISOR._require_foreground_terminal("run")

    def test_only_ttyless_live_instance_is_classified_as_background(self):
        self.assertTrue(SUPERVISOR._background_instance(
            {"alive": True, "actual_tty": "??"}))
        self.assertFalse(SUPERVISOR._background_instance(
            {"alive": True, "actual_tty": "ttys004"}))
        self.assertFalse(SUPERVISOR._background_instance(
            {"alive": False, "actual_tty": ""}))

    def test_stop_removes_only_a_stale_pid_file(self):
        pid_file = self.state / "pid.json"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text(json.dumps({"pid": 99999999, "mode": "run"}))
        self.assertEqual(SUPERVISOR.stop(self.args), 0)
        self.assertFalse(pid_file.exists())

    def test_stop_never_signals_a_recycled_pid(self):
        pid_file = self.state / "pid.json"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text(json.dumps({
            "pid": 4242, "mode": "run",
            "proc_started": "Mon Aug 24 20:00:00 2026",
        }))
        output = io.StringIO()
        with mock.patch.object(SUPERVISOR, "_pid_alive", return_value=True), \
                mock.patch.object(SUPERVISOR, "_process_start_time",
                                  return_value="Tue Aug 25 01:29:40 2026"), \
                mock.patch.object(SUPERVISOR, "_terminate_and_wait") as terminate, \
                mock.patch("sys.stdout", output):
            self.assertEqual(SUPERVISOR.stop(self.args), 0)
        terminate.assert_not_called()
        self.assertFalse(pid_file.exists())
        self.assertIn("unrelated process", output.getvalue())

    def test_matching_start_time_is_recognized_as_the_supervisor(self):
        info = {"proc_started": "Tue Aug 25 00:51:51 2026"}
        with mock.patch.object(SUPERVISOR, "_pid_alive", return_value=True), \
                mock.patch.object(SUPERVISOR, "_process_start_time",
                                  return_value="Tue Aug 25 00:51:51 2026"):
            self.assertTrue(SUPERVISOR._instance_identity_matches(info, 4242))

    def test_legacy_pid_file_accepts_only_daemon_command_lines(self):
        legacy = {}
        with mock.patch.object(SUPERVISOR, "_pid_alive", return_value=True), \
                mock.patch.object(SUPERVISOR, "_process_start_time",
                                  return_value=""):
            for command, expected in (
                ("/usr/bin/python3 ./supervisor.py run", True),
                ("/usr/bin/python3 ./supervisor.py restart --yolo", True),
                ("/usr/bin/python3 ./supervisor.py observe jean-luc", False),
                ("/usr/bin/python3 ./supervisor.py talk data", False),
                ("/usr/bin/python3 unrelated.py run", False),
                ("", False),
            ):
                with mock.patch.object(SUPERVISOR, "_process_command",
                                       return_value=command):
                    self.assertEqual(
                        SUPERVISOR._instance_identity_matches(legacy, 4242),
                        expected, command)

    def test_instance_metadata_records_the_process_start_time(self):
        with mock.patch.object(SUPERVISOR, "_process_start_time",
                               return_value="Tue Aug 25 00:51:51 2026"), \
                mock.patch.object(SUPERVISOR.os, "ttyname",
                                  side_effect=OSError):
            SUPERVISOR._write_instance_metadata(self.args, "run")
        info = json.loads((self.state / "pid.json").read_text())
        self.assertEqual(info["proc_started"], "Tue Aug 25 00:51:51 2026")
        self.assertEqual(info["pid"], SUPERVISOR.os.getpid())

    def test_stop_gracefully_terminates_a_foreground_supervisor(self):
        with mock.patch.object(SUPERVISOR, "_instance_info", return_value={
            "pid": 42, "alive": True, "actual_tty": "ttys004", "mode": "run"
        }), mock.patch.object(
            SUPERVISOR, "_terminate_and_wait", return_value=True
        ) as terminate:
            self.assertEqual(SUPERVISOR.stop(self.args), 0)
        terminate.assert_called_once_with(42)

    def test_reload_signals_supervisor_and_waits_for_new_profile_generation(self):
        self.state.mkdir(parents=True)
        SUPERVISOR.atomic_json(self.state / SUPERVISOR.PROFILE_GENERATION_FILE, {
            "generation": "old",
        })

        def acknowledge(_pid, sent_signal):
            self.assertEqual(sent_signal, SUPERVISOR.signal.SIGHUP)
            SUPERVISOR.atomic_json(self.state / SUPERVISOR.PROFILE_GENERATION_FILE, {
                "generation": "new",
            })

        with mock.patch.object(SUPERVISOR, "_instance_info", return_value={
            "pid": 43, "alive": True, "actual_tty": "ttys004", "mode": "run"
        }), mock.patch.object(SUPERVISOR.os, "kill", side_effect=acknowledge):
            self.assertEqual(SUPERVISOR.reload_supervisor(self.args), 0)

    def test_restart_and_reload_are_supported_commands(self):
        self.assertEqual(SUPERVISOR.build_parser().parse_args(["restart"]).command, "restart")
        self.assertEqual(SUPERVISOR.build_parser().parse_args(["reload"]).command, "reload")
        self.assertEqual(
            SUPERVISOR.build_parser().parse_args(["setup-cli"]).command, "setup-cli")

    def test_foreground_instance_must_be_stopped_with_ctrl_c(self):
        handle = mock.Mock()
        with mock.patch.object(SUPERVISOR, "_open_lock", return_value=handle), \
             mock.patch.object(SUPERVISOR, "_try_lock", return_value=False), \
             mock.patch.object(SUPERVISOR, "_instance_info", return_value={
                 "pid": 42, "alive": True, "actual_tty": "ttys004", "mode": "run"
             }), \
             mock.patch.object(SUPERVISOR, "_terminate_and_wait") as terminate:
            with self.assertRaisesRegex(RuntimeError, "Press Ctrl\\+C"):
                SUPERVISOR.acquire_lock(self.args, "run")
        terminate.assert_not_called()
        handle.close.assert_called_once()

    def test_background_instance_is_replaced_only_after_confirmation(self):
        first = mock.Mock()
        second = mock.Mock()
        with mock.patch.object(SUPERVISOR, "_open_lock", side_effect=[first, second]), \
             mock.patch.object(SUPERVISOR, "_try_lock", side_effect=[False, True]), \
             mock.patch.object(SUPERVISOR, "_instance_info", return_value={
                 "pid": 43, "alive": True, "actual_tty": "??", "mode": "run"
             }), \
             mock.patch.object(SUPERVISOR, "_terminate_and_wait", return_value=True) as terminate, \
             mock.patch("builtins.input", return_value="y"):
            lock = SUPERVISOR.acquire_lock(self.args, "run")
        self.assertIs(lock, second)
        terminate.assert_called_once_with(43)
        first.close.assert_called_once()

    def test_reap_keeps_codex_thread_id_after_interrupted_turn(self):
        supervisor = self.supervisor()
        log_path = Path(self.tmp.name) / "worker.jsonl"
        log_path.write_text(
            "Reading additional input from stdin...\n"
            + json.dumps({
                "type": "thread.started",
                "thread_id": "33333333-3333-3333-3333-333333333333",
            }) + "\n"
        )

        class Process:
            pid = 12345
            def poll(self):
                return 130

        log = mock.Mock()
        supervisor.processes["data"] = {
            "process": Process(), "log": log, "path": log_path,
            "runtime": "codex", "signature": "message-id",
        }
        supervisor.reap()
        self.assertEqual(
            supervisor.agent_state("data")["thread_id"],
            "33333333-3333-3333-3333-333333333333",
        )
        log.close.assert_called_once()


class RosterV2AndGenerationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.roster = SUPERVISOR.load_roster(HERE / "agents.json")
        self.roots = {
            "codex": self.root / "codex", "claude": self.root / "claude",
            "agy": self.root / "agy", "cursor": self.root / "cursor",
            "grok": self.root / "grok",
        }

    def tearDown(self):
        self.tmp.cleanup()

    def test_complete_teams_and_role_policy(self):
        self.assertEqual(len(self.roster["agents"]), 50)
        self.assertEqual({k: len(v["members"]) for k, v in self.roster["teams"].items()},
                         {"Voyager": 10, "Enterprise": 10, "DeepSpace9": 10,
                          "Discovery": 10, "yrevocsiD": 10})
        self.assertEqual(self.roster["agents"]["worf"]["team"], "DeepSpace9")
        self.assertEqual(self.roster["agents"]["worf"]["role"], "Dispatcher")
        self.assertEqual(self.roster["agents"]["benjamin"]["role"], "Dispatcher")
        self.assertEqual(self.roster["agents"]["jadzia"]["role"], "Project Lead")
        self.assertEqual(self.roster["agents"]["kira"]["role"], "Architect")
        self.assertEqual(self.roster["agents"]["tom"]["role"], "Dispatcher")
        self.assertEqual(self.roster["agents"]["data"]["role"], "Architect")
        self.assertEqual(self.roster["agents"]["michael"]["role"], "Project Lead")
        self.assertEqual(self.roster["agents"]["gabriel"]["role"], "Dispatcher")
        self.assertEqual(self.roster["agents"]["philippa"]["role"], "Dispatcher")
        self.assertEqual(self.roster["agents"]["saru"]["role"], "Architect")
        self.assertEqual(self.roster["agents"]["paul"]["role"], "Integrator")
        self.assertEqual(self.roster["agents"]["ellen"]["role"], "Security Engineer")
        self.assertEqual(self.roster["agents"]["sylvia"]["role"], "QA-Manager")
        self.assertEqual(self.roster["agents"]["ash"]["role"], "Runner")
        self.assertEqual(self.roster["agents"]["leahcim"]["role"], "Project Lead")
        self.assertEqual(self.roster["agents"]["leahcim"]["team"], "yrevocsiD")
        self.assertEqual(self.roster["agents"]["leahcim"]["provider"], "grok")
        self.assertEqual(self.roster["agents"]["leahcim"]["display_name"], "Michael Burnham (mirror)")
        self.assertEqual(
            self.roster["agents"]["leahcim"]["personality"],
            self.roster["agents"]["michael"]["personality"],
        )
        for role in ("Architect", "Security Engineer"):
            self.assertEqual(self.roster["role_policy"][role]["effort"], "high")
        self.assertIn("Project Lead", self.roster["role_policy"])
        self.assertIn("Process Optimizer", self.roster["role_policy"])
        self.assertEqual(self.roster["role_policy"]["Process Optimizer"]["capability_class"], "unprivileged")
        self.assertFalse(any(agent["role"] == "Process Optimizer" for agent in self.roster["agents"].values()))
        self.assertNotIn("Projektleiter", self.roster["role_policy"])
        self.assertEqual(self.roster["agents"]["jean-luc"]["role"], "Project Lead")
        self.assertEqual(self.roster["role_policy"]["Runner"]["capability_class"], "runner")
        # The runner invocation contract is defined: mail-woken sessions that
        # serve typed dispatch briefings. No deferral marker remains.
        self.assertNotIn("invocation_defined", self.roster["capability_sets"]["runner"])
        self.assertIn("Invocation contract", self.roster["capability_sets"]["runner"]["description"])
        self.assertLessEqual(set(self.roster["predefined_capability_sets"]), set(self.roster["capability_sets"]))
        self.assertEqual(set(self.roster["capabilities"]), {
            "repository-sandbox", "direct-local-execution",
            "privileged-integration-review", "foreground-long-running-process",
            "spawn-subagents", "agent-inbox", "edit-local", "shell-exec",
            "git-commit", "edit-canonical-worktree", "ticket-redo",
            "ticket-start", "ticket-accept", "delegate-task",
        })
        self.assertIn("privileged-integration-review", self.roster["capability_sets"]["privileged"]["capabilities"])
        self.assertIn("inert without that assignment", self.roster["capabilities"]["privileged-integration-review"]["description"])
        self.assertIn("explicit current bounded waiver", self.roster["capabilities"]["privileged-integration-review"]["description"])
        self.assertIn("active repository-selected", self.roster["capabilities"]["repository-sandbox"]["description"])
        self.assertIn("DECISION NEEDED", self.roster["coordination_policy"]["decision_request_format"])
        self.assertIn("through decision_request", self.roster["coordination_policy"]["project_lead_escalation"])
        self.assertIn("Only tool success creates the request", self.roster["coordination_policy"]["decision_request_format"])
        self.assertIn("call decision_request", self.roster["coordination_policy"]["decision_request_agent_notice"])
        self.assertIn("assignment-state-machine.json", self.roster["coordination_policy"]["assignment_lifecycle"])
        self.assertIn("begins submitted", self.roster["coordination_policy"]["assignment_lifecycle"])
        self.assertIn("ACCEPT means awarded", self.roster["coordination_policy"]["assignment_lifecycle"])
        self.assertIn("direct current-user or registered-authority instructions remain effective", self.roster["coordination_policy"]["management_routing"])
        self.assertIn("If no Project Lead is assigned or reachable", self.roster["coordination_policy"]["management_routing"])
        self.assertNotIn("Implementer", self.roster["terminology"]["obsolete"])
        self.assertNotIn("Architekt", self.roster["terminology"]["obsolete"])
        self.assertEqual(self.roster["terminology"]["autodocs_mapping"]["Programmer"], "Implementer")
        self.assertIn("autodocs/docs/pipeline/process-roles.md", self.roster["default_derivation"]["authoritative_sources"])
        self.assertIn("do not claim", self.roster["default_derivation"]["aspice_boundary"])
        architect = self.roster["role_policy"]["Architect"]["behavioral_patterns"]
        self.assertIn("configured Architect is already Management-instantiated", architect)
        self.assertIn("Project Lead may assign bounded architecture", architect)
        self.assertIn("exactly one terminal integrating Task", architect)
        self.assertIn("Integration review: mandatory", architect)
        self.assertIn("do not directly advance the Feature branch", architect)
        offer = self.roster["coordination_policy"]["offer_protocol"]
        self.assertIn("task-local and never justifies global standby", offer)
        self.assertIn("first ACCEPT", offer)
        self.assertIn("lower tiers", offer)
        self.assertIn("one item/chain may have only one open round", offer)
        self.assertIn("ack that exact message id", self.roster["coordination_policy"]["mail_handling"])
        self.assertIn("caveman style", self.roster["coordination_policy"]["peer_mail_style"])
        self.assertIn("concurrent holders", self.roster["coordination_policy"]["role_multiplicity"])
        optimizer = self.roster["role_policy"]["Process Optimizer"]["behavioral_patterns"]
        self.assertIn("separately claimed Task and Implementer scope", optimizer)
        self.assertIn("grants no write", optimizer)
        self.assertTrue(all(policy["behavioral_patterns"].strip()
                            for policy in self.roster["role_policy"].values()))

    def test_agy_model_family_combines_with_role_effort_without_exception(self):
        self.assertEqual(SUPERVISOR.resolved_model(self.roster, self.roster["agents"]["benjamin"]), "gemini-3.7-flash-low")
        self.assertEqual(SUPERVISOR.resolved_model(self.roster, self.roster["agents"]["worf"]), "gemini-3.7-flash-low")
        self.assertEqual(SUPERVISOR.resolved_model(self.roster, self.roster["agents"]["jake"]), "gemini-3.7-flash-medium")

    def test_codex_coder_tier_uses_catalog_model_slug(self):
        self.assertEqual(
            self.roster["providers"]["codex"]["tiers"]["coder"],
            "gpt-daybreak-blue-latest",
        )

    def test_cursor_model_tiers_use_installed_catalog_slugs(self):
        provider = self.roster["providers"]["cursor"]
        self.assertEqual(provider["tiers"]["frontier"], "cursor-grok-4.6")
        self.assertEqual(provider["tiers"]["budget"], "cursor-grok-4.6")
        self.assertEqual(
            SUPERVISOR.resolved_model(self.roster, self.roster["agents"]["michael"]),
            "cursor-grok-4.6-high",
        )

    def test_grok_model_tiers_use_installed_catalog_slugs(self):
        provider = self.roster["providers"]["grok"]
        self.assertEqual(provider["tiers"]["frontier"], "grok-4.6")
        self.assertEqual(provider["tiers"]["budget"], "grok-4.5")
        self.assertEqual(
            SUPERVISOR.resolved_model(self.roster, self.roster["agents"]["leahcim"]),
            "grok-4.6",
        )

    def test_generation_is_deterministic_and_check_only_reports_drift(self):
        from profile_generator import generate
        changed = generate(HERE / "agents.json", self.roots)
        self.assertEqual(len(changed), 50)
        self.assertEqual(generate(HERE / "agents.json", self.roots, check=True), [])
        target = self.roots["codex"] / "data.config.toml"
        target.write_text("drift")
        self.assertEqual(generate(HERE / "agents.json", self.roots, check=True), [str(target)])
        self.assertEqual(target.read_text(), "drift")
        generate(HERE / "agents.json", self.roots)
        self.assertIn("developer_instructions", target.read_text())
        self.assertTrue((self.roots["agy"] / "worf" / "agent.md").is_file())
        self.assertTrue((self.roots["cursor"] / "michael.md").is_file())
        self.assertTrue((self.roots["grok"] / "leahcim.md").is_file())

    def test_generated_personality_and_governance_are_native(self):
        from profile_generator import generate
        generate(HERE / "agents.json", self.roots)
        codex = (self.roots["codex"] / "lore.config.toml").read_text()
        project_lead = (self.roots["codex"] / "jean-luc.config.toml").read_text()
        claude = (self.roots["claude"] / "seven.md").read_text()
        agy = (self.roots["agy"] / "odo" / "agent.md").read_text()
        architect = (self.roots["agy"] / "kira" / "agent.md").read_text()
        dispatcher = (self.roots["agy"] / "worf" / "agent.md").read_text()
        ds9_lead = (self.roots["agy"] / "jadzia" / "agent.md").read_text()
        cursor = (self.roots["cursor"] / "paul.md").read_text()
        grok = (self.roots["grok"] / "luap.md").read_text()
        self.assertTrue(claude.startswith("---\n"))
        self.assertTrue(agy.startswith("---\n"))
        self.assertIn("# System Prompt", agy)
        self.assertIn("commandExecutionPolicy: eager", agy)
        self.assertIn("  - run_command\n", agy)
        self.assertIn("  - view_file\n", agy)
        self.assertIn("inheritMcp: true", agy)
        for banned in (
            "sed_file", "command_status", "send_command_input",
            "call_mcp_tool", "multi_replace_file_content",
        ):
            self.assertNotIn(f"  - {banned}\n", agy)
        self.assertTrue(cursor.startswith("---\n"))
        self.assertIn("name: paul", cursor)
        self.assertIn("model: cursor-grok-4.6-high", cursor)
        self.assertNotIn("prompt_mode:", cursor)
        self.assertNotIn("mcpInheritance:", cursor)
        self.assertTrue(grok.startswith("---\n"))
        self.assertIn("name: luap", grok)
        self.assertIn("model: grok-4.6", grok)
        self.assertIn("prompt_mode: full", grok)
        self.assertIn("mcpInheritance: all", grok)
        self.assertIn("refresh otherwise-fit stale/standby candidates", project_lead)
        self.assertIn("configured Architect is already Management-instantiated", architect)
        self.assertIn("Same-role peers in this team: `benjamin`", dispatcher)
        self.assertIn("atomic AWARD", dispatcher)
        self.assertIn("Team Integrator candidates: `obrien`", ds9_lead)
        self.assertIn("Role multiplicity:", ds9_lead)
        for text in (codex, claude, agy, cursor, grok):
            self.assertIn("TEAM COLLABORATION & ROSTER DIRECTORY", text)
            self.assertIn("docs/pipeline/agent-roster.md", text)
            self.assertIn("Prefer collaborating with and delegating to peers from your own team", text)
            self.assertIn("NORMATIVE PROCESS GUIDE", text)
            self.assertIn("docs/pipeline/roles/", text)
            self.assertIn("docs/pipeline/core-rules.md", text)
            self.assertIn("ROLE DEFAULT", text)
            self.assertIn("PERSONA PRACTICE", text)
            self.assertIn("CAPABILITY", text)
            self.assertIn("VOICE", text)
            self.assertIn("GOVERNANCE — OVERRIDES PERSONA", text)
            self.assertIn("MEMORY GOVERNANCE", text)
            self.assertIn("Partitioned Memory Scopes & Limits:", text)
            self.assertIn("Agent Memory:", text)
            self.assertIn("Role Memory:", text)
            self.assertIn("Capability Memory:", text)
            self.assertIn("Feature Memory:", text)
            self.assertIn("logs/agent-memory/", text)
            self.assertNotIn("`.memory/", text)
            self.assertIn("memory_store.py read --agent", text)
            self.assertIn("memory_store.py append --agent", text)
            self.assertIn("standing incidental permission", text)
            self.assertIn("blockers are task-local", text)
            self.assertIn("Do not edit shared memory files directly", text)
            self.assertIn("Acceptance", text)
            self.assertIn("Route new human decision requests through the assigned Project Lead when reachable", text)
            self.assertNotIn("PROFILE ROLE: Commander", text)

    def test_agent_roster_directory_is_generated(self):
        from profile_generator import generate, render_agent_roster_markdown
        roster_md = render_agent_roster_markdown(self.roster)
        self.assertIn("# Starfleet Agent Roster & Team Directory", roster_md)
        self.assertIn("prefer engaging agents from your own team first", roster_md)
        self.assertIn("## Team Voyager", roster_md)
        self.assertIn("## Team Enterprise", roster_md)
        self.assertIn("## Team DeepSpace9", roster_md)
        self.assertIn("## Team Discovery", roster_md)
        self.assertIn("## Team yrevocsiD", roster_md)
        self.assertIn("`kathryn`", roster_md)
        self.assertIn("`jean-luc`", roster_md)
        self.assertIn("`benjamin`", roster_md)
        self.assertIn("`gabriel`", roster_md)
        self.assertIn("`michael`", roster_md)
        self.assertIn("`leahcim`", roster_md)
        self.assertIn("Michael Burnham (mirror)", roster_md)
        agent_roster_file = HERE / "docs" / "pipeline" / "agent-roster.md"
        self.assertTrue(agent_roster_file.is_file())

    def test_role_specific_process_guides_and_core_rules_exist(self):
        core = HERE / "docs" / "pipeline" / "core-rules.md"
        self.assertTrue(core.is_file())
        self.assertIn("ASPICE Baseline", core.read_text())
        for role_name in self.roster["role_policy"]:
            slug = role_name.lower().replace(" ", "-").replace("/", "-")
            guide = HERE / "docs" / "pipeline" / "roles" / f"{slug}.md"
            self.assertTrue(guide.is_file(), f"Missing role guide for {role_name}: {guide}")
            self.assertIn("Role SOP:", guide.read_text())

    def test_memory_policy_structure_and_limits(self):
        mem = self.roster.get("memory_policy")
        self.assertIsNotNone(mem)
        self.assertEqual(mem["scopes"]["agent"]["default_size_kb"], 40)
        self.assertEqual(mem["scopes"]["role"]["default_size_kb"], 60)
        self.assertEqual(mem["scopes"]["capability_set"]["default_size_kb"], 30)
        self.assertFalse(mem["scopes"]["feature"]["size_configurable"])
        self.assertIn("Acceptance", mem["scopes"]["feature"]["lifecycle_instructions"])
        self.assertIn("ISO 8601 UTC", mem["entry_format"]["timestamp_format"])
        self.assertIn("Jeder Eintrag MUSS einen UTC-Zeitstempel und die Urheber-Signatur tragen.", mem["entry_format"]["rules"])


class AntigravitySessionTests(SupervisorNativeSessionTests):
    def test_agy_command_and_chat_use_same_conversation(self):
        supervisor = self.supervisor()
        supervisor.begin_profile_generation("test")
        supervisor.mark_profile_applied("worf")
        config = supervisor.agents["worf"]
        command = supervisor.command("worf", config, "agy", "wake")
        self.assertEqual(command[0], "agy")
        self.assertIn("--dangerously-skip-permissions", command)
        self.assertIn("accept-edits", command)
        self.assertIn("--output-format", command)
        self.assertIn("stream-json", command)
        self.assertEqual(command[-1], "-p=wake")
        self.assertNotIn("-p", command)
        self.assertIn("gemini-3.7-flash-low", command)
        supervisor.agent_state("worf")["conversation_id"] = "conversation-1"
        with mock.patch.object(supervisor, "runtime", return_value="agy"):
            name, observe = supervisor.chat_command("WORF")
        self.assertEqual(name, "worf")
        self.assertIn("--conversation", observe)
        self.assertIn("conversation-1", observe)
        resumed = supervisor.command("worf", config, "agy", "wake")
        self.assertIn("conversation-1", resumed)
        self.assertEqual(resumed[-1], "-p=wake")


class CursorCliSessionTests(SupervisorNativeSessionTests):
    def test_cursor_runtime_requires_its_generated_native_profile(self):
        supervisor = self.supervisor()
        config = supervisor.agents["michael"]
        self.assertIsNone(supervisor.runtime("michael", config))
        self.args.cursor_profiles.mkdir(parents=True)
        (self.args.cursor_profiles / "michael.md").write_text("---\nname: michael\n---\n")
        self.assertEqual(supervisor.runtime("michael", config), "cursor")

    def test_cursor_command_and_chat_share_a_resumable_session(self):
        supervisor = self.supervisor()
        config = supervisor.agents["michael"]
        command = supervisor.command("michael", config, "cursor", "wake")
        self.assertEqual(command[0], "cursor-agent")
        self.assertIn("--force", command)
        self.assertIn("--print", command)
        self.assertIn("--output-format", command)
        self.assertIn("stream-json", command)
        self.assertIn("--trust", command)
        self.assertIn("--approve-mcps", command)
        self.assertIn("cursor-grok-4.6-high", command)
        self.assertNotIn("--agent", command)
        self.assertEqual(command[-1], "wake")

        supervisor.agent_state("michael")["cursor_session_id"] = "session-1"
        with mock.patch.object(supervisor, "runtime", return_value="cursor"):
            name, interactive = supervisor.chat_command("MICHAEL")
        self.assertEqual(name, "michael")
        self.assertIn("--resume", interactive)
        self.assertIn("session-1", interactive)
        self.assertIn("--approve-mcps", interactive)
        self.assertNotIn("--print", interactive)
        self.assertNotIn("--agent", interactive)

        resumed = supervisor.command("michael", config, "cursor", "wake")
        self.assertIn("--resume", resumed)
        self.assertIn("session-1", resumed)
        self.assertEqual(resumed[-1], "wake")

    def test_cursor_reap_captures_stream_session_id(self):
        supervisor = self.supervisor()
        log_path = Path(self.tmp.name) / "cursor.jsonl"
        log_path.write_text(
            '{"type":"system","subtype":"init","session_id":"cursor-session-1"}\n'
            '{"type":"assistant","message":{"content":[{"type":"text","text":"ok"}]}}\n'
        )

        process = mock.Mock(pid=321)
        process.poll.return_value = 0
        log = mock.Mock()
        supervisor.processes["michael"] = {
            "process": process, "log": log, "path": log_path,
            "runtime": "cursor", "signature": "message-id", "lock": None,
        }
        supervisor.reap()
        self.assertEqual(
            supervisor.agent_state("michael")["cursor_session_id"],
            "cursor-session-1",
        )
        log.close.assert_called_once()


class GrokCliSessionTests(SupervisorNativeSessionTests):
    def test_grok_runtime_requires_its_generated_native_profile(self):
        supervisor = self.supervisor()
        config = supervisor.agents["leahcim"]
        self.assertIsNone(supervisor.runtime("leahcim", config))
        self.args.grok_profiles.mkdir(parents=True)
        (self.args.grok_profiles / "leahcim.md").write_text("---\nname: leahcim\n---\n")
        self.assertEqual(supervisor.runtime("leahcim", config), "grok")

    def test_grok_command_and_chat_share_a_resumable_session(self):
        supervisor = self.supervisor()
        config = supervisor.agents["leahcim"]
        command = supervisor.command("leahcim", config, "grok", "wake")
        self.assertEqual(command[0], "grok")
        self.assertEqual(
            command[command.index("--allow") + 1],
            "MCPTool(agent-inbox__*)")
        self.assertIn("--output-format", command)
        self.assertIn("grok-4.6", command)
        self.assertIn("--agent", command)
        self.assertEqual(command[-1], "--single=wake")

        supervisor.agent_state("leahcim")["grok_session_id"] = "session-1"
        with mock.patch.object(supervisor, "runtime", return_value="grok"):
            name, interactive = supervisor.chat_command("LEAHCIM")
        self.assertEqual(name, "leahcim")
        self.assertIn("--resume", interactive)
        self.assertIn("session-1", interactive)
        self.assertEqual(
            interactive[interactive.index("--allow") + 1],
            "MCPTool(agent-inbox__*)")
        self.assertNotIn("--single=wake", interactive)

        resumed = supervisor.command("leahcim", config, "grok", "wake")
        self.assertIn("--resume", resumed)
        self.assertIn("session-1", resumed)
        self.assertEqual(resumed[-1], "--single=wake")

    def test_grok_reap_captures_stream_session_id(self):
        supervisor = self.supervisor()
        log_path = Path(self.tmp.name) / "grok.jsonl"
        log_path.write_text(
            '{"type":"text","data":"working"}\n'
            '{"type":"end","sessionId":"grok-session-1"}\n'
        )

        process = mock.Mock(pid=321)
        process.poll.return_value = 0
        log = mock.Mock()
        supervisor.processes["leahcim"] = {
            "process": process, "log": log, "path": log_path,
            "runtime": "grok", "signature": "message-id", "lock": None,
        }
        supervisor.reap()
        self.assertEqual(
            supervisor.agent_state("leahcim")["grok_session_id"],
            "grok-session-1",
        )
        log.close.assert_called_once()


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.config = root / "config"
        self.store = root / "store"
        self.archive = root / "archive"
        self.state = root / "state"
        self.workspace = root / "workspace"
        self.config.mkdir()
        self.workspace.mkdir()
        shutil.copy2(HERE / "agents.json", self.config / "agents.json")
        self.args = argparse.Namespace(
            inbox=self.config, store=self.store, archive_dir=self.archive,
            state_dir=self.state, workspace=self.workspace, agent=None,
            wake_broadcasts=False, allow_integrators=False, max_parallel=1,
            cooldown=1, max_backoff=10, interval=1, replace_running=False,
            codex_profiles=root / "codex", claude_profiles=root / "claude",
            agy_profiles=root / "agy", cursor_profiles=root / "cursor",
            grok_profiles=root / "grok", check=False,
            keys_root=root / "keys", command="run",
        )

    def tearDown(self):
        self.tmp.cleanup()

    def supervisor(self):
        return SUPERVISOR.Supervisor(self.args)

    def _usage_state(self, supervisor, **remaining_by_provider):
        usage = supervisor.state.setdefault("usage", {})
        for provider, remaining in remaining_by_provider.items():
            usage[provider] = {"provider": provider, "windows": [{
                "label": "7d", "remaining_percent": remaining,
            }]}
        return usage

    def _write_backlog(self):
        (self.workspace / "TODO.md").write_text(
            "# TODO\n"
            "  [u] - unclear. Legend prose, not an item.\n"
            "- [ ] **0044-01** Something in progress.\n"
            "- [u] **0039-03** PREREQ: 0039-03:0039-02 Productize or reject "
            "the `validator` proposal.\n"
            "  - [u] 0044-05.01 Subtask waiting on a scope waiver.\n",
            encoding="utf-8")

    def test_pending_decisions_list_u_items_with_claim_owner(self):
        self._write_backlog()
        (self.workspace / "TODO-data-0039-03-20260827T000000Z.md").write_text(
            "claim", encoding="utf-8")
        supervisor = self.supervisor()
        decisions = supervisor.pending_decisions()
        self.assertEqual([d["id"] for d in decisions],
                         ["0039-03", "0044-05.01"])
        self.assertEqual(decisions[0]["agent"], "data")
        self.assertIn("Productize or reject the validator proposal",
                      decisions[0]["title"])
        self.assertEqual(decisions[1]["agent"], "")
        with mock.patch.object(supervisor, "unread_counts", return_value={}):
            snap = supervisor.dashboard_snapshot()
        self.assertEqual(len(snap["decisions"]), 2)

    def _write_issue(self, item, state="blocked", escalation=None):
        parts = item.split("-")
        folder = (self.workspace / "issues" / parts[0] if len(parts) == 1
                  else self.workspace / "issues" / parts[0] / item)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "index.md").write_text(
            f'---\nschema_version: "1.0"\nid: "{item}"\n'
            f'level: "task"\nparent: "{parts[0]}"\nstate: "{state}"\n---\n'
            f"# Store title for {item}\n", encoding="utf-8")
        if escalation:
            decisions = folder / "decisions"
            decisions.mkdir(exist_ok=True)
            (decisions / "esc-001.json").write_text(
                json.dumps(escalation), encoding="utf-8")

    def _escalation(self, **overrides):
        record = {
            "schema_version": "1.0", "decision_id": "esc-0039-03-scope",
            "item_id": "0039-03", "kind": "escalation", "status": "proposed",
            "decided_at": "2026-08-27T00:00:00Z",
            "authority": {"kind": "human", "identity": "pending"},
            "rationale": "needs management",
            "question": "Productize the validator or reject it?",
            "options": [
                {"id": "productize", "summary": "Productize",
                 "consequences": "becomes a supported tool"},
                {"id": "reject", "summary": "Reject", "consequences": "drop it"},
            ],
        }
        record.update(overrides)
        return record

    def test_issue_store_enriches_todo_items_with_question_and_options(self):
        self._write_backlog()
        self._write_issue("0039-03", escalation=self._escalation())
        supervisor = self.supervisor()
        by_id = {d["id"]: d for d in supervisor.pending_decisions()}
        decision = by_id["0039-03"]
        self.assertIn("Productize the validator", decision["question"])
        self.assertEqual(
            [o["id"] for o in decision["options"]], ["productize", "reject"])
        self.assertEqual(decision["options"][0]["label"], "Productize")
        self.assertEqual(decision["decision_id"], "esc-0039-03-scope")
        # TODO.md stays authoritative pre-cutover: its title wins.
        self.assertIn("Productize or reject", decision["title"])
        # A decided or non-escalation record is not a pending questionnaire.
        self._write_issue("0044-05.01", escalation=self._escalation(
            item_id="0044-05.01", selected_option="productize"))
        by_id = {d["id"]: d for d in supervisor.pending_decisions()}
        self.assertNotIn("question", by_id["0044-05.01"])

    def test_issue_store_becomes_the_source_after_cutover(self):
        (self.workspace / "TODO.md").write_text(
            "- [ ] **0039-03** migrated, no [u] markers left\n",
            encoding="utf-8")
        self._write_issue("0041-02", escalation=self._escalation(
            item_id="0041-02", decision_id="esc-0041-02"))
        self._write_issue("0044-01", state="in_progress")
        supervisor = self.supervisor()
        decisions = supervisor.pending_decisions()
        self.assertEqual([d["id"] for d in decisions], ["0041-02"])
        self.assertEqual(decisions[0]["title"], "Store title for 0041-02")
        self.assertEqual(decisions[0]["decision_id"], "esc-0041-02")

    def _journal(self, *messages):
        path = self.store / "data" / "messages.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("".join(json.dumps(m) + "\n" for m in messages),
                        encoding="utf-8")

    def test_mailbox_decision_requests_track_ask_answer_and_reask(self):
        self._journal(
            {"id": "m1", "ts": "t1", "sender": "doctor", "to": "management",
             "thread": "opd-01", "subject": "OPD-01 identity grammar",
             "body": "Which identity form?"},
            {"id": "m2", "ts": "t2", "sender": "seven", "to": "kathryn",
             "thread": "0044-99",
             "subject": "DECISION NEEDED: waive the gate?",
             "body": "Options A/B."},
            {"id": "m3", "ts": "t3", "sender": "tom", "to": "kathryn",
             "thread": "smalltalk", "subject": "status", "body": "all fine"},
        )
        supervisor = self.supervisor()
        pending = {e["id"]: e for e in supervisor.mailbox_decision_requests()}
        self.assertEqual(set(pending), {"opd-01", "0044-99"})
        self.assertEqual(pending["opd-01"]["agent"], "doctor")
        self.assertIn("Which identity form?", pending["opd-01"]["question"])
        # A supervisor reply in the thread answers it; a new ask re-opens it.
        self._journal(
            {"id": "m1", "sender": "doctor", "to": "management",
             "thread": "opd-01", "subject": "OPD-01", "body": "?"},
            {"id": "m4", "sender": "supervisor", "to": "doctor",
             "thread": "opd-01", "subject": "Management decision: opd-01",
             "body": "OPT-01-A"},
            {"id": "m5", "sender": "seven", "to": "kathryn",
             "thread": "0044-99", "subject": "DECISION NEEDED: gate",
             "body": "?"},
            {"id": "m6", "sender": "supervisor", "to": "seven",
             "thread": "0044-99", "subject": "Management decision: 0044-99",
             "body": "B"},
            {"id": "m7", "sender": "seven", "to": "management",
             "thread": "0044-99", "subject": "DECISION NEEDED: follow-up",
             "body": "new situation"},
        )
        pending = {e["id"] for e in supervisor.mailbox_decision_requests()}
        self.assertEqual(pending, {"0044-99"})

    def test_mailbox_decision_requests_recognise_german_markers(self):
        self._journal(
            {"id": "m1", "ts": "t1", "sender": "kathryn", "to": "supervisor",
             "thread": "0037-16",
             "subject": "ENTSCHEIDUNG NÖTIG, dritte Vorlage — 0037-16 blockiert",
             "body": "A oder B?"},
            {"id": "m2", "ts": "t2", "sender": "kathryn", "to": "supervisor",
             "thread": "quota-recovery-claude",
             "subject": "Die fünf Entscheidungsvorlagen, formal und knapp",
             "body": "① … ⑤"},
            {"id": "m3", "ts": "t3", "sender": "kathryn", "to": "supervisor",
             "thread": "smalltalk",
             "subject": "Nachtrag zu Entscheidung ②, der sie verändert",
             "body": "kein Request, nur Kontext"},
        )
        pending = {e["id"] for e in self.supervisor().mailbox_decision_requests()}
        self.assertEqual(pending, {"0037-16", "quota-recovery-claude"})

    def test_structured_decision_request_exposes_form_and_resolves_before_reply(self):
        form = {
            "schema": "decision-request@v1", "decision_id": "decision-0037-22",
            "question": "Repair the interface or retain it?",
            "deciding_role": "Management",
            "options": [
                {"id": "A", "summary": "Repair", "consequences": "new API"},
                {"id": "B", "summary": "Retain", "consequences": "compatibility"},
            ],
            "recommendation": {"option_id": "A", "reason": "bounded"},
            "permanent_records": ["docs/contract.md", "main@abc123"],
            "affected_work_products": ["docs/interface.md"],
            "affected_processes": ["acceptance", "integration"],
        }
        decision_dir = self.archive / "decision-requests"
        decision_dir.mkdir(parents=True)
        (decision_dir / "decision-0037-22.json").write_text(
            json.dumps(form), encoding="utf-8")
        self._journal({
            "id": "m-structured", "sender": "jadzia", "to": "management",
            "thread": "0037-22", "subject": "DECISION NEEDED — interface",
            "body": "generated notice", "kind": "decision_request",
            "decision_id": "decision-0037-22", "assignment_id": "offer-22",
            "decision_record": str(decision_dir / "decision-0037-22.json"),
        })
        supervisor = self.supervisor()
        entry = supervisor.mailbox_decision_requests()[0]
        self.assertEqual(entry["question"], form["question"])
        self.assertEqual(entry["deciding_role"], "Management")
        self.assertEqual(entry["assignment_id"], "offer-22")
        self.assertEqual(entry["provenance"], form["permanent_records"])
        self.assertEqual(entry["affected_work_products"], ["docs/interface.md"])
        self.assertEqual(entry["affected_processes"], ["acceptance", "integration"])
        self.assertTrue(entry["options"][0]["recommended"])
        with (mock.patch.object(
                  supervisor, "_run_inbox_tool", return_value="Resolved") as run,
              mock.patch.object(
                  supervisor, "send_supervisor_message", return_value=True) as send):
            supervisor.apply_management_decision({
                "item": "0037-22", "decision_id": "decision-0037-22",
                "option": "A", "text": "Proceed.",
            })
        run.assert_called_once_with(
            "tool_decision_resolve",
            {"decision_id": "decision-0037-22", "option": "A", "text": "Proceed."},
            "management decision resolution 0037-22")
        self.assertEqual(send.call_args.args[0], "jadzia")
        self.assertIn("Structured decision record resolved", send.call_args.args[2])

    def test_decision_options_parsed_from_block_style_mail_body(self):
        body = (
            "**Eingereicht nach der neuen Konvention.**\n\n"
            "**OPTIONEN:**\n\n"
            "  **`OPT-02-A`** — Eskalationen auf `main`.\n"
            "  *Folge:* Extern sichtbar, aber blockierbar.\n\n"
            "  **`OPT-02-B`** — Ein eigener Ref außerhalb der\n"
            "  Item-Branches.\n"
            "  *Folge:* Sichtbar ohne Branch-Raten.\n\n"
            "**EMPFEHLUNG DES RE (keine Entscheidung): `OPT-02-B`** — als "
            "einzige Option.\n\n"
            "**Antwort bitte mit `OPT-02-A`, `OPT-02-B` oder Freitext.**\n")
        options = SUPERVISOR.decision_options_from_body(body)
        self.assertEqual([o["id"] for o in options], ["OPT-02-A", "OPT-02-B"])
        self.assertEqual(options[1]["label"],
                         "Ein eigener Ref außerhalb der Item-Branches.")
        self.assertIn("Sichtbar ohne Branch-Raten", options[1]["description"])
        self.assertTrue(options[1].get("recommended"))
        self.assertFalse(options[0].get("recommended"))

    def test_decision_options_parsed_from_inline_choices_prose(self):
        body = (
            "Question: May the seven registrations be cleaned? "
            "Choices: RECOVER-EXACT-SEVEN — authorize cleanup of only those "
            "seven registrations, rerun hygiene (recommended). "
            "KEEP-STOPPED — leave merge stopped and provide another route. "
            "Reply with stable choice ID.")
        options = SUPERVISOR.decision_options_from_body(body)
        self.assertEqual([o["id"] for o in options],
                         ["RECOVER-EXACT-SEVEN", "KEEP-STOPPED"])
        self.assertTrue(options[0].get("recommended"))
        self.assertFalse(options[1].get("recommended"))
        # The dashboard renders the flag itself; the prose marker must go.
        self.assertNotIn("recommended", options[0]["label"].lower())
        # Fewer than two recognisable options must stay free-text only.
        self.assertEqual(
            SUPERVISOR.decision_options_from_body(
                "Please decide soon; see REQ-MDI-08 for context."), [])

    def test_decision_provenance_extracted_and_shipped_with_mail_requests(self):
        body = (
            "**FRAGE:** Wo liegt die Eskalation?\n\n"
            "**HERKUNFT:** `re-intake-mdi-20260827@25f65ab62`, Datei\n"
            "`docs/dossiers/re-intake-mdi-20260827.md`, Zeilen 380–402.\n"
            "Basis `main`. Siehe auch https://example.org/ticket/7.\n\n"
            "**Antwort bitte per Options-ID.**\n")
        refs = SUPERVISOR.decision_provenance_from_body(body)
        # Bare prose-like tokens (`main`) are dropped: without a digit, path
        # separator, dot, colon or @ they are not resolvable references.
        self.assertEqual(refs, [
            "re-intake-mdi-20260827@25f65ab62",
            "docs/dossiers/re-intake-mdi-20260827.md",
            "https://example.org/ticket/7",
        ])
        # Genitive prose in backticks ("`doctors` Befund") must not become
        # a chip; the message-id next to it must.
        self.assertEqual(
            SUPERVISOR.decision_provenance_from_body(
                "HERKUNFT: `doctors` Befund `1787831935011-5bd2c529` und "
                "`jean-lucs` Anweisung `1787831844182-4de4605f`."),
            ["1787831935011-5bd2c529", "1787831844182-4de4605f"])
        # EVIDENZ lines are read as equivalent; no marker line, no refs.
        self.assertEqual(
            SUPERVISOR.decision_provenance_from_body(
                "EVIDENZ: `main:TODO.md:463` und `1787783870722-22d0b8d3`."),
            ["main:TODO.md:463", "1787783870722-22d0b8d3"])
        self.assertEqual(
            SUPERVISOR.decision_provenance_from_body(
                "Der Verweis `main:TODO.md:463` steht im Fliesstext."), [])
        self._journal(
            {"id": "m1", "sender": "doctor", "to": "management",
             "thread": "opd-09", "subject": "OPD-09",
             "body": "Frage?\nHERKUNFT: `docs/dossiers/x.md`"})
        supervisor = self.supervisor()
        entry = supervisor.mailbox_decision_requests()[0]
        self.assertEqual(entry["provenance"], ["docs/dossiers/x.md"])

    def test_mail_decision_appears_in_pending_and_answer_goes_to_asker(self):
        self._write_backlog()
        self._journal(
            {"id": "m1", "sender": "doctor", "to": "management",
             "thread": "opd-01", "subject": "OPD-01 identity grammar",
             "body": "Which identity form?"})
        supervisor = self.supervisor()
        by_id = {d["id"]: d for d in supervisor.pending_decisions()}
        self.assertIn("opd-01", by_id)       # mail-sourced
        self.assertIn("0039-03", by_id)      # [u]-sourced still present
        self.assertEqual(by_id["opd-01"]["source"], "mail")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.apply_dashboard_command(
                {"action": "decide", "item": "opd-01", "text": "OPT-01-A."})
        recipient, _subject, body, thread = send.call_args.args[:4]
        self.assertEqual(recipient, "doctor")
        self.assertEqual(thread, "opd-01")
        self.assertIn("OPT-01-A.", body)

    def test_dashboard_mail_command_delivers_to_the_clicked_agent(self):
        supervisor = self.supervisor()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.apply_dashboard_command(
                {"action": "mail", "target": "DATA",
                 "subject": "Kurz nachgefragt", "body": "Wie weit ist 0044-05?"})
        recipient, subject, body, thread = send.call_args.args[:4]
        self.assertEqual(recipient, "data")
        self.assertEqual(subject, "Kurz nachgefragt")
        self.assertIn("From the current user via the supervisor dashboard",
                      body)
        self.assertIn("Wie weit ist 0044-05?", body)
        self.assertEqual(thread, "dashboard-mail")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.apply_dashboard_command(
                {"action": "mail", "target": "nobody-known", "body": "hi"})
            supervisor.apply_dashboard_command(
                {"action": "mail", "target": "data", "body": "  "})
        send.assert_not_called()

    def test_dashboard_delegation_prioritises_provider_capacity(self):
        stamp = SUPERVISOR.now()
        roster = {
            "kathryn": {"status": "idle", "status_since": stamp},
            "jean-luc": {"status": "busy", "status_since": stamp,
                         "remaining": 1, "task": "0037-01"},
            "jadzia": {"status": "standby", "status_since": stamp,
                       "delegate": "kathryn"},
            "michael": {"status": "exhausted", "status_since": stamp,
                        "delegate": "kathryn"},
            "leahcim": {"status": "idle", "status_since": stamp},
        }
        path = self.store / "data" / "roster.json"
        path.parent.mkdir(parents=True)
        path.write_text(json.dumps(roster), encoding="utf-8")
        supervisor = self.supervisor()
        self._usage_state(supervisor, claude=80, codex=50, grok=25,
                          agy=80, cursor=80)
        groups = supervisor.dashboard_role_offer_groups("Project Lead")
        self.assertEqual(groups[0]["agents"], ["kathryn"])
        self.assertEqual(groups[1]["agents"], ["jean-luc"])
        self.assertEqual(groups[2]["agents"], ["leahcim"])
        self.assertNotIn("jadzia", {name for group in groups
                                    for name in group["agents"]})
        preferred = supervisor.dashboard_role_offer_groups(
            "Project Lead", "JEAN-LUC")
        self.assertEqual(preferred[0]["agents"], ["jean-luc"])
        with self.assertRaisesRegex(ValueError, r"ineligible \(standby\)"):
            supervisor.dashboard_role_offer_groups("Project Lead", "jadzia")

        requested = supervisor.dashboard_role_offer_groups(
            "Project Lead", requested=[
                {"priority": 1, "agents": ["jean-luc"]},
                {"priority": 2, "agents": ["kathryn", "leahcim"]},
            ])
        self.assertEqual(requested, [
            {"priority": 1, "agents": ["jean-luc"]},
            {"priority": 2, "agents": ["kathryn", "leahcim"]},
        ])
        with self.assertRaisesRegex(ValueError, "not eligible"):
            supervisor.dashboard_role_offer_groups(
                "Project Lead", requested=[
                    {"priority": 1, "agents": ["jadzia"]},
                ])

    def test_capacity_priority_uses_five_thresholds(self):
        supervisor = self.supervisor()
        self.assertEqual(
            [supervisor.capacity_priority(value)
             for value in (100, 75, 74, 50, 49, 25, 24, 10, 9, 4, 3, None)],
            [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, None, None])

    def test_unknown_status_and_sub_four_capacity_are_not_default_offers(self):
        stamp = SUPERVISOR.now()
        path = self.store / "data" / "roster.json"
        path.parent.mkdir(parents=True)
        path.write_text(json.dumps({
            "kathryn": {"status": "idle", "status_since": stamp},
            "jean-luc": {"status": "idle", "status_since": stamp},
        }), encoding="utf-8")
        supervisor = self.supervisor()
        self._usage_state(supervisor, claude=80, codex=3, grok=99)
        groups = supervisor.dashboard_role_offer_groups("Project Lead")
        offered = {name for group in groups for name in group["agents"]}
        self.assertEqual(offered, {"kathryn"})
        self.assertNotIn("leahcim", offered)  # capacity known, status unknown
        self.assertNotIn("jean-luc", offered)  # status known, capacity below 4%

    def test_dashboard_offer_excludes_recent_terminal_runtime_quota(self):
        stamp = SUPERVISOR.now()
        roster = {
            "jadzia": {"status": "idle", "status_since": stamp},
            "kathryn": {"status": "idle", "status_since": stamp},
        }
        path = self.store / "data" / "roster.json"
        path.parent.mkdir(parents=True)
        path.write_text(json.dumps(roster), encoding="utf-8")
        log = self.state / "jadzia.jsonl"
        self.state.mkdir(parents=True, exist_ok=True)
        log.write_text(json.dumps({
            "event": "result", "result": {
                "status": "ERROR",
                "error": "Individual quota reached. Resets in 1h30m.",
            },
        }) + "\n", encoding="utf-8")
        supervisor = self.supervisor()
        self._usage_state(supervisor, agy=80, claude=75)
        supervisor.agent_state("jadzia").update(
            last_log=str(log), last_finished=stamp, last_exit=0)
        groups = supervisor.dashboard_role_offer_groups("Project Lead")
        offered = {name for group in groups for name in group["agents"]}
        self.assertNotIn("jadzia", offered)
        self.assertIn("kathryn", offered)
        snapshot = supervisor.dashboard_snapshot(claims={})
        self.assertFalse(snapshot["agents"]["jadzia"]["offer_eligible"])
        self.assertEqual(
            snapshot["agents"]["jadzia"]["offer_ineligible_reason"],
            "runtime quota exhausted")

    def test_expired_terminal_runtime_quota_does_not_block_offer(self):
        log = self.state / "jadzia.jsonl"
        self.state.mkdir(parents=True, exist_ok=True)
        log.write_text(json.dumps({
            "event": "result", "result": {
                "status": "ERROR",
                "error": "Individual quota reached. Resets in 10s.",
            },
        }) + "\n", encoding="utf-8")
        supervisor = self.supervisor()
        finished = SUPERVISOR.now()
        supervisor.agent_state("jadzia").update(
            last_log=str(log), last_finished=finished, last_exit=0)
        self.assertEqual(supervisor.runtime_quota_block(
            "jadzia", SUPERVISOR.iso_to_epoch(finished) + 61), "")

    def test_dashboard_delegation_creates_idempotent_priority_offer(self):
        supervisor = self.supervisor()
        scope = {
            "kind": "feature", "value": "0037", "thread": "0037",
            "label": "Feature 0037 (4 Branches, +2/-1)",
            "baseline": "main@abc123", "detail": "neuester 0037-04@def456",
        }
        groups = [{"priority": 1, "agents": ["kathryn"]},
                  {"priority": 2, "agents": ["jean-luc"]}]
        command = {
            "action": "delegate_integration", "command_id": "cmd-1",
            "role": "Project Lead", "intent": "coordinate",
            "scope_kind": "feature", "scope_value": "0037",
            "outcome": "Vier Branches in unabhängige Ketten schneiden.",
            "planned_minutes": 89, "reply_window_seconds": 12,
        }
        with (mock.patch.object(supervisor, "integration_delegation_scope",
                                return_value=scope),
              mock.patch.object(supervisor, "dashboard_role_offer_groups",
                                return_value=groups),
              mock.patch.object(
                  supervisor, "_run_inbox_tool",
                  return_value="Created priority offer offer-123 for 'x'.") as run):
            supervisor.apply_dashboard_command(command)
            supervisor.apply_dashboard_command(command)
            supervisor.apply_dashboard_command(
                {**command, "command_id": "cmd-2"})
        run.assert_called_once()
        tool, request, label = run.call_args.args
        self.assertEqual(tool, "tool_offer")
        self.assertEqual(request["sender"], "supervisor")
        self.assertEqual(request["thread"], "0037")
        self.assertEqual(request["priority_groups"], groups)
        self.assertEqual(request["branch"], "main")
        self.assertEqual(request["scope_paths"], ["."])
        self.assertEqual(request["planned_minutes"], 89)
        self.assertEqual(request["reply_window_seconds"], 12)
        self.assertIn("main@abc123", request["body"])
        self.assertIn("direct current-user delegation", request["body"])
        self.assertIn("nicht selbst implementieren", request["body"])
        self.assertIn("real item claim", request["body"])
        self.assertNotIn("task=dashboard-integration", request["body"])
        self.assertLessEqual(len(request["body"].splitlines()), 10)
        self.assertIn("cmd-1", label)
        record = supervisor.state["dashboard_delegations"][0]
        self.assertEqual(record["phase"], "offered")
        self.assertEqual(record["offer_id"], "offer-123")
        duplicate = supervisor.state["dashboard_delegations"][1]
        self.assertEqual(duplicate["phase"], "failed")
        self.assertIn("already has a live dashboard assignment",
                      duplicate["error"])
        offer_path = self.store / "data/offers.jsonl"
        offer_path.parent.mkdir(parents=True, exist_ok=True)
        offer_path.write_text(json.dumps({
            "offer_id": "offer-123", "event": "cancelled",
            "reason": "aborted", "ts": SUPERVISOR.now(),
        }) + "\n", encoding="utf-8")
        with (mock.patch.object(supervisor, "integration_delegation_scope",
                                return_value=scope),
              mock.patch.object(supervisor, "dashboard_role_offer_groups",
                                return_value=groups),
              mock.patch.object(
                  supervisor, "_run_inbox_tool",
                  return_value="Created priority offer offer-456 for 'x'.") as rerun):
            supervisor.apply_dashboard_delegation(
                {**command, "command_id": "cmd-3"})
        rerun.assert_called_once()
        self.assertEqual(
            supervisor.state["dashboard_delegations"][-1]["phase"], "offered")

    def test_supervisor_sweeps_priority_offer_at_its_deadline(self):
        offer_path = self.store / "data" / "offers.jsonl"
        offer_path.parent.mkdir(parents=True)
        offer_path.write_text("".join(json.dumps(event) + "\n" for event in (
            {"offer_id": "offer-clock", "event": "created"},
            {"offer_id": "offer-clock", "event": "activated", "priority": 1,
             "deadline": "2026-08-28T08:10:00Z"},
        )), encoding="utf-8")
        deadline = SUPERVISOR.iso_to_epoch("2026-08-28T08:10:00Z")
        supervisor = self.supervisor()
        with (mock.patch.object(
                  supervisor, "_run_inbox_tool",
                  return_value="Offer offer-clock priority 1 timed out; unfilled.") as run,
              mock.patch("sys.stdout", io.StringIO())):
            self.assertFalse(supervisor.reconcile_priority_offers(deadline - 1))
            run.assert_not_called()
            self.assertTrue(supervisor.reconcile_priority_offers(deadline))
        run.assert_called_once_with(
            "tool_offer_sweep", {}, "priority offer deadline sweep")

    def test_supervisor_uses_dedicated_delivery_deadline_not_grace_deadline(self):
        offer_path = self.store / "data/offers.jsonl"
        offer_path.parent.mkdir(parents=True)
        offer_path.write_text("".join(json.dumps(event) + "\n" for event in (
            {"offer_id": "offer-clock", "event": "created",
             "priority_groups": [{"priority": 1, "agents": ["jadzia"]}]},
            {"offer_id": "offer-clock", "event": "activated", "priority": 1,
             "deadline": "2026-08-28T08:01:00Z",
             "candidate_deadlines": {"jadzia": "2026-08-28T08:01:00Z"}},
            {"offer_id": "offer-clock", "event": "delivered", "agent": "jadzia",
             "deadline": "2026-08-28T08:00:30Z", "channel": "offer_inbox"},
        )), encoding="utf-8")
        self.assertEqual(
            self.supervisor().next_priority_offer_deadline(),
            SUPERVISOR.iso_to_epoch("2026-08-28T08:00:30Z"))

    def test_dashboard_delegation_preserves_multi_scope_contract(self):
        supervisor = self.supervisor()
        scopes = [
            {"kind": "branch", "value": "0037-01", "expected_oid": "a" * 40},
            {"kind": "branch", "value": "0037-02", "expected_oid": "b" * 40},
        ]
        resolved = {
            "kind": "multi", "value": "branch:0037-01|branch:0037-02",
            "thread": "integration-selection", "label": "2 ausgewählte Branches",
            "baseline": "main@abc123", "detail": "Branch 0037-01; Branch 0037-02",
            "scope_key": "branch:0037-01|branch:0037-02",
            "scopes": [
                {"kind": "branch", "value": "0037-01", "label": "Branch 0037-01"},
                {"kind": "branch", "value": "0037-02", "label": "Branch 0037-02"},
            ],
        }
        command = {
            "action": "delegate_integration", "command_id": "cmd-multi",
            "role": "Project Lead", "intent": "coordinate", "scopes": scopes,
            "outcome": "Beide Branches koordinieren.", "planned_minutes": 13,
            "reply_window_seconds": 10,
            "priority_groups": [{"priority": 1, "agents": ["kathryn"]}],
        }
        with (mock.patch.object(supervisor, "integration_delegation_scopes",
                                return_value=resolved) as resolve,
              mock.patch.object(supervisor, "dashboard_role_offer_groups",
                                return_value=command["priority_groups"]),
              mock.patch.object(supervisor, "_run_inbox_tool",
                                return_value="Created priority offer offer-multi for 'x'.") as run):
            supervisor.apply_dashboard_command(command)
        self.assertEqual(resolve.call_args.args[0], scopes)
        request = run.call_args.args[1]
        self.assertEqual(request["thread"], "integration-selection")
        self.assertIn("Branch 0037-01; Branch 0037-02", request["body"])
        record = supervisor.state["dashboard_delegations"][-1]
        self.assertEqual(record["scope_kind"], "multi")
        self.assertEqual(len(record["scopes"]), 2)

    def test_dashboard_integrator_assignment_requires_exact_branch(self):
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "_run_inbox_tool") as run:
            supervisor.apply_dashboard_delegation({
                "command_id": "cmd-invalid", "role": "Integrator",
                "intent": "coordinate", "scope_kind": "queue",
            })
        run.assert_not_called()
        record = supervisor.state["dashboard_delegations"][0]
        self.assertEqual(record["phase"], "failed")
        self.assertIn("exact branch", record["error"])

    def test_dashboard_delegation_tracks_award_active_and_completion(self):
        supervisor = self.supervisor()
        supervisor.state["dashboard_delegations"] = [{
            "command_id": "cmd-life", "offer_id": "offer-life",
            "offer_item": "dashboard-integration-cmd-life",
            "phase": "offered", "role": "Project Lead",
            "scope_kind": "feature", "thread": "0037",
            "scope_label": "Feature 0037", "created_at": SUPERVISOR.now(),
        }]
        awarded_at = "2026-08-28T10:00:00+00:00"
        offer_path = self.store / "data" / "offers.jsonl"
        offer_path.parent.mkdir(parents=True)
        offer_path.write_text("".join(json.dumps(event) + "\n" for event in (
            {"offer_id": "offer-life", "event": "created"},
            {"offer_id": "offer-life", "event": "activated", "priority": 1,
             "deadline": "2026-08-28T12:00:00Z", "ts": awarded_at},
            {"offer_id": "offer-life", "event": "declined", "agent": "jean-luc",
             "reason": "independence conflict", "ts": awarded_at},
            {"offer_id": "offer-life", "event": "awarded", "agent": "kathryn",
             "ts": awarded_at},
        )), encoding="utf-8")
        roster_path = self.store / "data" / "roster.json"
        roster_path.write_text(json.dumps({
            "kathryn": {"status": "busy", "status_since": SUPERVISOR.now(),
                        "task": "0037-17", "remaining": 1},
        }), encoding="utf-8")
        active = supervisor.dashboard_delegations()[0]
        self.assertEqual(active["phase"], "in_progress")
        self.assertEqual(active["winner"], "kathryn")
        self.assertEqual(active["declined"], ["jean-luc"])
        self.assertEqual(active["offer_events"][1]["reason"],
                         "independence conflict")
        messages = self.store / "data" / "messages.jsonl"
        messages.write_text(json.dumps({
            "id": "1787914800000-deadbeef", "ts": SUPERVISOR.now(),
            "sender": "kathryn", "to": "supervisor", "thread": "0037",
            "subject": "RESULT 0037", "body": "Chains awarded and tracked.",
        }) + "\n", encoding="utf-8")
        completed = supervisor.dashboard_delegations()[0]
        self.assertEqual(completed["phase"], "review")
        self.assertTrue(completed["completed_at"])

    def test_dashboard_delegation_folds_assignment_lifecycle_and_child_round(self):
        supervisor = self.supervisor()
        supervisor.state["dashboard_delegations"] = [{
            "command_id": "cmd-controls", "offer_id": "offer-parent",
            "phase": "offered", "role": "Project Lead",
            "scope_kind": "feature", "thread": "0037",
            "scope_label": "Feature 0037", "created_at": SUPERVISOR.now(),
        }]
        offer_path = self.store / "data" / "offers.jsonl"
        offer_path.parent.mkdir(parents=True)
        events = (
            {"offer_id": "offer-parent", "event": "created"},
            {"offer_id": "offer-parent", "event": "awarded", "agent": "kathryn",
             "due_at": "2026-08-28T12:00:00Z", "ts": "2026-08-28T10:00:00Z"},
            {"offer_id": "offer-parent", "event": "paused", "reason": "gate",
             "ts": "2026-08-28T10:05:00Z"},
            {"offer_id": "offer-parent", "event": "extended",
             "due_at": "2026-08-28T13:00:00Z", "reason": "gate moved",
             "ts": "2026-08-28T10:06:00Z"},
            {"offer_id": "offer-parent", "event": "transferred",
             "new_sender": "jean-luc", "reason": "coverage",
             "ts": "2026-08-28T10:07:00Z"},
            {"offer_id": "offer-parent", "event": "delegation_started",
             "delegation_offer_id": "offer-child", "reason": "handover",
             "ts": "2026-08-28T10:08:00Z"},
            {"offer_id": "offer-child", "event": "created",
             "parent_offer_id": "offer-parent"},
            {"offer_id": "offer-child", "event": "declined", "agent": "jadzia",
             "reason": "conflict", "ts": "2026-08-28T10:09:00Z"},
        )
        offer_path.write_text("".join(json.dumps(event) + "\n" for event in events))
        record = supervisor.dashboard_delegations()[0]
        self.assertEqual(record["phase"], "on_hold")
        self.assertEqual(record["due_at"], "2026-08-28T13:00:00Z")
        self.assertEqual(record["coordinator"], "jean-luc")
        self.assertEqual(record["delegation_offer_id"], "offer-child")
        child_decline = record["offer_events"][-1]
        self.assertTrue(child_decline["delegation"])
        self.assertEqual(child_decline["reason"], "conflict")

    def test_dashboard_offer_control_calls_canonical_lifecycle_tool(self):
        supervisor = self.supervisor()
        supervisor.state["dashboard_delegations"] = [{
            "command_id": "cmd-controls", "offer_id": "offer-parent",
            "phase": "awarded", "role": "Project Lead", "coordinator": "supervisor",
        }]
        with mock.patch.object(
                supervisor, "_run_inbox_tool", return_value="Paused assignment") as run:
            supervisor.apply_dashboard_offer_control({
                "offer_id": "offer-parent", "control_action": "pause",
                "reason": "checkpoint",
            })
        self.assertEqual(run.call_args.args[0], "tool_offer_control")
        self.assertEqual(run.call_args.args[1], {
            "sender": "supervisor", "offer_id": "offer-parent",
            "action": "pause", "reason": "checkpoint",
        })

    def test_dashboard_assignment_transition_uses_canonical_state_machine(self):
        supervisor = self.supervisor()
        current = [{
            "offer_id": "offer-parent", "phase": "review",
            "role": "Project Lead", "coordinator": "supervisor",
        }]
        with (mock.patch.object(
                  supervisor, "dashboard_delegations", return_value=current),
              mock.patch.object(
                  supervisor, "_run_inbox_tool", return_value="accepted") as run):
            supervisor.apply_dashboard_assignment_transition({
                "offer_id": "offer-parent", "assignment_status": "accepted",
                "reason": "acceptance passed",
            })
        run.assert_called_once_with(
            "tool_assignment_transition",
            {"agent": "supervisor", "offer_id": "offer-parent",
             "status": "accepted", "reason": "acceptance passed"},
            "dashboard assignment transition accepted offer-parent")

    def test_decide_command_mails_the_claim_owner_and_marks_answered(self):
        self._write_backlog()
        (self.workspace / "TODO-data-0039-03-20260827T000000Z.md").write_text(
            "claim", encoding="utf-8")
        supervisor = self.supervisor()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.apply_dashboard_command(
                {"action": "decide", "item": "0039-03",
                 "option": "B", "text": "Productize it."})
        recipient, subject, body, thread = send.call_args.args[:4]
        self.assertEqual(recipient, "data")
        self.assertIn("0039-03", subject)
        self.assertIn("Chosen option: B", body)
        self.assertIn("Productize it.", body)
        self.assertIn("check the recorded decision in first", body)
        self.assertEqual(thread, "0039-03")
        self.assertTrue(supervisor.state["decisions_answered"]["0039-03"])
        answered = {d["id"]: d["answered_at"]
                    for d in supervisor.pending_decisions()}
        self.assertTrue(answered["0039-03"])
        # The marker clears once the item leaves [u].
        (self.workspace / "TODO.md").write_text(
            "- [ ] **0039-03** answered and moving again\n", encoding="utf-8")
        supervisor.pending_decisions()
        self.assertNotIn("0039-03", supervisor.state["decisions_answered"])

    def test_decide_without_claim_owner_goes_to_the_project_leads(self):
        self._write_backlog()
        supervisor = self.supervisor()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.apply_dashboard_command(
                {"action": "decide", "item": "0044-05.01", "text": "Waiver granted."})
        recipients = {call.args[0] for call in send.call_args_list}
        self.assertIn("jean-luc", recipients)   # codex lead
        self.assertIn("kathryn", recipients)    # claude lead
        self.assertIn("route it to the responsible agent",
                      send.call_args.args[2])
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.apply_dashboard_command(
                {"action": "decide", "item": "0044-05.01", "text": ""})
        send.assert_not_called()  # an empty answer decides nothing

    def test_supervisor_gui_appends_job_control_commands(self):
        spec = importlib.util.spec_from_file_location(
            "supervisor_gui", HERE / "supervisor-gui.py")
        gui = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(gui)
        gui.enqueue(self.state, "restart", "all", "")
        recorded = json.loads(
            (self.state / gui.COMMANDS_FILE).read_text().splitlines()[0])
        self.assertEqual(
            recorded,
            {"action": "restart", "scope": "all", "target": ""},
        )

    def test_supervisor_gui_returns_delegation_receipt_and_preserves_contract(self):
        spec = importlib.util.spec_from_file_location(
            "supervisor_gui_delegate", HERE / "supervisor-gui.py")
        gui = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(gui)
        server = gui.ThreadingHTTPServer(
            ("127.0.0.1", 0), gui.make_handler(self.state))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            connection = http.client.HTTPConnection(
                "127.0.0.1", server.server_address[1], timeout=3)
            command = {
                "action": "delegate_integration", "command_id": "receipt-1",
                "role": "Project Lead", "intent": "coordinate",
                "scope_kind": "feature", "scope_value": "0037",
                "expected_oid": "a" * 40,
                "scopes": [
                    {"kind": "branch", "value": "0037-01",
                     "expected_oid": "b" * 40},
                    {"kind": "branch", "value": "0037-02",
                     "expected_oid": "c" * 40},
                ],
                "outcome": "Coordinate it.", "conditions": "Wait for 0037-02.",
                "planned_minutes": 89, "reply_window_seconds": 15,
                "priority_groups": [
                    {"priority": 1, "agents": ["kathryn"]},
                    {"priority": 2, "agents": ["jean-luc"]},
                ],
            }
            connection.request(
                "POST", "/command", json.dumps(command),
                {"Content-Type": "application/json"})
            response = connection.getresponse()
            receipt = json.loads(response.read())
            connection.close()
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)
        self.assertEqual(response.status, 202)
        self.assertEqual(receipt,
                         {"command_id": "receipt-1", "phase": "submitted"})
        recorded = json.loads(
            (self.state / gui.COMMANDS_FILE).read_text().splitlines()[0])
        self.assertEqual(recorded, command)

    def test_supervisor_gui_queues_offer_lifecycle_control(self):
        spec = importlib.util.spec_from_file_location(
            "supervisor_gui_control", HERE / "supervisor-gui.py")
        gui = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(gui)
        server = gui.ThreadingHTTPServer(
            ("127.0.0.1", 0), gui.make_handler(self.state))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            connection = http.client.HTTPConnection(
                "127.0.0.1", server.server_address[1], timeout=3)
            connection.request("POST", "/command", json.dumps({
                "action": "control_integration_delegation",
                "offer_id": "offer-parent", "control_action": "delegate",
                "reason": "handover", "reply_window_seconds": 12,
                "priority_groups": [{"priority": 1, "agents": ["jadzia"]}],
            }), {"Content-Type": "application/json"})
            response = connection.getresponse()
            response.read()
            connection.close()
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=3)
        self.assertEqual(response.status, 202)
        recorded = json.loads(
            (self.state / gui.COMMANDS_FILE).read_text().splitlines()[0])
        self.assertEqual(recorded["control_action"], "delegate")
        self.assertEqual(recorded["priority_groups"][0]["agents"], ["jadzia"])

    def test_unread_counts_match_direct_mail(self):
        supervisor = self.supervisor()
        path = self.store / "data/messages.jsonl"
        path.parent.mkdir(parents=True)
        path.write_text(json.dumps({
            "id": "1700000000000-dashboard", "ts": "2026-08-26T00:00:00Z",
            "sender": "jean-luc", "to": "data", "subject": "s", "body": "b",
            "thread": "",
        }) + "\n")
        counts = supervisor.unread_counts()
        self.assertEqual(counts["data"], 1)
        self.assertEqual(len(supervisor.unread("data")), 1)
        self.assertEqual(counts.get("jean-luc", 0), 0)

    def test_usage_windows_group_into_five_hour_week_and_month(self):
        grouped = SUPERVISOR.grouped_usage_windows({
            "provider": "codex",
            "error": None,
            "windows": [
                {"label": "5h", "remaining_percent": 80, "duration_minutes": 300},
                {"label": "7d", "remaining_percent": 40, "duration_minutes": 10080},
                {"label": "month", "remaining_percent": 12},
                {"label": "api", "remaining_percent": 99},
            ],
        })
        self.assertEqual(grouped["windows"]["five_hour"]["remaining_percent"], 80)
        self.assertEqual(grouped["windows"]["weekly"]["remaining_percent"], 40)
        self.assertEqual(grouped["windows"]["monthly"]["remaining_percent"], 12)
        self.assertEqual(grouped["extra"][0]["label"], "api")
        self.assertEqual(SUPERVISOR.classify_usage_window({"label": "weekly"}), "weekly")
        self.assertIsNone(SUPERVISOR.classify_usage_window({"label": "api"}))
        cursor = SUPERVISOR.grouped_usage_windows({
            "provider": "cursor",
            "windows": [
                {"label": "plan", "remaining_percent": 60},
                {"label": "auto", "remaining_percent": 63},
            ],
        })
        self.assertEqual(cursor["windows"]["monthly"]["remaining_percent"], 60)
        self.assertIsNone(cursor["windows"]["weekly"])
        self.assertEqual(cursor["extra"][0]["label"], "auto")
        self.assertIsNone(SUPERVISOR.classify_usage_window({"label": "auto"}))
        self.assertEqual(SUPERVISOR.classify_usage_window(
            {"label": "Current session"}), "five_hour")
        self.assertEqual(SUPERVISOR.dashboard_pose("standby", True), "waiting")
        self.assertEqual(SUPERVISOR.dashboard_pose("exhausted", True), "sweating")
        self.assertEqual(SUPERVISOR.dashboard_pose("retired", False), "tombstone")
        self.assertEqual(SUPERVISOR.dashboard_pose("idle", True), "walking")
        self.assertEqual(SUPERVISOR.dashboard_pose("idle", False), "sitting")
        self.assertEqual(SUPERVISOR.dashboard_pose("unknown", False), "recovering")

    def test_parked_claims_nudge_sleeping_holders_once_per_claim_set(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text(
            "claimed\nassigned-by: jean-luc\n")
        supervisor = self.supervisor()
        # No recorded check-in at all counts as over the horizon.
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
        recipient, subject, body, thread = send.call_args.args[:4]
        self.assertEqual(recipient, "data")
        self.assertIn("Parked claims", subject)
        self.assertIn("0037-01", body)
        self.assertIn("record the handover", body)
        self.assertEqual(thread, "supervisor-claim-check")
        self.assertEqual(
            supervisor.state["claim_nudges"]["data"]["key"], "0037-01")
        # Same claim set: no second nudge.
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
        send.assert_not_called()
        # A fresh check-in stays quiet; dropping the claims re-arms the nudge.
        supervisor.agent_state("data")["last_wake"] = SUPERVISOR.now()
        (self.workspace / "TODO-data-0037-01-claim.md").unlink()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
        send.assert_not_called()
        self.assertNotIn("data", supervisor.state["claim_nudges"])

    def test_claim_lifecycle_fields_control_openness(self):
        (self.workspace / "TODO-data-0037-01-a.md").write_text(
            "claimed\nassigned-by: jean-luc\n")
        (self.workspace / "TODO-data-0037-02-b.md").write_text(
            "done\nstate: [x]\n")
        (self.workspace / "TODO-data-0037-03-c.md").write_text(
            "moving\nhandover_to: kathryn\nhandover_at: 2026-08-27T00:00:00Z\n")
        claims = SUPERVISOR.workspace_task_claims(self.workspace)
        by_id = {item["id"]: item for item in claims["data"]}
        self.assertTrue(by_id["0037-01"]["open"])
        self.assertFalse(by_id["0037-02"]["open"])
        self.assertFalse(by_id["0037-03"]["open"])
        self.assertEqual(by_id["0037-03"]["handover_to"], "kathryn")
        self.assertEqual(by_id["0037-01"]["giver"], "jean-luc")
        # Only the open claim is nudged when the holder sleeps.
        supervisor = self.supervisor()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
        body = send.call_args.args[2]
        self.assertIn("0037-01", body)
        self.assertNotIn("0037-02", body)
        self.assertNotIn("0037-03", body)

    def test_claim_lifecycle_reads_full_markdown_records(self):
        late = self.workspace / "TODO-data-0037-04-late.md"
        late.write_text("evidence\n" * 700 + "- **Status:** `[x]` — complete\n")
        (self.workspace / "TODO-data-0037-05-bold.md").write_text(
            "- **state / status:** `[x]` / `[x]`\n")
        (self.workspace / "TODO-data-0037-06-handover.md").write_text(
            "- **handover_to:** kathryn\n- **handover_at:** 2026-08-28T00:00:00Z\n")
        claims = SUPERVISOR.workspace_task_claims(self.workspace)
        by_id = {item["id"]: item for item in claims["data"]}
        self.assertGreater(late.stat().st_size, 4096)
        self.assertFalse(by_id["0037-04"]["open"])
        self.assertFalse(by_id["0037-05"]["open"])
        self.assertFalse(by_id["0037-06"]["open"])
        self.assertEqual(by_id["0037-04"]["state"], "x")
        self.assertEqual(by_id["0037-06"]["handover_to"], "kathryn")

    def test_startup_recovery_forces_dead_open_claim_holders(self):
        (self.workspace / "TODO-data-0037-01-open.md").write_text("state: [p]\n")
        (self.workspace / "TODO-worf-0038-01-open.md").write_text("state: [p]\n")
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "roster.json").write_text(json.dumps({
            "worf": {"status": "standby", "delegate": "benjamin"},
        }))
        supervisor = self.supervisor()
        supervisor.agent_state("data")["pid"] = 999999
        with mock.patch.object(SUPERVISOR, "_pid_alive", return_value=False), \
                mock.patch.object(supervisor, "interactive_session", return_value=None):
            recovered = supervisor.reconcile_startup_claims()
        self.assertEqual(recovered, {"data": ["0037-01"]})
        state = supervisor.agent_state("data")
        self.assertNotIn("pid", state)
        self.assertTrue(state["dashboard_force"])
        self.assertEqual(state["next_wake"], 0)
        self.assertEqual(state["startup_recovery_claims"], ["0037-01"])
        self.assertNotIn("startup_recovery_claims", supervisor.agent_state("worf"))

    def test_task_git_artifacts_require_exact_local_branch_and_worktree(self):
        repo = self.workspace / "task-repo"
        repo.mkdir()

        def git(*args):
            subprocess.run(["git", "-C", str(repo), *args], check=True,
                           capture_output=True)

        git("init", "-q", "-b", "main")
        git("config", "user.email", "t@example.org")
        git("config", "user.name", "t")
        (repo / "a.txt").write_text("a\n")
        git("add", "a.txt")
        git("commit", "-qm", "base")
        git("branch", "feature/0037-01-implementation")
        worktree = self.workspace / "worker-0037-01"
        git("worktree", "add", "-q", str(worktree),
            "feature/0037-01-implementation")

        evidence = SUPERVISOR.task_git_artifacts(repo, "0037-01")
        self.assertEqual(evidence["branches"],
                         ["feature/0037-01-implementation"])
        self.assertEqual([Path(path).resolve() for path in evidence["worktrees"]],
                         [worktree.resolve()])
        nested = SUPERVISOR.task_git_artifacts(repo, "0037-01.01")
        self.assertEqual(nested, {"branches": [], "worktrees": []})

    def test_busy_task_cross_check_reports_missing_evidence_once_to_lead(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text("claimed\n")
        supervisor = self.supervisor()
        presence = {"data": {"availability": "busy", "task": "0037-01",
                             "since": "2026-08-27T18:00:00Z"}}
        missing_worktree = {"branches": ["0037-01"], "worktrees": []}
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence), \
             mock.patch.object(SUPERVISOR, "task_git_artifacts",
                               return_value=missing_worktree), \
             mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.nudge_unverified_announced_tasks()
            supervisor.nudge_unverified_announced_tasks()
        self.assertEqual(send.call_count, 1)
        recipient, subject, body, thread = send.call_args.args[:4]
        self.assertEqual(recipient, "jean-luc")
        self.assertIn("Unverified busy task", subject)
        self.assertIn("worktree", body)
        self.assertNotIn("open claim,", body)
        self.assertEqual(thread, "0037-01")

        # Valid evidence clears the dedupe marker, so a later regression is
        # visible even without a fresh announce.
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence), \
             mock.patch.object(SUPERVISOR, "task_git_artifacts",
                               return_value={"branches": ["0037-01"],
                                             "worktrees": ["/tmp/0037-01"]}), \
             mock.patch.object(supervisor, "send_supervisor_message") as send:
            supervisor.nudge_unverified_announced_tasks()
        send.assert_not_called()
        self.assertNotIn("data", supervisor.state["announced_task_checks"])

    def test_busy_task_cross_check_stays_quiet_when_git_is_unknown(self):
        supervisor = self.supervisor()
        presence = {"data": {"availability": "busy", "task": "0037-01",
                             "since": "2026-08-27T18:00:00Z"}}
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence), \
             mock.patch.object(SUPERVISOR, "task_git_artifacts",
                               return_value=None), \
             mock.patch.object(supervisor, "send_supervisor_message") as send:
            supervisor.nudge_unverified_announced_tasks()
        send.assert_not_called()

    def test_busy_task_cross_check_reports_duplicate_claim_owners(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text("claimed\n")
        (self.workspace / "TODO-worf-0037-01-claim.md").write_text("claimed\n")
        supervisor = self.supervisor()
        presence = {"data": {"availability": "busy", "task": "0037-01",
                             "since": "2026-08-27T18:00:00Z"}}
        artifacts = {"branches": ["0037-01"],
                     "worktrees": ["/tmp/0037-01"]}
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence), \
             mock.patch.object(SUPERVISOR, "task_git_artifacts",
                               return_value=artifacts), \
             mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.nudge_unverified_announced_tasks()
        body = send.call_args.args[2]
        self.assertIn("unique claim ownership", body)
        self.assertIn("claim_owners=data, worf", body)

    def test_hold_announcement_triggers_handover_nudge_for_open_claims(self):
        (self.workspace / "TODO-data-0037-01-a.md").write_text("claimed\n")
        (self.workspace / "TODO-data-0037-02-b.md").write_text(
            "moving\nhandover_to: kathryn\n")
        supervisor = self.supervisor()
        presence = {"data": {"availability": "exhausted", "since": "s1",
                             "delegate": "kathryn"},
                    "worf": {"availability": "idle", "since": "s1"}}
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence), \
             mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.nudge_unhanded_claims()
            supervisor.nudge_unhanded_claims()  # same claim set: once only
            # Bouncing through idle and back on hold must not re-mail
            # (runners announce every session).
            presence["data"] = {"availability": "idle", "since": "s2"}
            supervisor.nudge_unhanded_claims()
            presence["data"] = {"availability": "standby", "since": "s3",
                                "delegate": "kathryn"}
            supervisor.nudge_unhanded_claims()
        self.assertEqual(send.call_count, 1)
        recipient, subject, body, thread = send.call_args.args[:4]
        self.assertEqual(recipient, "data")
        self.assertIn("record the handover", subject.lower())
        self.assertIn("TODO-data-0037-01-a.md", body)
        self.assertNotIn("TODO-data-0037-02-b.md", body)
        self.assertIn("handover_to: kathryn", body)
        self.assertIn("Do not delete claim files", body)
        self.assertEqual(thread, "supervisor-claim-check")
        # Only a changed claim set re-arms: routing the last open claim
        # clears the marker.
        (self.workspace / "TODO-data-0037-01-a.md").write_text(
            "moving\nhandover_to: kathryn\n")
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence):
            supervisor.nudge_unhanded_claims()
        self.assertNotIn("data", supervisor.state["handover_nudges"])

    def test_ignored_parked_nudge_escalates_once_to_the_project_lead(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text("claimed\n")
        supervisor = self.supervisor()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
        self.assertEqual(send.call_args.args[0], "data")
        # The holder woke after the nudge, recorded nothing, and is now past
        # the horizon again: escalate once to its Project Lead.
        import datetime as _dt
        awake = (_dt.datetime.now(_dt.timezone.utc)
                 - _dt.timedelta(hours=5)).isoformat(timespec="seconds")
        nudge_at = (_dt.datetime.now(_dt.timezone.utc)
                    - _dt.timedelta(hours=6)).isoformat(timespec="seconds")
        supervisor.agent_state("data")["last_wake"] = awake
        supervisor.state["claim_nudges"]["data"]["at"] = nudge_at
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
            supervisor.nudge_parked_claims()  # escalates once, not twice
        self.assertEqual(send.call_count, 1)
        leader, subject, body = send.call_args.args[:3]
        self.assertEqual(leader, "jean-luc")
        self.assertIn("Escalation", subject)
        self.assertIn("data", subject)
        self.assertIn("0037-01", body)
        # A holder that never woke after the nudge is not escalated.
        (self.workspace / "TODO-worf-0038-01-claim.md").write_text("claimed\n")
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()   # first nudge for worf
            supervisor.nudge_parked_claims()   # no wake since: no escalation
        self.assertEqual(send.call_count, 1)
        self.assertEqual(send.call_args.args[0], "worf")

    def test_parked_claims_do_not_nudge_recently_seen_holders(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text("claimed\n")
        supervisor = self.supervisor()
        supervisor.agent_state("data")["last_wake"] = SUPERVISOR.now()
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_parked_claims()
        send.assert_not_called()

    def test_integration_status_classifies_branches_and_features(self):
        repo = self.workspace / "integration-repo"
        repo.mkdir()
        commit_time = SUPERVISOR.now()
        env = {**os.environ, "GIT_AUTHOR_DATE": commit_time,
               "GIT_COMMITTER_DATE": commit_time}
        def git(*args):
            subprocess.run(["git", "-C", str(repo), *args], check=True,
                           capture_output=True, env=env)
        git("init", "-q", "-b", "main")
        git("config", "user.email", "t@example.org")
        git("config", "user.name", "t")
        (repo / "a.txt").write_text("a\n")
        git("add", "."); git("commit", "-qm", "base")
        git("branch", "0037-01")          # item branch, no own commits yet
        (repo / "b.txt").write_text("b\n")
        git("checkout", "-qb", "0037-02")
        git("add", "."); git("commit", "-qm", "item work")
        git("checkout", "-q", "main")
        git("checkout", "-qb", "review-0037-02")
        (repo / "r.txt").write_text("r\n")
        git("add", "."); git("commit", "-qm", "review evidence")
        git("checkout", "-q", "main")
        git("checkout", "-qb", "0039-01")
        (repo / "c.txt").write_text("c\n")
        git("add", "."); git("commit", "-qm", "merged work")
        git("checkout", "-q", "main")
        git("merge", "-q", "--no-ff", "-m", "integrate 0039-01", "0039-01")
        (repo / "claims.txt").write_text("claim\n")
        git("add", "."); git("commit", "-qm", "bookkeeping(0037): claim recorded")
        status = SUPERVISOR.integration_status(repo)
        # Self-generated throughput: base + merge are substance, the
        # bookkeeping commit is meta.
        self.assertEqual(status["commits_24h"], 3)
        self.assertEqual(status["meta_24h"], 1)
        self.assertEqual(status["queue"], 1)          # only 0037-02 waits
        self.assertEqual(status["evidence"], 1)       # review-* is terminal
        self.assertEqual(status["stale_merged"], 2)   # 0039-01 and 0037-01
        self.assertEqual(status["features"][0]["feature"], "0037")
        self.assertEqual(status["features"][0]["queue"], 1)
        self.assertEqual(status["features"][0]["ahead"], 1)
        self.assertEqual(status["features"][0]["newest_branch"], "0037-02")
        self.assertEqual(len(status["features"][0]["newest_oid"]), 40)
        self.assertEqual(len(status["main_oid"]), 40)
        self.assertEqual(status["oldest"]["branch"], "0037-02")
        self.assertEqual(status["queue_branches"][0]["branch"], "0037-02")
        self.assertEqual(status["oldest_queued"][0]["branch"], "0037-02")
        self.assertEqual(status["evidence_branches"][0]["branch"],
                         "review-0037-02")
        self.assertEqual(
            {item["branch"] for item in status["merged_branches"]},
            {"0037-01", "0039-01"})
        self.assertEqual(len(status["inflow_7d"]), 7)
        self.assertEqual(len(status["outflow_7d"]), 7)
        self.assertIsNone(SUPERVISOR.integration_status(self.workspace / "nope"))
        # Root watchdog reads branch and tracked dirt from the same repo.
        clean = SUPERVISOR.workspace_root_status(repo)
        self.assertEqual(clean["branch"], "main")
        self.assertEqual(clean["dirty_tracked"], 0)
        (repo / "a.txt").write_text("changed\n")
        (repo / "untracked.md").write_text("drop\n")
        dirty = SUPERVISOR.workspace_root_status(repo)
        self.assertEqual(dirty["dirty_tracked"], 1)  # untracked is fine
        self.assertIn("a.txt", dirty["dirty_files"])
        supervisor = self.supervisor()
        supervisor.args.workspace = repo
        scope = supervisor.integration_delegation_scope(
            "branch", "0037-02", status["oldest_queued"][0]["oid"])
        self.assertIn("0037-02@", scope["detail"])
        evidence_scope = supervisor.integration_delegation_scope(
            "category_branch", "review-0037-02",
            status["evidence_branches"][0]["oid"])
        self.assertEqual(evidence_scope["label"], "Branch review-0037-02")
        multi = supervisor.integration_delegation_scopes([
            {"kind": "branch", "value": "0037-02",
             "expected_oid": status["oldest_queued"][0]["oid"]},
            {"kind": "category_branch", "value": "review-0037-02",
             "expected_oid": status["evidence_branches"][0]["oid"]},
        ], legacy={})
        self.assertEqual(multi["kind"], "multi")
        self.assertEqual(multi["label"], "2 ausgewählte Branches")
        self.assertEqual(len(multi["scopes"]), 2)
        self.assertEqual(multi["thread"], "integration-selection")
        with self.assertRaisesRegex(ValueError, "branch .* moved"):
            supervisor.integration_delegation_scope(
                "branch", "0037-02", "0" * 40)

    def test_runtime_board_publishes_exit_classes_and_open_claims(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text("claimed\n")
        supervisor = self.supervisor()
        supervisor.agent_state("data")["last_exit"] = -15
        supervisor.agent_state("worf")["last_exit"] = 1
        board = supervisor.publish_runtime_board()
        agents = board["agents"]
        self.assertEqual(agents["data"]["exit_class"], "killed")
        self.assertEqual(agents["data"]["open_claims"],
                         ["TODO-data-0037-01-claim.md"])
        self.assertEqual(agents["worf"]["exit_class"], "failed")
        self.assertEqual(agents["kathryn"]["exit_class"], "clean")
        self.assertEqual(agents["data"]["team"], "Enterprise")
        disk = json.loads(
            (self.store / "data" / "runtime.json").read_text(encoding="utf-8"))
        self.assertIn("generated_at", disk)
        self.assertEqual(disk["agents"]["data"]["exit_class"], "killed")

    def test_aborted_session_with_open_claims_reports_to_the_project_lead(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text("claimed\n")
        supervisor = self.supervisor()
        supervisor.agent_state("data")["last_exit"] = -15
        supervisor.agent_state("data")["last_log"] = "/logs/data-1.jsonl"
        # Killed without work in flight: remembered, but no report.
        supervisor.agent_state("worf")["last_exit"] = 143
        supervisor.agent_state("worf")["last_log"] = "/logs/worf-1.jsonl"
        # Ordinary failure is not an abort.
        supervisor.agent_state("tasha")["last_exit"] = 1
        supervisor.agent_state("tasha")["last_log"] = "/logs/tasha-1.jsonl"
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_aborted_sessions()
            supervisor.nudge_aborted_sessions()  # one report per session
        self.assertEqual(send.call_count, 1)
        leader, subject, body, thread = send.call_args.args[:4]
        self.assertEqual(leader, "jean-luc")
        self.assertIn("Aborted session", subject)
        self.assertIn("data", subject)
        self.assertIn("TODO-data-0037-01-claim.md", body)
        self.assertIn("restart the task", body)
        self.assertEqual(thread, "supervisor-abort-check")
        self.assertEqual(supervisor.state["abort_reports"]["worf"],
                         "/logs/worf-1.jsonl")
        # A new aborted session of the same holder is reported again.
        supervisor.agent_state("data")["last_log"] = "/logs/data-2.jsonl"
        with mock.patch.object(
                supervisor, "send_supervisor_message", return_value=True) as send:
            supervisor.nudge_aborted_sessions()
        self.assertEqual(send.call_count, 1)

    def test_pl_mail_load_buckets_exception_vs_routine(self):
        import datetime as _dt
        fresh = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        old = (_dt.datetime.now(_dt.timezone.utc)
               - _dt.timedelta(days=9)).isoformat(timespec="seconds")
        self._journal(
            {"id": "m1", "ts": fresh, "sender": "kathryn", "to": "michael",
             "subject": "OFFER: root cleanup", "body": "round"},
            {"id": "m2", "ts": fresh, "sender": "kathryn", "to": "benjamin",
             "subject": "NEIN — ich führe das nicht aus",
             "body": "dein Lagebild ist veraltet, STOP"},
            {"id": "m3", "ts": fresh, "sender": "kathryn", "to": "worf",
             "subject": "Gedanken zum Wetter", "body": "smalltalk"},
            {"id": "m4", "ts": old, "sender": "kathryn", "to": "worf",
             "subject": "OFFER: ancient", "body": "outside the window"},
            {"id": "m5", "ts": fresh, "sender": "wesley", "to": "kathryn",
             "subject": "OFFER: not a lead", "body": "ignored"},
        )
        supervisor = self.supervisor()
        load = {entry["name"]: entry for entry in supervisor.pl_mail_load()}
        self.assertEqual(set(load), {"kathryn"})
        entry = load["kathryn"]
        self.assertEqual(entry["routine"], 1)
        self.assertEqual(entry["exception"], 1)
        self.assertEqual(entry["other"], 1)
        self.assertEqual(entry["total"], 3)
        self.assertEqual(entry["exception_share"], 33)

    def test_root_watchdog_alerts_leads_once_per_contamination(self):
        supervisor = self.supervisor()
        with mock.patch.object(
                SUPERVISOR, "workspace_root_status",
                return_value={"branch": "0047-x", "dirty_tracked": 2,
                              "dirty_files": ["core-rules.md"]}), \
             mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.watch_workspace_root()
            supervisor.watch_workspace_root()  # same signature: no repeat
        leads = {call.args[0] for call in send.call_args_list}
        self.assertIn("jean-luc", leads)
        self.assertIn("kathryn", leads)
        self.assertIn("ROOT ALERT", send.call_args.args[1])
        self.assertEqual(len(send.call_args_list), len(leads))
        with mock.patch.object(
                SUPERVISOR, "workspace_root_status",
                return_value={"branch": "main", "dirty_tracked": 0,
                              "dirty_files": []}):
            supervisor.watch_workspace_root()   # clean root re-arms
        self.assertNotIn("root_alert", supervisor.state)

    def test_integration_digest_goes_to_leads_and_integrators_once_a_day(self):
        supervisor = self.supervisor()
        status = {"queue": 3, "stale_merged": 5, "evidence": 2,
                  "oldest_queued": [
                      {"branch": "0041-03", "date": "2026-08-18",
                       "age_days": 9}],
                  "features": [{"feature": "0037", "queue": 2, "ahead": 160,
                                "behind": 4, "oldest_age_days": 5}]}
        with mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.send_integration_digest(status)
            supervisor.send_integration_digest(status)  # once per day
        recipients = {call.args[0] for call in send.call_args_list}
        self.assertIn("geordi", recipients)    # Integrator
        self.assertIn("belanna", recipients)   # Integrator
        self.assertIn("kathryn", recipients)   # Project Lead
        body = send.call_args.args[2]
        self.assertIn("0041-03", body)
        self.assertIn("oldest first", body)
        self.assertIn("0037: 2 open, +160/-4", body)
        self.assertEqual(len(send.call_args_list), len(recipients))

    def test_workspace_task_claims_stay_in_the_workspace_root(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text(
            "claimed\nassigned-by: jean-luc\n")
        nested = self.workspace / ".worktrees" / "0037-01"
        nested.mkdir(parents=True)
        (nested / "TODO-data-0038-99-nested.md").write_text("ignore\n")
        (self.workspace / "subdir").mkdir()
        (self.workspace / "subdir" / "TODO-jean-luc-0039-01-nested.md").write_text("ignore\n")
        claims = SUPERVISOR.workspace_task_claims(self.workspace)
        self.assertEqual(claims["data"][0]["id"], "0037-01")
        self.assertEqual(claims["data"][0]["giver"], "jean-luc")
        self.assertNotIn("jean-luc", claims)
        self.assertEqual(len(claims["data"]), 1)

    def test_snapshot_reports_usage_claims_profile_and_key(self):
        (self.workspace / "TODO-data-0037-01-claim.md").write_text(
            "claimed\nassigned-by: jean-luc\n")
        profile = self.args.codex_profiles / "data.config.toml"
        profile.parent.mkdir(parents=True)
        profile.write_text("profile\n")
        generation = "gen-1"
        SUPERVISOR.atomic_json(
            self.state / SUPERVISOR.PROFILE_GENERATION_FILE,
            {"generation": generation},
        )
        applied = self.state / SUPERVISOR.PROFILE_APPLIED_DIR / "data.json"
        applied.parent.mkdir(parents=True)
        SUPERVISOR.atomic_json(applied, {"generation": generation})
        latest = SUPERVISOR.agent_keys.key_dir(self.args.keys_root, "data", self.supervisor().agents["data"])
        latest.mkdir(parents=True)
        hashed = SUPERVISOR.agent_keys.hashed_key_name("profile\n")
        (latest / hashed).write_text("key\n")
        (latest / SUPERVISOR.agent_keys.KEY_BASENAME).symlink_to(hashed)

        supervisor = self.supervisor()
        supervisor.state["usage"] = {"codex": {
            "provider": "codex",
            "windows": [{"label": "5h", "remaining_percent": 22, "duration_minutes": 300}],
        }}
        with mock.patch.object(supervisor, "unread", return_value=[]):
            snap = supervisor.dashboard_snapshot()
        self.assertEqual(snap["horizon_seconds"], SUPERVISOR.DASHBOARD_HORIZON_SECONDS)
        self.assertEqual(
            snap["usage"]["codex"]["windows"]["five_hour"]["remaining_percent"], 22)
        data = snap["agents"]["data"]
        self.assertEqual(data["assigned"], "0037-01")
        self.assertEqual(data["task_count"], 1)
        self.assertEqual(data["profile"]["status"], "current")
        self.assertEqual(data["git_key"]["status"], "current")
        self.assertIn("Enterprise", [team["name"] for team in snap["teams"]])
        self.assertFalse(data["active"])
        self.assertEqual(data["status"], "recovering")
        self.assertEqual(data["availability"], "unknown")
        self.assertEqual(data["pose"], "ghost")
        self.assertEqual(data["task_giver"], "jean-luc")
        self.assertIsNone(data["working_for_seconds"])

    def test_snapshot_busy_agent_reports_work_duration_and_upcoming_tasks(self):
        supervisor = self.supervisor()
        supervisor.agent_state("data")["last_wake"] = "2026-08-26T18:00:00+00:00"
        claims = {"data": [{"id": "0037-01", "file": "TODO-data-0037-01.md",
                            "giver": "kathryn"},
                           {"id": "0037-02", "file": "TODO-data-0037-02.md"}]}
        with mock.patch.object(supervisor, "unread_counts", return_value={"data": 0}), \
                mock.patch.object(supervisor, "agent_run_status", return_value="running"), \
                mock.patch.object(SUPERVISOR.time, "time", return_value=SUPERVISOR.iso_to_epoch(
                    "2026-08-26T18:10:00+00:00")):
            snap = supervisor.dashboard_snapshot(claims=claims)
        data = snap["agents"]["data"]
        self.assertTrue(data["active"])
        self.assertEqual(data["working_for_seconds"], 600)
        self.assertEqual(data["upcoming_tasks"], ["0037-01", "0037-02"])
        self.assertEqual(data["pose"], "walking")
        self.assertEqual(data["task_giver"], "kathryn")

    def test_snapshot_excludes_closed_and_deduplicates_open_claims(self):
        claims = {"data": [
            {"id": "0037-01", "file": "closed.md", "open": False},
            {"id": "0037-02", "file": "open-a.md", "open": True},
            {"id": "0037-02", "file": "open-b.md", "open": True},
        ]}
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "unread_counts", return_value={}):
            snap = supervisor.dashboard_snapshot(claims=claims)
        data = snap["agents"]["data"]
        self.assertEqual(data["assigned_tasks"], ["0037-02"])
        self.assertEqual(data["upcoming_tasks"], ["0037-02"])
        self.assertEqual(data["task_count"], 1)

    def test_snapshot_standby_and_retired_map_to_sit_and_tombstone(self):
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "roster.json").write_text(json.dumps({
            "data": {"status": "standby", "delegate": "geordi"},
            "worf": {"status": "retired"},
        }), encoding="utf-8")
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "unread_counts", return_value={}):
            snap = supervisor.dashboard_snapshot(claims={})
        self.assertEqual(snap["agents"]["data"]["pose"], "waiting")
        self.assertEqual(snap["agents"]["data"]["availability"], "standby")
        self.assertEqual(snap["agents"]["worf"]["pose"], "tombstone")

    def test_snapshot_expires_old_announced_status_to_sleeping(self):
        now = SUPERVISOR.iso_to_epoch("2026-08-28T12:00:00+00:00")
        stale = "2026-08-28T07:59:59+00:00"
        fresh = "2026-08-28T08:00:01+00:00"
        presence = {
            "data": {"availability": "busy", "since": stale},
            "geordi": {"availability": "standby", "since": stale},
            "tasha": {"availability": "exhausted", "since": stale},
            "worf": {"availability": "retired", "since": stale},
            "kathryn": {"availability": "standby", "since": fresh},
        }
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "mailbox_presence",
                               return_value=presence), \
                mock.patch.object(supervisor, "unread_counts", return_value={}), \
                mock.patch.object(SUPERVISOR.time, "time", return_value=now):
            snap = supervisor.dashboard_snapshot(claims={})
        for name in ("data", "geordi", "tasha"):
            self.assertEqual(snap["agents"][name]["status"], "sleeping")
            self.assertEqual(snap["agents"][name]["pose"], "sleeping")
            self.assertGreater(snap["agents"][name]["status_age_seconds"],
                               SUPERVISOR.DASHBOARD_HORIZON_SECONDS)
        self.assertEqual(snap["agents"]["worf"]["pose"], "tombstone")
        self.assertEqual(snap["agents"]["kathryn"]["pose"], "waiting")

    def test_active_runtime_overrides_old_announced_status(self):
        now = SUPERVISOR.iso_to_epoch("2026-08-28T12:00:00+00:00")
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "mailbox_presence", return_value={
                    "data": {"availability": "busy",
                             "since": "2026-08-28T07:00:00+00:00"},
                }), \
                mock.patch.object(supervisor, "unread_counts", return_value={}), \
                mock.patch.object(supervisor, "agent_run_status",
                                  side_effect=lambda name, _count: (
                                      "running" if name == "data" else "idle")), \
                mock.patch.object(SUPERVISOR.time, "time", return_value=now):
            data = supervisor.dashboard_snapshot(claims={})["agents"]["data"]
        self.assertTrue(data["active"])
        self.assertEqual(data["status"], "running")
        self.assertEqual(data["pose"], "walking")

    def test_old_life_sign_sleeps_but_never_seen_agent_is_ghost(self):
        now = SUPERVISOR.iso_to_epoch("2026-08-28T12:00:00+00:00")
        supervisor = self.supervisor()
        supervisor.agent_state("data")["last_finished"] = (
            "2026-08-28T07:00:00+00:00")
        with mock.patch.object(supervisor, "mailbox_presence", return_value={}), \
                mock.patch.object(supervisor, "unread_counts", return_value={}), \
                mock.patch.object(SUPERVISOR.time, "time", return_value=now):
            agents = supervisor.dashboard_snapshot(claims={})["agents"]
        self.assertEqual(agents["data"]["pose"], "sleeping")
        self.assertEqual(agents["data"]["status"], "sleeping")
        self.assertEqual(agents["guinan"]["pose"], "ghost")
        self.assertEqual(agents["guinan"]["status"], "unknown")

    def test_snapshot_task_giver_from_mailbox_thread(self):
        (self.store / "data").mkdir(parents=True)
        (self.store / "data" / "messages.jsonl").write_text(
            json.dumps({
                "id": "m1", "ts": "2026-08-26T18:00:00Z",
                "sender": "jean-luc", "to": "data", "thread": "0037-01",
                "subject": "assign",
            }) + "\n",
            encoding="utf-8",
        )
        supervisor = self.supervisor()
        claims = {"data": [{"id": "0037-01", "file": "TODO-data-0037-01.md", "giver": ""}]}
        with mock.patch.object(supervisor, "unread_counts", return_value={"data": 0}):
            snap = supervisor.dashboard_snapshot(claims=claims)
        self.assertEqual(snap["agents"]["data"]["task_giver"], "jean-luc")

    def test_dashboard_hold_skips_launch_and_force_wakes_without_mail(self):
        supervisor = self.supervisor()
        supervisor.args.max_parallel = 10
        selected = [("data", supervisor.agents["data"], "codex")]
        supervisor.agent_state("data")["dashboard_hold"] = True
        with mock.patch.object(supervisor, "selected", return_value=selected), \
                mock.patch.object(supervisor, "rotate_codex_rollouts"), \
                mock.patch.object(supervisor, "archive_messages"), \
                mock.patch.object(supervisor, "poll_usage"), \
                mock.patch.object(supervisor, "unread", return_value=[{"id": "m1"}]), \
                mock.patch.object(supervisor, "launch") as launch:
            supervisor.tick()
        launch.assert_not_called()

        supervisor.agent_state("data")["dashboard_hold"] = False
        supervisor.agent_state("data")["dashboard_force"] = True
        with mock.patch.object(supervisor, "selected", return_value=selected), \
                mock.patch.object(supervisor, "rotate_codex_rollouts"), \
                mock.patch.object(supervisor, "archive_messages"), \
                mock.patch.object(supervisor, "poll_usage"), \
                mock.patch.object(supervisor, "unread", return_value=[]), \
                mock.patch.object(supervisor, "retry_ready", return_value=True), \
                mock.patch.object(supervisor, "launch", return_value=True) as launch:
            supervisor.tick()
        launch.assert_called_once()
        self.assertNotIn("dashboard_force", supervisor.agent_state("data"))

    def test_dashboard_commands_start_stop_reload_and_stop_all(self):
        supervisor = self.supervisor()
        supervisor.enqueue_dashboard_command(
            {"action": "stop", "scope": "agent", "target": "data"})
        supervisor.enqueue_dashboard_command(
            {"action": "start", "scope": "agent", "target": "data"})
        with mock.patch.object(supervisor, "stop_agent_process") as stop:
            self.assertTrue(supervisor.apply_dashboard_commands())
        stop.assert_called_once_with("data")
        state = supervisor.agent_state("data")
        self.assertFalse(state["dashboard_hold"])
        self.assertTrue(state["dashboard_force"])

        marker = supervisor.state_dir / SUPERVISOR.PROFILE_APPLIED_DIR / "data.json"
        marker.parent.mkdir(parents=True)
        marker.write_text("{}\n")
        supervisor.apply_dashboard_command(
            {"action": "reload", "scope": "agent", "target": "data"})
        self.assertFalse(marker.exists())

        supervisor.apply_dashboard_command({"action": "stop", "scope": "all"})
        self.assertTrue(supervisor.stopping)
        supervisor.apply_dashboard_command({"action": "reload", "scope": "all"})
        self.assertTrue(supervisor.reload_requested)

    def test_reload_respawns_a_running_dashboard_but_not_a_headless_one(self):
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "_load_roster_configuration"), \
                mock.patch.object(supervisor, "begin_profile_generation"), \
                mock.patch.object(supervisor, "poll_usage"), \
                mock.patch.object(supervisor, "stop_dashboard") as stop, \
                mock.patch.object(supervisor, "start_dashboard") as start:
            supervisor.reload_configuration()   # headless: nothing to bounce
            stop.assert_not_called()
            start.assert_not_called()
            supervisor.dashboard_process = mock.Mock()
            supervisor.reload_configuration()
            stop.assert_called_once()
            start.assert_called_once()

    def test_start_dashboard_only_in_run_and_spawns_python_gui(self):
        (self.config / "supervisor-gui.py").write_text("# stub\n")
        supervisor = self.supervisor()
        supervisor.args.command = "once"
        with mock.patch.object(SUPERVISOR.subprocess, "Popen") as popen:
            supervisor.start_dashboard()
        popen.assert_not_called()
        self.assertIsNone(supervisor.dashboard_process)

        supervisor.args.command = "run"
        with mock.patch.object(SUPERVISOR.subprocess, "Popen") as popen:
            supervisor.start_dashboard()  # run without --gui stays headless
        popen.assert_not_called()

        supervisor.args.gui = True
        fake = mock.Mock()
        with mock.patch.object(SUPERVISOR.subprocess, "Popen", return_value=fake) as popen:
            supervisor.start_dashboard()
        popen.assert_called_once()
        argv = popen.call_args[0][0]
        self.assertEqual(argv[0], SUPERVISOR.sys.executable)
        self.assertEqual(Path(argv[1]).name, "supervisor-gui.py")
        self.assertEqual(Path(argv[2]).resolve(), self.state.resolve())
        self.assertEqual(supervisor.dashboard_process, fake)
        self.assertTrue((self.state / SUPERVISOR.DASHBOARD_SNAPSHOT_FILE).is_file())


class NativeGuiLaunchTests(unittest.TestCase):
    def test_supervisor_gui_uses_runner_host_jxa_appkit_tooling(self):
        source = (HERE / "supervisor.py").read_text()
        self.assertIn('"/usr/bin/osascript", "-l", "JavaScript"', source)
        self.assertIn('str(args.inbox / "roster-gui.js")', source)
        self.assertIn('self.inbox / "supervisor-gui.py"', source)
        self.assertNotIn("roster_gui_main", source)
        self.assertIn('if getattr(self.args, "command", None) != "run":', source)
        once_block = source[source.index('if args.command == "once":'):
                            source.index("supervisor.start_dashboard()")]
        self.assertNotIn("start_dashboard", once_block)
        git_key = source[source.index("def git_key_status"):
                         source.index("def agent_run_status")]
        self.assertIn("inspect_key", git_key)
        self.assertNotIn("ensure_key", git_key)

    def test_native_gui_declares_appkit_and_has_headless_self_test(self):
        source = (HERE / "roster-gui.js").read_text()
        self.assertIn('ObjC.import("AppKit")', source)
        self.assertIn('ObjC.import("Foundation")', source)
        self.assertIn('args[0] === "--self-test"', source)
        self.assertIn("NSApplicationActivationPolicyRegular", source)
        self.assertIn("ui.policyRows = {}", source)
        self.assertIn("ui.providerRows = {}", source)
        self.assertIn("ui.agentScroll = $.NSScrollView", source)
        self.assertIn('name: "RosterFlippedView"', source)
        self.assertIn("function sortedAgentsByRole()", source)
        self.assertIn("function rebuildAgentList(focusName)", source)
        self.assertIn("function rebuildRolePolicyView(focusRole)", source)
        self.assertIn("function rebuildCapabilityView(focusCapability)", source)
        self.assertIn("function addCapability(name)", source)
        self.assertIn("function removeCapability(name)", source)
        self.assertIn("function addCapabilitySet(name)", source)
        self.assertIn("function removeCapabilitySet(name)", source)
        self.assertIn("ui.teamFilterControl = $.NSSegmentedControl", source)
        self.assertIn("$.NSSegmentSwitchTrackingSelectAny", source)
        self.assertIn("sender.isSelectedForSegment(index)", source)
        self.assertNotIn("updateTeamFilterButton", source)
        self.assertNotIn("setContentTintColor", source)
        self.assertIn("function renameCapability(oldName, requestedName)", source)
        self.assertIn("function teamDefaultProviderChanged(sender)", source)
        self.assertIn("function addProvider(name, templateName)", source)
        self.assertIn("function rebuildProviderView()", source)
        self.assertIn("function editorString(view)", source)
        self.assertIn("function restoreClipOriginY(scrollView, y)", source)
        self.assertIn('provider.setAction("agentProviderChanged:")', source)
        self.assertIn("ui.agentAssignments[name] = {team, role: rolePopup, provider}", source)
        self.assertIn('return ["default"].concat(providerNames())', source)
        self.assertIn('choice === "default"', source)
        self.assertIn("makePopup($.NSMakeRect(426, y, 332, 28)", source)
        self.assertIn("makePopup($.NSMakeRect(766, y, 110, 28)", source)
        self.assertIn("function installEditMenu()", source)
        self.assertIn("selectAll:", source)
        self.assertIn("$.NSTextView.alloc.initWithFrame", source)
        self.assertIn('popup.setAction("teamDefaultProviderChanged:")', source)
        self.assertIn('row.name.setAction("capabilityNameChanged:")', source)
        self.assertIn("label.setFrameRotation(-90)", source)
        self.assertIn("ui.previewScroll = $.NSScrollView", source)
        self.assertIn("ui.preview = $.NSTextView", source)
        self.assertIn("ui.previewAgentPopup = makePopup", source)
        self.assertIn("function sortedPreviewAgentNames()", source)
        self.assertIn('ui.previewAgentPopup.setAction("previewSelectionChanged:")', source)
        self.assertIn("guideHint.setToolTip(guide)", source)
        self.assertIn("function makeRule(frame)", source)
        self.assertIn('disclosure.setAction("toggleAgent:")', source)
        self.assertIn('popup.setAction("agentAssignmentChanged:")', source)
        self.assertIn('ui.teamFilterControl.setAction("teamFilterChanged:")', source)
        self.assertIn("ui.agentNoMatchesNotice = noMatches", source)
        self.assertIn("row.behavioralPatterns = makeMultiline", source)
        self.assertIn('disclosure.setAction("toggleRole:")', source)
        self.assertIn('disclosure.setAction("toggleCapability:")', source)
        self.assertIn('check.setAction("capabilityMembershipChanged:")', source)
        self.assertIn('"+", "addCapability:"', source)
        self.assertIn('"−", "removeCapability:"', source)
        self.assertIn('"Capabilities", "Providers & models"', source)
        self.assertIn("logs/agent-memory/agents/{agent}.md", source)
        self.assertNotIn("Path: .memory/", source)
        self.assertIn("roster.predefined_capability_sets.includes(name)", source)
        self.assertNotIn("ui.teamTabs = $.NSSegmentedControl", source)
        self.assertNotIn("ui.policyRole = makePopup", source)
        self.assertNotIn("ui.providerPopup = makePopup", source)
        self.assertIn("ui.capabilitySetOrder = Object.keys(roster.capability_sets);", source)
        self.assertIn('showAlert("Validation passed"', source)
        self.assertIn('args[0] === "--self-test-ui"', source)
        self.assertIn('NSMakeRect(20, 568, 700, 24)', source)

    def test_native_gui_interaction_self_test_recalculates_persona_view(self):
        result = subprocess.run(
            ["/usr/bin/osascript", "-l", "JavaScript", str(HERE / "roster-gui.js"),
             "--self-test-ui", str(HERE / "agents.json")],
            text=True, capture_output=True, timeout=20, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("50 collapsible personae, empty roles, colored team filters, role patterns, capabilities, and memory governance", result.stdout + result.stderr)

    def test_dashboard_gui_declares_track_hud_and_has_headless_self_test(self):
        source = (HERE / "supervisor-gui.py").read_text()
        self.assertNotIn("import tkinter as tk", source)
        self.assertIn('--self-test', source)
        self.assertIn("dashboard-commands.jsonl", source)
        self.assertIn("drawInstrument", source)
        self.assertIn("drawPerson", source)
        self.assertIn("drawSitting", source)
        self.assertIn("drawTombstone", source)
        self.assertIn("drawChair", source)
        self.assertIn("drawFootsteps", source)
        self.assertIn("teamBands", source)
        self.assertIn("separateAvatars", source)
        self.assertIn("nameGoesLeft", source)
        self.assertIn("drawAgentName", source)
        self.assertIn("showTaskMarks", source)
        self.assertIn("NOW_AVATAR_PAD", source)
        self.assertIn("status_age_seconds", source)
        self.assertIn('pose === "sleeping"', source)
        self.assertIn('pose === "ghost"', source)
        self.assertIn("const progress = Math.max(0, span) / LOG_T_MIN", source)
        self.assertIn("avatarX + (timelineX - avatarX) * progress", source)
        self.assertIn("log time since last check-in", source)
        self.assertIn("upcoming_tasks", source)
        self.assertIn("sitting = idle", source)
        self.assertIn("standing = unknown/recovering", source)
        self.assertIn("slumped + battery = exhausted", source)
        self.assertIn("paused = standby", source)
        self.assertIn("drawBubble", source)
        self.assertIn('scope: "all"', source)
        self.assertNotIn('enqueue(self.state_dir, a, "agent"', source)
        self.assertNotIn("ensure_key", source)

    def test_dashboard_gui_self_test_builds_the_window(self):
        result = subprocess.run(
            [sys.executable, str(HERE / "supervisor-gui.py"), "--self-test"],
            text=True, capture_output=True, timeout=20, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn(
            "OK crew dashboard: round instruments, team track, chairs, footsteps",
            result.stdout + result.stderr,
        )

    def test_python_gui_module_is_headless_backend_without_tk(self):
        source = (HERE / "roster_gui.py").read_text()
        self.assertNotIn("import tkinter", source)
        self.assertIn("Headless validation/save backend", source)
        self.assertIn('"generate-profiles"', source)
        self.assertNotIn("from profile_generator import atomic_write, generate,", source)


class IntegratorAvailabilityPolicyTests(SupervisorNativeSessionTests):
    def test_integrators_are_selected_by_default(self):
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "runtime", return_value="codex"):
            selected = {name for name, _config, _runtime in supervisor.selected()}
        self.assertIn("geordi", selected)
        self.assertIn("belanna", selected)
        self.assertIn("obrien", selected)
        self.assertIn("paul", selected)

    def test_runners_are_launchable_under_the_invocation_contract(self):
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "runtime", return_value="codex"):
            selected = {name for name, _config, _runtime in supervisor.selected()}
        self.assertLessEqual({"kes", "guinan", "quark", "ash"}, selected)
        self.assertTrue(supervisor.invocation_defined(supervisor.agents["guinan"]))

    def test_integrator_wake_prompt_is_idle_and_assignment_gated(self):
        supervisor = self.supervisor()
        prompt = supervisor.wake_prompt("geordi", supervisor.agents["geordi"], ["m1"])
        self.assertIn("announce 'idle'", prompt)
        self.assertIn("normal offer rounds", prompt)
        self.assertIn("Project Lead", prompt)
        self.assertIn("Wake-up never creates independence", prompt)
        self.assertIn("exact scope-and-baseline assignment", prompt)
        self.assertNotIn("scan for work", prompt.split("They do not", 1)[0])

    def test_wake_prompt_templates_come_from_agents_json_live(self):
        supervisor = self.supervisor()
        path = self.config / "agents.json"
        roster = json.loads(path.read_text())
        roster.setdefault("coordination_policy", {})["wake_prompt"] = {
            "base": "Wecken {name}: {count} Mails ({ids}).",
            "tail": "Danach Feierabend.",
        }
        path.write_text(json.dumps(roster))
        # No reload, no restart: the template is re-read when the file changes.
        prompt = supervisor.wake_prompt("data", supervisor.agents["data"], ["m1", "m2"])
        self.assertEqual(prompt, "Wecken data: 2 Mails (m1, m2). Danach Feierabend.")

    def test_project_lead_prompt_escalates_dispatcher_problem_and_checkpoint(self):
        supervisor = self.supervisor()
        prompt = supervisor.wake_prompt("jean-luc", supervisor.agents["jean-luc"], ["m2"])
        self.assertIn("Dispatcher reports a problem", prompt)
        self.assertIn("checkpoint blocks work", prompt)
        self.assertIn("team Integrator", prompt)
        self.assertIn("genuine remaining human choice", prompt)

    def test_profiles_contain_team_specific_escalation_contract(self):
        from profile_generator import instructions
        roster = SUPERVISOR.load_roster(HERE / "agents.json")
        leader = instructions(roster, "jean-luc", roster["agents"]["jean-luc"])
        integrator = instructions(roster, "geordi", roster["agents"]["geordi"])
        self.assertIn("Team Integrator candidates: `geordi`", leader)
        self.assertIn("PROJECT LEAD DECISION ROUTING", leader)
        self.assertIn("DECISION NEEDED", leader)
        self.assertIn("INTEGRATOR AVAILABILITY", integrator)
        self.assertIn("Direct current-user/registered-authority instructions remain effective", leader)
        self.assertIn("repository-native role names and record literals remain valid", leader)
        self.assertIn("MAILBOX DISCIPLINE", leader)
        self.assertIn("Decision requests: For a Management decision template call decision_request", integrator)
        self.assertIn("1,000 characters", leader)
        michael = instructions(roster, "michael", roster["agents"]["michael"])
        self.assertIn("ack that exact id before ending the turn", michael)
        self.assertIn("never send CONTINUE", michael)
        if len(leader) >= 7000:
            print(f"WARN: leader profile is {len(leader)} chars (soft limit 7000)",
                  file=sys.stderr)
        # Leaders get a larger budget by explicit management decision
        # (2026-08-27): the analysis-driven steering routine is worth the
        # tokens. Ordinary profiles keep the tighter cap.
        self.assertLess(len(leader), 15000)
        ordinary = [instructions(roster, name, agent) for name, agent in roster["agents"].items() if agent["role"] != "Project Lead"]
        if max(map(len, ordinary)) >= 6000:
            print(f"WARN: largest ordinary profile is {max(map(len, ordinary))} "
                  f"chars (soft limit 6000)", file=sys.stderr)
        self.assertLess(max(map(len, ordinary)), 10000)


class RosterGuiDocumentTests(unittest.TestCase):
    def setUp(self):
        from roster_gui import RosterDocument
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.path = self.root / "agents.json"
        shutil.copy2(HERE / "agents.json", self.path)
        self.doc = RosterDocument(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def agent_values(self, name, team=None, role=None, provider=None):
        a = self.doc.data["agents"][name]
        values = {"display_name": a["display_name"], "team": team or a["team"], "role": role or a["role"], "role_practice": a["role_practice"]}
        values.update(a["personality"])
        if provider is not None:
            values["provider"] = provider
        return values

    def test_agent_move_updates_team_membership_and_provider(self):
        self.doc.update_agent("worf", self.agent_values("worf", team="Enterprise"))
        self.assertEqual(self.doc.data["agents"]["worf"]["provider"], "codex")
        self.assertIn("worf", self.doc.data["teams"]["Enterprise"]["members"])
        self.assertNotIn("worf", self.doc.data["teams"]["DeepSpace9"]["members"])
        self.doc.validate()

    def test_agent_keeps_provider_override_when_moving_teams(self):
        self.doc.data["agents"]["worf"]["provider"] = "cursor"
        self.doc.update_agent("worf", self.agent_values("worf", team="Enterprise"))
        self.assertEqual(self.doc.data["agents"]["worf"]["provider"], "cursor")
        self.doc.validate()

    def test_agent_explicit_provider_overrides_team_default(self):
        self.doc.update_agent("worf", self.agent_values("worf", provider="claude"))
        self.assertEqual(self.doc.data["agents"]["worf"]["provider"], "claude")
        self.assertEqual(self.doc.data["agents"]["worf"]["team"], "DeepSpace9")
        self.doc.validate()

    def test_role_policy_propagates_to_all_matching_agents(self):
        self.doc.update_role_policy("Dispatcher", "standard", "medium", "unprivileged")
        dispatchers = [a for a in self.doc.data["agents"].values() if a["role"] == "Dispatcher"]
        self.assertTrue(dispatchers)
        self.assertTrue(all(a["effort"] == "medium" for a in dispatchers))
        self.doc.validate()

    def test_save_is_atomic_validated_and_backed_up(self):
        self.doc.update_agent("data", self.agent_values("data"))
        self.doc.data["agents"]["data"]["display_name"] = "Data, Operations Architect"
        backup = self.doc.save()
        self.assertTrue((backup / "agents.json").is_file())
        self.assertEqual(json.loads(self.path.read_text())["agents"]["data"]["display_name"], "Data, Operations Architect")
        self.assertFalse(self.doc.dirty)

    def test_validation_rejects_role_policy_without_provider_mapping(self):
        del self.doc.data["providers"]["agy"]["tiers"]["frontier"]
        with self.assertRaisesRegex(ValueError, "tier frontier has no mapping for agy"):
            self.doc.validate()

    def test_role_policy_accepts_declared_runner_capability(self):
        self.doc.update_role_policy("Runner", "budget", "low", "runner")
        runners = [agent for agent in self.doc.data["agents"].values() if agent["role"] == "Runner"]
        self.assertTrue(runners)
        self.assertTrue(all(agent["capability_class"] == "runner" for agent in runners))
        self.doc.validate()

    def test_save_generate_runs_supervisor_generate_profiles(self):
        from roster_gui import cli, parse_generate_profiles_output
        generated, keys = parse_generate_profiles_output(
            "KEY data <data@example> /tmp/key\n"
            "GENERATED /tmp/data.config.toml\n"
            "profiles are current\n")
        self.assertEqual(generated, ["/tmp/data.config.toml"])
        self.assertEqual(keys, ["data <data@example> /tmp/key"])
        draft = self.root / "draft.json"
        draft.write_text(self.path.read_text())
        completed = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="KEYS none\nGENERATED /tmp/a.md\n",
            stderr="",
        )
        with mock.patch("roster_gui.subprocess.run", return_value=completed) as run, \
                mock.patch("sys.stdout", io.StringIO()):
            code = cli(["--roster", str(self.path), "--draft", str(draft),
                        "--save", "--generate"])
        self.assertEqual(code, 0)
        command = run.call_args.args[0]
        self.assertEqual(command[1:], [
            str(HERE / "supervisor.py"), "generate-profiles",
            "--inbox", str(self.root),
        ])

    def test_validation_rejects_unknown_capability_set(self):
        self.doc.data["role_policy"]["Runner"]["capability_class"] = "warp-core"
        with self.assertRaisesRegex(ValueError, "unknown capability set warp-core"):
            self.doc.validate()

    def test_validation_rejects_empty_role_behavioral_patterns(self):
        self.doc.data["role_policy"]["Dispatcher"]["behavioral_patterns"] = "  "
        with self.assertRaisesRegex(ValueError, "behavioral_patterns must not be empty"):
            self.doc.validate()

    def test_validation_rejects_missing_default_derivation_sources(self):
        self.doc.data["default_derivation"]["operational_evidence"] = []
        with self.assertRaisesRegex(ValueError, "default_derivation requires nonempty operational_evidence"):
            self.doc.validate()

    def test_validation_rejects_invalid_atomic_capability_name(self):
        self.doc.data["capabilities"]["__new-capability-1"] = {"description": "unfinished draft"}
        with self.assertRaisesRegex(ValueError, "invalid capability name"):
            self.doc.validate()

    def test_validation_rejects_unknown_atomic_capability(self):
        self.doc.data["capability_sets"]["unprivileged"]["capabilities"].append("warp-core")
        with self.assertRaisesRegex(ValueError, "unknown capability warp-core"):
            self.doc.validate()

    def test_validation_requires_every_predefined_capability_set(self):
        del self.doc.data["capability_sets"]["runner"]
        with self.assertRaisesRegex(ValueError, "missing predefined capability set runner"):
            self.doc.validate()


class GitIdentityTests(unittest.TestCase):
    """Agents commit as themselves, never as the operator running them."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.config = root / "config"
        self.workspace = root / "workspace"
        self.state = root / "state"
        self.keys_root = root / "keys"
        self.config.mkdir()
        self.workspace.mkdir()
        shutil.copy2(HERE / "agents.json", self.config / "agents.json")
        self.args = argparse.Namespace(
            inbox=self.config, store=root / "store", archive_dir=root / "archive",
            state_dir=self.state, workspace=self.workspace, agent=None,
            wake_broadcasts=False, allow_integrators=False, max_parallel=1,
            cooldown=1, max_backoff=10, interval=1, replace_running=False,
            codex_profiles=root / "codex", claude_profiles=root / "claude",
            agy_profiles=root / "agy", cursor_profiles=root / "cursor", grok_profiles=root / "grok", check=False,
            keys_root=self.keys_root,
        )
        from profile_generator import generate as generate_native_profiles
        generate_native_profiles(
            self.config / "agents.json",
            {
                "codex": self.args.codex_profiles,
                "claude": self.args.claude_profiles,
                "agy": self.args.agy_profiles,
                "cursor": self.args.cursor_profiles,
                "grok": self.args.grok_profiles,
            },
        )

    def supervisor(self):
        return SUPERVISOR.Supervisor(self.args)

    def read_config(self, env):
        return Path(env["GIT_CONFIG_GLOBAL"]).read_text()

    def test_identity_is_the_agent_and_shadows_the_operator_config(self):
        env = self.supervisor().git_identity_environment("data")
        # Both operator scopes are displaced: global is redirected, system off.
        self.assertEqual(env["GIT_CONFIG_NOSYSTEM"], "1")
        self.assertTrue(Path(env["GIT_CONFIG_GLOBAL"]).is_file())
        self.assertEqual(env["GIT_CONFIG_COUNT"], "8")
        self.assertEqual(env["GIT_CONFIG_KEY_0"], "user.name")
        self.assertEqual(env["GIT_CONFIG_VALUE_0"], "data")
        self.assertEqual(env["GIT_CONFIG_KEY_2"], "user.signingkey")

        config = self.read_config(env)
        self.assertIn("name = data", config)
        self.assertIn("email = data@enterprise.starfleet.network", config)
        self.assertIn("gpgsign = true", config)
        self.assertIn("format = ssh", config)
        self.assertIn(
            f"hooksPath = {self.workspace.resolve() / '.githooks'}",
            config,
        )

        key = (
            self.keys_root / "starfleet" / "enterprise" / "data"
            / "latest" / "id_ed25519"
        )
        self.assertIn(f"signingkey = {key}", config)
        self.assertTrue(key.is_file())
        self.assertNotIn(str(Path.home() / ".gitconfig"), config)

    def test_allowed_signers_points_at_the_versioned_copy_in_the_repository(self):
        env = self.supervisor().git_identity_environment("data")
        self.assertIn(
            f"allowedSignersFile = {self.workspace.resolve() / 'allowed_signers'}",
            self.read_config(env),
        )

    def test_hooks_are_installed_in_the_workspace_not_agent_inbox(self):
        env = self.supervisor().git_identity_environment("data")
        hooks = self.workspace.resolve() / ".githooks"
        self.assertIn(f"hooksPath = {hooks}", self.read_config(env))
        self.assertTrue((hooks / "commit-msg").is_file())
        self.assertTrue((hooks / "post-commit").is_file())
        self.assertTrue((hooks / "commit_audit.py").is_file())
        wrapper = (hooks / "commit-msg").read_text()
        self.assertIn("Path(__file__).resolve().parent", wrapper)
        self.assertNotIn("parent.parent", wrapper)
        self.assertNotIn("agent-inbox", wrapper)

    def test_new_key_is_published_to_the_workspace_allowed_signers(self):
        self.supervisor().git_identity_environment("data")
        published = (self.workspace / "allowed_signers").read_text().splitlines()
        self.assertEqual(len(published), 1)
        self.assertTrue(
            published[0].startswith("data@enterprise.starfleet.network ssh-ed25519 "))
        self.assertFalse((self.config / "allowed_signers").exists())

    def test_repeated_calls_reuse_the_same_key_and_config(self):
        first = self.supervisor().git_identity_environment("DATA")
        content = self.read_config(first)
        second = self.supervisor().git_identity_environment("data")
        self.assertEqual(first, second)
        self.assertEqual(self.read_config(second), content)
        self.assertEqual(
            len((self.workspace / "allowed_signers").read_text().splitlines()), 1)

    def test_unprovisionable_key_degrades_instead_of_failing_the_turn(self):
        stderr = io.StringIO()
        with mock.patch.object(SUPERVISOR.agent_keys, "ensure_key",
                               side_effect=RuntimeError("ssh-keygen failed")), \
                mock.patch.object(SUPERVISOR.sys, "stderr", stderr):
            self.assertEqual(self.supervisor().git_identity_environment("data"), {})
        self.assertIn("without its own git identity", stderr.getvalue())

    def test_launch_hands_the_identity_to_the_agent_process(self):
        supervisor = self.supervisor()
        # Provision the key before Popen is mocked; ssh-keygen needs a real one.
        supervisor.git_identity_environment("data")

        class DummyProcess:
            pid = 4711

            def poll(self):
                return None

        captured = {}

        def popen(*args, **kwargs):
            captured.update(kwargs)
            return DummyProcess()

        with mock.patch.object(supervisor, "runtime", return_value="codex"), \
                mock.patch("subprocess.Popen", side_effect=popen):
            self.assertTrue(supervisor.launch(
                "data", supervisor.agents["data"], "codex",
                [{"id": "m1", "to": "data", "sender": "picard"}]))
        env = captured["env"]
        self.assertEqual(env["GIT_CONFIG_NOSYSTEM"], "1")
        self.assertIn("data.gitconfig", env["GIT_CONFIG_GLOBAL"])
        self.assertEqual(env["GIT_CONFIG_KEY_2"], "user.signingkey")
        self.assertIn("/starfleet/enterprise/data/latest/id_ed25519", env["GIT_CONFIG_VALUE_2"])
        # The rest of the operator environment stays intact for the runtime.
        self.assertEqual(env.get("PATH"), os.environ.get("PATH"))
        supervisor.shutdown()

    def test_chat_hands_the_identity_to_the_interactive_session(self):
        args = argparse.Namespace(**vars(self.args), command="talk", target="data")
        captured = {}
        with mock.patch.object(SUPERVISOR, "_require_foreground_terminal"), \
                mock.patch.object(SUPERVISOR.Supervisor, "interactive_command",
                                  return_value=("data", ["claude"])), \
                mock.patch.object(SUPERVISOR, "interactive_recording_command",
                                  return_value=["/usr/bin/true"]), \
                mock.patch.object(SUPERVISOR, "_capture_terminal_state",
                                  return_value=None), \
                mock.patch.object(SUPERVISOR, "_restore_interactive_terminal"), \
                mock.patch.object(SUPERVISOR.os, "ttyname", side_effect=OSError), \
                mock.patch.object(
                    SUPERVISOR.subprocess, "call",
                    side_effect=lambda *a, **kw: captured.update(kw) or 0):
            self.assertEqual(SUPERVISOR.chat(args), 0)
        self.assertIn("data.gitconfig", captured["env"]["GIT_CONFIG_GLOBAL"])

    def test_commit_made_with_the_generated_config_verifies(self):
        for tool in ("git", "ssh-keygen"):
            if shutil.which(tool) is None:
                self.skipTest(f"{tool} is unavailable")
        env = {
            **os.environ,
            **self.supervisor().git_identity_environment("data"),
            "GIT_CONFIG_SYSTEM": "/dev/null",
        }

        def git(*arguments):
            return subprocess.run(
                ["git", *arguments], cwd=self.workspace, env=env,
                capture_output=True, text=True, check=True)

        git("init", "-q", "-b", "main")
        git("config", "user.signingkey", "/nonexistent/agent-commit-key")
        git("config", "gpg.format", "ssh")
        git("config", "commit.gpgsign", "true")
        git("add", "allowed_signers")
        git("commit", "-qm", "signed by the agent")

        show = git("log", "-1", "--format=%an <%ae>%n%G?%n%B")
        self.assertEqual(
            show.stdout.split("\n")[0], "data <data@enterprise.starfleet.network>")
        self.assertEqual(show.stdout.split("\n")[1], "G")
        self.assertNotIn("[identity-warning]", show.stdout)
        verify = subprocess.run(
            ["git", "verify-commit", "HEAD"], cwd=self.workspace, env=env,
            capture_output=True, text=True, check=True)
        self.assertIn("data@enterprise.starfleet.network", verify.stderr)


class CliSetupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.inbox = self.root / "inbox"
        self.inbox.mkdir()
        self.script = SUPERVISOR.mcp_server_script(self.inbox)
        self.script.write_text("# test mcp server\n")
        self.home = self.root / "home"
        self.home.mkdir()
        self.calls = []

    def tearDown(self):
        self.tmp.cleanup()

    def which(self, present):
        mapping = {
            name: str(self.root / name) for name in present
        }

        def lookup(executable):
            return mapping.get(executable)

        return lookup

    def run_cli(self, listings, add_code=0, enable_code=0):
        def run(argv, timeout=45):
            self.calls.append(list(argv))
            if len(argv) >= 3 and argv[1:3] == ["mcp", "list"]:
                stdout = listings.get(argv[0], "")
                return subprocess.CompletedProcess(argv, 0, stdout, "")
            if len(argv) >= 3 and argv[1:3] == ["mcp", "add"]:
                return subprocess.CompletedProcess(argv, add_code, "", "" if add_code == 0 else "exists")
            if len(argv) >= 3 and argv[1:3] == ["mcp", "enable"]:
                return subprocess.CompletedProcess(argv, enable_code, "", "")
            if len(argv) >= 3 and argv[1:3] == ["mcp", "remove"]:
                return subprocess.CompletedProcess(argv, 0, "", "")
            return subprocess.CompletedProcess(argv, 1, "", "unexpected")

        return run

    def test_parser_accepts_setup_cli_check(self):
        args = SUPERVISOR.build_parser().parse_args(["setup-cli", "--check"])
        self.assertEqual(args.command, "setup-cli")
        self.assertTrue(args.check)

    def test_skips_clis_that_are_not_on_path(self):
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, check=True, home=self.home,
            which=self.which([]), run=self.run_cli({}),
        ))
        for runtime, executable in SUPERVISOR.MCP_CLI_BINARIES.items():
            self.assertEqual(results[runtime], f"skipped (not on PATH: {executable})")
        self.assertEqual(self.calls, [])

    def test_reports_current_when_cli_list_already_points_at_this_script(self):
        claude = self.home / ".claude" / "settings.json"
        claude.parent.mkdir(parents=True)
        claude.write_text(json.dumps({"permissions": {
            "allow": SUPERVISOR.claude_mcp_allow_entries()}}))
        agy = self.home / ".gemini" / "antigravity-cli" / "settings.json"
        agy.parent.mkdir(parents=True)
        agy.write_text(json.dumps({"permissions": {
            "allow": SUPERVISOR.agy_mcp_allow_entries()}}))
        listing = f"agent-inbox  stdio  enabled  /usr/bin/python3 {self.script}"
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, check=True, home=self.home,
            which=self.which(["claude", "codex", "agy", "grok"]),
            run=self.run_cli({
                "claude": listing,
                "codex": listing,
                "agy": listing,
                "grok": listing,
            }),
        ))
        self.assertEqual(results["claude"], "current")
        self.assertEqual(results["codex"], "current")
        self.assertEqual(results["agy"], "current")
        self.assertEqual(results["grok"], "current")
        self.assertTrue(results["cursor"].startswith("skipped"))
        self.assertTrue(all(argv[1:3] == ["mcp", "list"] for argv in self.calls))

    def test_adds_missing_cli_registration(self):
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, home=self.home,
            which=self.which(["claude", "codex", "agy", "grok"]),
            run=self.run_cli({}),
        ))
        self.assertEqual(results["claude"], "updated")
        self.assertEqual(results["codex"], "updated")
        self.assertEqual(results["agy"], "updated")
        self.assertEqual(results["grok"], "updated")
        added = [argv for argv in self.calls if argv[1:3] == ["mcp", "add"]]
        self.assertEqual(added, [
            ["claude", "mcp", "add", "--scope", "user", "agent-inbox", "--",
             "/usr/bin/python3", str(self.script)],
            ["codex", "mcp", "add", "agent-inbox", "--",
             "/usr/bin/python3", str(self.script)],
            ["agy", "mcp", "add", "agent-inbox",
             "/usr/bin/python3", str(self.script)],
            ["grok", "mcp", "add", "--scope", "user", "agent-inbox", "--",
             "/usr/bin/python3", str(self.script)],
        ])
        claude = json.loads((self.home / ".claude/settings.json").read_text())
        agy = json.loads((
            self.home / ".gemini/antigravity-cli/settings.json").read_text())
        self.assertEqual(
            claude["permissions"]["allow"],
            SUPERVISOR.claude_mcp_allow_entries())
        self.assertEqual(
            agy["permissions"]["allow"], SUPERVISOR.agy_mcp_allow_entries())
        self.assertIn(
            "mcp(agent-inbox/offer_reply)", agy["permissions"]["allow"])
        self.assertIn(
            "mcp(agent-inbox/offer_inbox)", agy["permissions"]["allow"])

    def test_check_detects_missing_provider_permission_rules(self):
        listing = f"agent-inbox  stdio  enabled  /usr/bin/python3 {self.script}"
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, check=True, home=self.home,
            which=self.which(["claude", "agy"]),
            run=self.run_cli({"claude": listing, "agy": listing}),
            runtimes=("claude", "agy"),
        ))
        self.assertEqual(results, {
            "claude": "needs-update", "agy": "needs-update"})
        self.assertFalse((self.home / ".claude/settings.json").exists())
        self.assertFalse((
            self.home / ".gemini/antigravity-cli/settings.json").exists())

    def test_check_does_not_write_or_add(self):
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, check=True, home=self.home,
            which=self.which(["claude"]),
            run=self.run_cli({}),
        ))
        self.assertEqual(results["claude"], "needs-update")
        self.assertTrue(all(argv[1:3] == ["mcp", "list"] for argv in self.calls))

    def test_cursor_writes_mcp_json_enable_and_allowlist(self):
        cursor_home = self.home / ".cursor"
        cursor_home.mkdir()
        (cursor_home / "mcp.json").write_text('{"mcpServers": {}}\n')
        (cursor_home / "cli-config.json").write_text(json.dumps({
            "permissions": {"allow": ["Shell(ls)"], "deny": []},
            "version": 1,
        }) + "\n")
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, home=self.home,
            which=self.which(["cursor-agent"]),
            run=self.run_cli({}),
        ))
        self.assertEqual(results["cursor"], "updated")
        mcp = json.loads((cursor_home / "mcp.json").read_text())
        self.assertEqual(mcp["mcpServers"]["agent-inbox"], {
            "command": "/usr/bin/python3",
            "args": [str(self.script)],
        })
        allow = json.loads((cursor_home / "cli-config.json").read_text())["permissions"]["allow"]
        self.assertEqual(allow[0], "Shell(ls)")
        for entry in SUPERVISOR.cursor_mcp_allow_entries():
            self.assertIn(entry, allow)
        self.assertIn(
            ["cursor-agent", "mcp", "enable", "agent-inbox"], self.calls)

    def test_cursor_check_is_current_when_config_and_list_match(self):
        cursor_home = self.home / ".cursor"
        cursor_home.mkdir()
        (cursor_home / "mcp.json").write_text(json.dumps({
            "mcpServers": {
                "agent-inbox": {
                    "command": "/usr/bin/python3",
                    "args": [str(self.script)],
                }
            }
        }) + "\n")
        (cursor_home / "cli-config.json").write_text(json.dumps({
            "permissions": {
                "allow": SUPERVISOR.cursor_mcp_allow_entries(),
                "deny": [],
            }
        }) + "\n")
        listing = "agent-inbox: ready"
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, check=True, home=self.home,
            which=self.which(["cursor-agent"]),
            run=self.run_cli({"cursor-agent": listing}),
        ))
        self.assertEqual(results["cursor"], "current")
        self.assertEqual(self.calls, [["cursor-agent", "mcp", "list"]])

    def test_setup_cli_command_prints_and_exits_on_check_drift(self):
        args = argparse.Namespace(inbox=self.inbox, check=True)
        buffer = io.StringIO()
        with mock.patch.object(SUPERVISOR, "setup_cli_mcp", return_value=[
            ("claude", "needs-update"),
            ("codex", "skipped (not on PATH: codex)"),
        ]), mock.patch("sys.stdout", buffer):
            self.assertEqual(SUPERVISOR.setup_cli(args), 1)
        self.assertIn("claude: needs-update", buffer.getvalue())

    def test_setup_cli_mcp_can_limit_to_in_use_runtimes(self):
        claude = self.home / ".claude" / "settings.json"
        claude.parent.mkdir(parents=True)
        claude.write_text(json.dumps({"permissions": {
            "allow": SUPERVISOR.claude_mcp_allow_entries()}}))
        listing = f"agent-inbox  /usr/bin/python3 {self.script}"
        results = dict(SUPERVISOR.setup_cli_mcp(
            self.inbox, check=True, home=self.home,
            which=self.which(["claude", "codex", "agy", "grok", "cursor-agent"]),
            run=self.run_cli({"claude": listing, "codex": ""}),
            runtimes=("claude",),
        ))
        self.assertEqual(list(results), ["claude"])
        self.assertEqual(results["claude"], "current")
        self.assertEqual(self.calls, [["claude", "mcp", "list"]])

    def test_run_preflight_provisions_only_launchable_providers(self):
        args = argparse.Namespace(
            command="run", target=None, inbox=self.inbox, agent=None)
        supervisor = mock.Mock()
        supervisor.selected.return_value = [
            ("data", {"provider": "codex"}, "codex"),
            ("michael", {"provider": "cursor"}, "cursor"),
            ("tom", {"provider": "claude"}, "claude"),
        ]
        with mock.patch.object(SUPERVISOR, "setup_cli_mcp", return_value=[
            ("claude", "current"),
            ("codex", "current"),
            ("cursor", "current"),
        ]) as setup:
            self.assertEqual(
                SUPERVISOR.preflight_cli_setup(args, supervisor=supervisor), 0)
        setup.assert_called_once()
        self.assertEqual(setup.call_args.kwargs["runtimes"], ("claude", "codex", "cursor"))
        self.assertFalse(setup.call_args.kwargs["check"])

    def test_chat_preflight_checks_only_the_target_cli(self):
        args = argparse.Namespace(
            command="chat", target="michael", inbox=self.inbox)
        supervisor = mock.Mock()
        supervisor.resolve_agent.return_value = ("michael", {"provider": "cursor"})
        with mock.patch.object(SUPERVISOR, "setup_cli_mcp", return_value=[
            ("cursor", "needs-update"),
        ]) as setup:
            err = io.StringIO()
            with mock.patch("sys.stderr", err):
                self.assertEqual(
                    SUPERVISOR.preflight_cli_setup(args, supervisor=supervisor), 1)
        setup.assert_called_once()
        self.assertEqual(setup.call_args.kwargs["runtimes"], ("cursor",))
        self.assertIn("cursor: needs-update", err.getvalue())
        self.assertIn("setup-cli", err.getvalue())

    def test_preflight_treats_missing_binary_as_failure_for_in_use_cli(self):
        args = argparse.Namespace(command="once", target=None, inbox=self.inbox)
        supervisor = mock.Mock()
        supervisor.selected.return_value = [
            ("michael", {"provider": "cursor"}, "cursor"),
        ]
        with mock.patch.object(SUPERVISOR, "setup_cli_mcp", return_value=[
            ("cursor", "skipped (not on PATH: cursor-agent)"),
        ]):
            err = io.StringIO()
            with mock.patch("sys.stderr", err):
                self.assertEqual(
                    SUPERVISOR.preflight_cli_setup(args, supervisor=supervisor), 1)
        self.assertIn("cursor-agent", err.getvalue())

    def test_preflight_is_a_no_op_when_no_cli_is_in_use(self):
        args = argparse.Namespace(command="run", inbox=self.inbox)
        supervisor = mock.Mock()
        supervisor.selected.return_value = []
        with mock.patch.object(SUPERVISOR, "setup_cli_mcp") as setup:
            self.assertEqual(
                SUPERVISOR.preflight_cli_setup(args, supervisor=supervisor), 0)
        setup.assert_not_called()

    def test_cursor_usage_preflight_skips_when_no_cursor_agent(self):
        args = argparse.Namespace(command="run", target=None, workspace=self.root)
        supervisor = mock.Mock()
        supervisor.selected.return_value = [
            ("data", {"provider": "codex"}, "codex"),
        ]
        query = mock.Mock()
        self.assertEqual(
            SUPERVISOR.preflight_cursor_usage(args, supervisor=supervisor, query=query),
            0)
        query.assert_not_called()

    def test_cursor_usage_preflight_aborts_when_snapshot_fails(self):
        args = argparse.Namespace(command="run", target=None, workspace=self.root)
        supervisor = mock.Mock()
        supervisor.selected.return_value = [
            ("michael", {"provider": "cursor"}, "cursor"),
        ]
        err = io.StringIO()
        with mock.patch("sys.stderr", err):
            self.assertEqual(
                SUPERVISOR.preflight_cursor_usage(
                    args, supervisor=supervisor,
                    query=lambda _workspace: {
                        "provider": "cursor", "windows": [],
                        "error": "no local Cursor session token",
                    },
                ),
                1)
        self.assertIn("Cursor usage preflight failed", err.getvalue())
        self.assertIn("no local Cursor session token", err.getvalue())
        self.assertIn("CURSOR_SESSION_TOKEN", err.getvalue())

    def test_cursor_usage_preflight_aborts_when_windows_are_empty(self):
        args = argparse.Namespace(command="run", target=None, workspace=self.root)
        supervisor = mock.Mock()
        supervisor.selected.return_value = [
            ("michael", {"provider": "cursor"}, "cursor"),
        ]
        err = io.StringIO()
        with mock.patch("sys.stderr", err):
            self.assertEqual(
                SUPERVISOR.preflight_cursor_usage(
                    args, supervisor=supervisor,
                    query=lambda _workspace: {"provider": "cursor", "windows": []},
                ),
                1)
        self.assertIn("Cursor usage preflight failed", err.getvalue())

    def test_cursor_usage_preflight_passes_when_plan_window_exists(self):
        args = argparse.Namespace(command="chat", target="michael", workspace=self.root)
        supervisor = mock.Mock()
        supervisor.resolve_agent.return_value = ("michael", {"provider": "cursor"})
        self.assertEqual(
            SUPERVISOR.preflight_cursor_usage(
                args, supervisor=supervisor,
                query=lambda _workspace: {
                    "provider": "cursor",
                    "windows": [{"label": "plan", "remaining_percent": 89}],
                },
            ),
            0)

    def test_main_runs_cli_preflight_before_launch_commands(self):
        source = (HERE / "supervisor.py").read_text()
        self.assertEqual(
            SUPERVISOR.CLI_LAUNCH_COMMANDS,
            ("run", "once", "restart", "chat", "talk", "chat-with", "talk-to"),
        )
        launch_gate = 'if args.command in CLI_LAUNCH_COMMANDS:'
        chat_return = 'if args.command in ("chat", "talk", "chat-with", "talk-to"):\n        return chat(args)'
        restart = 'if args.command == "restart":'
        self.assertIn(launch_gate, source)
        self.assertIn("code = preflight_cli_setup(args)", source)
        self.assertIn("code = preflight_cursor_usage(args)", source)
        self.assertLess(
            source.index("code = preflight_cli_setup(args)"),
            source.index("code = preflight_cursor_usage(args)"),
        )
        self.assertLess(source.index(launch_gate), source.index(chat_return))
        self.assertLess(source.index(launch_gate), source.index(restart))


class ProfileRootAgreementTests(unittest.TestCase):
    def matching_args(self, **overrides):
        roster = json.loads((HERE / "agents.json").read_text())
        attr = {
            "codex": "codex_profiles",
            "claude": "claude_profiles",
            "agy": "agy_profiles",
            "cursor": "cursor_profiles",
            "grok": "grok_profiles",
        }
        kwargs = dict(
            inbox=HERE,
            check=False,
            keys_root=HERE / "unused-keys",
            workspace=HERE,
        )
        for name, config in roster["providers"].items():
            kwargs[attr[name]] = Path(config["profile_root"]).expanduser()
        kwargs.update(overrides)
        return argparse.Namespace(**kwargs)

    def test_implicit_mismatch_aborts_without_writing(self):
        args = self.matching_args(codex_profiles=Path("/tmp/agent-inbox-other-codex"))
        generate = mock.Mock(return_value=["unused"])
        err = io.StringIO()
        with mock.patch.object(SUPERVISOR, "generate_native_profiles", generate), \
                mock.patch("sys.stderr", err):
            code = SUPERVISOR.generate_profiles(args, argv=["generate-profiles"])
        self.assertEqual(code, 1)
        generate.assert_not_called()
        self.assertIn("do not match", err.getvalue())
        self.assertIn("--codex-profiles", err.getvalue())

    def test_explicit_override_warns_and_reports_files_and_keys(self):
        other = Path("/tmp/agent-inbox-other-codex")
        args = self.matching_args(codex_profiles=other)
        fake_path = mock.Mock()
        fake_path.read_text.return_value = "native profile"
        out = io.StringIO()
        err = io.StringIO()
        with mock.patch.object(
                    SUPERVISOR, "generate_native_profiles",
                    return_value=["/tmp/a.config.toml"]), \
                mock.patch.object(
                    SUPERVISOR.agent_keys, "sync",
                    return_value={"created": [("data", "data@x", "/tmp/key")]}), \
                mock.patch.object(SUPERVISOR.commit_audit, "install_hooks"), \
                mock.patch("profile_generator.profile_path", return_value=fake_path), \
                mock.patch("sys.stdout", out), mock.patch("sys.stderr", err):
            code = SUPERVISOR.generate_profiles(
                args,
                argv=["generate-profiles", "--codex-profiles", str(other)],
            )
        self.assertEqual(code, 0)
        self.assertIn("warning:", err.getvalue())
        self.assertIn("--codex-profiles", err.getvalue())
        self.assertIn("GENERATED /tmp/a.config.toml", out.getvalue())
        self.assertIn("KEY data <data@x> /tmp/key", out.getvalue())

    def test_matching_defaults_report_current_and_keys_none(self):
        args = self.matching_args()
        fake_path = mock.Mock()
        fake_path.read_text.return_value = "native profile"
        out = io.StringIO()
        with mock.patch.object(SUPERVISOR, "generate_native_profiles", return_value=[]), \
                mock.patch.object(
                    SUPERVISOR.agent_keys, "sync", return_value={"created": []}), \
                mock.patch.object(SUPERVISOR.commit_audit, "install_hooks"), \
                mock.patch("profile_generator.profile_path", return_value=fake_path), \
                mock.patch("sys.stdout", out):
            code = SUPERVISOR.generate_profiles(args, argv=["generate-profiles"])
        self.assertEqual(code, 0)
        self.assertIn("KEYS none", out.getvalue())
        self.assertIn("profiles are current", out.getvalue())


class DashboardMailboxTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.config = root / "config"
        self.store = root / "store"
        self.archive = root / "archive"
        self.state = root / "state"
        self.workspace = root / "workspace"
        self.config.mkdir()
        self.workspace.mkdir()
        shutil.copy2(HERE / "agents.json", self.config / "agents.json")
        self.args = argparse.Namespace(
            inbox=self.config, store=self.store, archive_dir=self.archive,
            state_dir=self.state, workspace=self.workspace, agent=None,
            wake_broadcasts=False, allow_integrators=False, max_parallel=1,
            cooldown=1, max_backoff=10, interval=1, replace_running=False,
            codex_profiles=root / "codex", claude_profiles=root / "claude",
            agy_profiles=root / "agy", cursor_profiles=root / "cursor",
            grok_profiles=root / "grok", check=False,
        )

    def tearDown(self):
        self.tmp.cleanup()

    def supervisor(self):
        return SUPERVISOR.Supervisor(self.args)

    def write_mail(self, records):
        path = self.store / "data/messages.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("".join(json.dumps(record) + "\n" for record in records))

    def test_supervisor_mailbox_lists_direct_mail_and_broadcasts(self):
        self.write_mail([
            {"id": "1700000000000-0000aaaa", "ts": "2026-08-27T10:00:00Z",
             "sender": "kathryn", "to": "supervisor", "subject": "Report",
             "body": "b1", "thread": "t1"},
            {"id": "1700000000001-0000bbbb", "ts": "2026-08-27T10:01:00Z",
             "sender": "worf", "to": "all", "subject": "Broadcast",
             "body": "b2", "thread": ""},
            {"id": "1700000000002-0000cccc", "ts": "2026-08-27T10:02:00Z",
             "sender": "supervisor", "to": "all", "subject": "Own send",
             "body": "b3", "thread": ""},
            {"id": "1700000000003-0000dddd", "ts": "2026-08-27T10:03:00Z",
             "sender": "kathryn", "to": "data", "subject": "Not mine",
             "body": "b4", "thread": ""},
        ])
        read = self.store / "data/read/supervisor.json"
        read.parent.mkdir(parents=True, exist_ok=True)
        read.write_text(json.dumps(
            {"agent": "supervisor", "acked": ["1700000000000-0000aaaa"]}))
        snapshot = self.supervisor().supervisor_mailbox_snapshot()
        # Newest first; own sends and other agents' mail stay out.
        self.assertEqual([m["id"] for m in snapshot["messages"]],
                         ["1700000000001-0000bbbb", "1700000000000-0000aaaa"])
        self.assertEqual(snapshot["unread"], 1)
        self.assertFalse(snapshot["messages"][0]["acked"])
        self.assertTrue(snapshot["messages"][1]["acked"])

    def test_supervisor_mailbox_keeps_every_unread_beyond_the_limit(self):
        records = [
            {"id": f"170000000{index:04d}-0000aaaa",
             "ts": "2026-08-27T10:00:00Z", "sender": "kathryn",
             "to": "supervisor", "subject": f"m{index}", "body": "b",
             "thread": ""}
            for index in range(6)
        ]
        self.write_mail(records)
        snapshot = self.supervisor().supervisor_mailbox_snapshot(limit=3)
        self.assertEqual(snapshot["unread"], 6)
        self.assertEqual(len(snapshot["messages"]), 6)

    def test_dashboard_ack_survives_volatile_store_reset(self):
        message_id = "1700000000000-0000aaaa"
        self.write_mail([{
            "id": message_id, "ts": "2026-08-27T10:00:00Z",
            "sender": "kathryn", "to": "supervisor", "subject": "Report",
            "body": "b1", "thread": "t1",
        }])
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "_run_inbox_tool",
                               return_value="Acknowledged 1 message"):
            self.assertTrue(supervisor.ack_supervisor_mail([message_id]))
        durable = json.loads(
            (self.state / SUPERVISOR.DASHBOARD_READ_STATE_FILE).read_text())
        self.assertEqual(durable["acked"], [message_id])

        # A machine restart wipes only the volatile delivery state.  The
        # restored message journal must not reopen dashboard mail already acked.
        shutil.rmtree(self.store / "data/read", ignore_errors=True)
        snapshot = self.supervisor().supervisor_mailbox_snapshot()
        self.assertEqual(snapshot["unread"], 0)
        self.assertTrue(snapshot["messages"][0]["acked"])

    def test_dashboard_mail_broadcast_team_fanout_and_thread(self):
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.apply_dashboard_mail({
                "target": "all", "subject": "Hello", "body": "B",
                "thread": "t-9"})
        send.assert_called_once_with(
            "all", "Hello",
            "From the current user via the supervisor dashboard:\n\nB", "t-9")
        team_name, team = next(iter(supervisor.roster.get("teams", {}).items()))
        retired = supervisor.retired_identities()
        members = [name for name in team.get("members") or []
                   if SUPERVISOR.identity_key(name) not in retired]
        with mock.patch.object(supervisor, "send_supervisor_message",
                               return_value=True) as send:
            supervisor.apply_dashboard_mail({
                "target": "team:" + team_name.upper(), "subject": "S",
                "body": "B"})
        self.assertEqual([call.args[0] for call in send.call_args_list],
                         members)
        self.assertEqual(send.call_args.args[3], "dashboard-mail")

    def test_dashboard_mail_ack_runs_the_canonical_ack_tool(self):
        supervisor = self.supervisor()
        with mock.patch.object(supervisor, "_run_inbox_tool",
                               return_value="Acknowledged") as run:
            supervisor.apply_dashboard_command(
                {"action": "mail_ack",
                 "ids": ["1700000000000-0000aaaa", "  "]})
        run.assert_called_once_with(
            "tool_ack",
            {"agent": "supervisor", "ids": ["1700000000000-0000aaaa"]},
            "supervisor ack")

    def test_workspace_open_features_parses_open_tasks_and_strips_prereqs(self):
        (self.workspace / "TODO.md").write_text(
            "# TODO\n"
            "## Feature: 0044 — Process Improvement\n"
            "- [x] **0044-01** Done thing\n"
            "- [ ] **0044-07** PREREQ: 0044-07:0044-05 Review the role catalog\n"
            "- [p] **0044-12** Anchor provenance\n"
            "## Feature: 0099 — All done\n"
            "- [x] **0099-01** Finished\n")
        features = SUPERVISOR.workspace_open_features(self.workspace)
        self.assertEqual(len(features), 1)
        self.assertEqual(features[0]["id"], "0044")
        self.assertEqual(features[0]["title"], "Process Improvement")
        self.assertEqual(
            [(task["id"], task["mark"]) for task in features[0]["tasks"]],
            [("0044-07", " "), ("0044-12", "p")])
        self.assertEqual(features[0]["tasks"][0]["title"],
                         "Review the role catalog")

    def test_dashboard_snapshot_carries_mailbox_and_features(self):
        snapshot = self.supervisor().dashboard_snapshot(claims={})
        self.assertIn("unread", snapshot["mailbox"])
        self.assertIsInstance(snapshot["mailbox"]["messages"], list)
        self.assertIsInstance(snapshot["features"], list)
        self.assertIsInstance(snapshot["integration_delegations"], list)


class GeneratedProfileMemoryRoutingTests(unittest.TestCase):
    """DEC-0044-029 C07: whole-population proof over every generated profile.

    Sampling is insufficient because one stale profile can still instruct the
    old unsafe append form. Profiles are rendered in memory; no live profile
    root, key, allowed_signers, hook, or Memory path is touched.
    """

    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location(
            "profile_generator", HERE / "profile_generator.py")
        cls.generator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.generator)
        cls.roster = cls.generator.load_roster(HERE / "agents.json")
        cls.profiles = cls.generator.native_profiles(cls.roster)
        cls.memory_profiles = {
            name: text for name, text in cls.profiles.items()
            if "MEMORY GOVERNANCE" in text
        }

    def test_population_is_not_empty(self):
        self.assertGreater(len(self.profiles), 0)
        self.assertEqual(len(self.memory_profiles), len(self.profiles))

    def test_every_profile_requires_an_explicit_append_worktree(self):
        offenders = [
            name for name, text in self.memory_profiles.items()
            if "--workspace <active-item-worktree>" not in text
            or 'workspace="<active-item-worktree>"' not in text
        ]
        self.assertEqual(offenders, [])

    def test_no_profile_instructs_a_repository_root_or_default_append(self):
        offenders = [
            name for name, text in self.memory_profiles.items()
            if 'workspace="<repository-root>"' in text
        ]
        self.assertEqual(offenders, [])

    def test_no_profile_shows_an_append_fallback_without_workspace(self):
        offenders = []
        for name, text in self.memory_profiles.items():
            for line in text.splitlines():
                # Only concrete invocation forms; prose that merely names the
                # helper (the hold notice) carries no unsafe example.
                if "append --agent" in line and "--workspace" not in line:
                    offenders.append((name, line.strip()[:60]))
        self.assertEqual(offenders, [])

    def test_every_profile_carries_the_active_hold(self):
        offenders = [
            name for name, text in self.memory_profiles.items()
            if "DEC-0044-029" not in text or "HOLD" not in text
        ]
        self.assertEqual(offenders, [])

    def test_every_profile_distinguishes_feature_routing(self):
        offenders = [
            name for name, text in self.memory_profiles.items()
            if "--scope feature --feature <id>" not in text
        ]
        self.assertEqual(offenders, [])

    def test_every_profile_retains_authority_limits(self):
        offenders = [
            name for name, text in self.memory_profiles.items()
            if "grants no wider scope or authority" not in text
        ]
        self.assertEqual(offenders, [])

    def test_generation_is_deterministic(self):
        again = self.generator.native_profiles(
            self.generator.load_roster(HERE / "agents.json"))
        self.assertEqual(again, self.profiles)

    def test_rendering_touches_no_live_profile_root(self):
        """Zero-mutation canary around the whole-population render."""
        roots = {
            "codex": Path.home() / ".codex",
            "claude": Path.home() / ".claude" / "agents",
            "gemini": Path.home() / ".gemini" / "config" / "agents",
            "cursor": Path.home() / ".cursor" / "agents",
            "grok": Path.home() / ".grok" / "agents",
        }
        # Only the generated profile files themselves: sibling runtime state
        # such as live session logs changes independently of this render.
        watched = []
        for name, agent in self.roster["agents"].items():
            try:
                watched.append(self.generator.profile_path(roots, name, agent))
            except KeyError:
                continue

        def snapshot():
            state = {}
            for path in sorted(set(watched)):
                if path.is_file():
                    state[str(path)] = (
                        path.stat().st_mtime_ns,
                        hashlib.sha256(path.read_bytes()).hexdigest(),
                    )
            return state
        before = snapshot()
        self.generator.native_profiles(self.roster)
        self.assertEqual(before, snapshot())


if __name__ == "__main__":
    unittest.main()
