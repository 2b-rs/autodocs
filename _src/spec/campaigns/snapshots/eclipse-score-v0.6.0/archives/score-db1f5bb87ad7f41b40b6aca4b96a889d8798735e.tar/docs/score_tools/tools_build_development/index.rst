..
   # *******************************************************************************
   # Copyright (c) 2026 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _tools_build_development:

Build & Development Tools Overview
==================================

.. needtable:: Testing Frameworks List
   :tags: tool_management, tools_build_development
   :filter: "tool_management" in tags and "tools_build_development" in tags and type == "doc_tool" and is_external == False
   :style: table
   :sort: status
   :columns: id as "UID";title as "TITLE";version as "VERSION";status as "STATUS";tcl as "TCL";safety_affected as "SAFETY AFFECTED";security_affected as "SECURITY AFFECTED"
   :colwidths: 30,30,30,30,30,30,30

.. toctree::
   :hidden:
   :maxdepth: 2

   bazel
