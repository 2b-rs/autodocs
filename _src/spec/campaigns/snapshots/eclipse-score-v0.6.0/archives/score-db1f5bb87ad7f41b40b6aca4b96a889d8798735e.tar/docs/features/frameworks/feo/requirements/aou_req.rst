..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. document:: FEO Assumptions of Use Requirements
   :id: doc__frameworks_feo_aou_reqs
   :status: draft
   :version: 1
   :security: NO
   :safety: ASIL_B
   :realizes: wp__requirements_feat_aou[version==1]

FEO Feature Assumption of Use Requirements
==========================================


.. aou_req:: FEO something
   :id: aou_req__feature_feo__something
   :reqtype: Functional
   :security: NO
   :safety: ASIL_B
   :status: invalid

   Something shall be done.

.. needextend:: is_external == False and "frameworks/feo/requirements" in docname
   :+tags: frameworks_feo
