..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _process_verification:

Verification
############

.. toctree::
   :maxdepth: 1

   verification_getstrt
   verification_concept
   guidance/index
   verification_roles
   verification_workflows
   verification_workproducts

.. needextend:: docname is not None and "process_areas/verification" in docname
   :+tags: verification
