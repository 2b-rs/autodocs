..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _guideline_safety_management:

Safety Management Guideline
===========================

.. gd_guidl:: Safety plan definitions
   :id: gd_guidl__saf_plan_definitions
   :status: valid
   :version: 1
   :complies: std_req__iso26262__management_5426[version==1],
              std_req__iso26262__management_6465[version==1],
              std_req__iso26262__management_6466[version==1],
              std_req__iso26262__management_6467[version==1],
              std_req__iso26262__management_6468[version==1],
              std_req__iso26262__management_6469[version==1],
              std_req__iso26262__management_6422[version==1],
              std_req__iso26262__management_6423[version==1],
              std_req__iso26262__management_6424[version==1],
              std_req__iso26262__management_6451[version==1],
              std_req__iso26262__management_6452[version==1],
              std_req__iso26262__management_6455[version==1],
              std_req__iso26262__management_6457[version==1],
              std_req__iso26262__management_6461[version==1],
              std_req__iso26262__management_6462[version==1],
              std_req__iso26262__management_6463[version==1],
              std_req__iso26262__management_6472[version==1],
              std_req__iso26262__management_6471[version==1],
              std_req__iso26262__management_64111[version==1],
              std_req__iso26262__management_64112[version==1],
              std_req__iso26262__management_64113[version==1],
              std_req__iso26262__management_64114[version==1],
              std_req__iso26262__management_6431[version==1],
              std_req__iso26262__management_6432[version==1],
              std_req__iso26262__management_6433[version==1],
              std_req__iso26262__software_747[version==1],
              std_req__iso26262__support_8441[version==1],
              std_req__iso26262__management_5424[version==1],
              std_req__iso26262__management_5427[version==1],
              std_req__iso26262__management_5432[version==1],
              std_req__iso26262__management_5441[version==1],
              std_req__iso26262__management_5424[version==1],
              std_req__iso26262__management_5427[version==1],
              std_req__iso26262__management_5461[version==1],
              std_req__aspice_40__REU-2-BP1[version==1]

   **Safety culture:**

   Safety culture is planned to grow in the SW platform. This shall be fostered by doing a lessons learned after each feature development completion, using the ISO 26262-2 Table B.1 as a questionnaire.
   This lessons learned is the main input for process improvement managed by :need:`wp__process_impr_report`
   As starting point for safety culture we define a Committer selection process to already have professionals with safety experience in the teams.

   Additionally the SW platform's processes are defined with experience of several companies already performing successful safe SW development. This also improves independence of reviews for the process definitions.

   **Quality Management:**

   ASPICE standard is selected for quality management. Processes will always link to the :ref:`standard_iso26262` standard and to the :ref:`ASPICE PAM4 <standard_aspice_pam4>` standard.

   **Competence management:**

   The :need:`rl__project_lead` on SW platform level is responsible to define a competence management for the whole platform.
   Expectation is that the safety competence of the persons nominated for the roles is already given and only has to be checked.
   The exception from this are the committers, for these no safety competence needs to be enforced.
   So the module safety managers shall consult the :need:`module safety plan <wp__module_safety_plan>` and perform accordingly in their module project.

   **Communication:**

   Development teams are interdisciplinary, so the regular planning and review meetings enable communication (as defined in in the project specific :need:`project management plan <wp__project_mgt>`). Another main communication means are the Pull Request reviews.
   Also the standard Eclipse Foundation communication strategies are used (e.g. mailing lists)

   **Safety anomalies:**

   As the SW platform organization does not have own vehicles in the field, it relies on feedback from OEMs and Distributors on bugs discovered in the field. The need for this feedback is part of each safety manual.
   But also during development of change requests to existing features, bug reporting by the Open Source community or integration of existing SW components into new features may lead to the discovery of new safety anomalies.
   Safety anomalies can also be deviations from the development process with impact on safety.
   If these are known at the time of creation of a release they will be part of the :need:`wp__module_safety_package` or :need:`wp__platform_safety_package` for the SEooC.
   Safety anomalies relevant for already delivered releases will be identified as such and communicated (as defined in Problem Resolution part of :need:`wp__platform_mgmt`) via the :need:`wp__issue_track_system` (which is also Open Source).

   **Tailoring Safety Activities:**

   The software platform is developed purely as software and provided as a Safety Element out of Context (SEooC). That is why only software relevant parts of :ref:`standard_iso26262` are used.
   This requires a generic, platform-wide approach to tailoring so that safety processes remain efficient, relevant, and compliant with the software relevant ISO 26262.
   Before any tailoring is performed, an **impact analysis** must be conducted in accordance with ISO 26262. This analysis is performed on element level, not on the item level as previously stated.
   This analysis determines whether the element is a new development, a modification, or an existing element with a modified environment. The results guide the extent and nature of any tailoring.

   If tailoring is necessary, it must be justified and documented. The rationale should demonstrate that the tailored approach is sufficient to achieve the required level of functional safety. Tailoring may be driven by factors such as:

   - Qualification of software components,
   - Confidence in the use of software tools.

   Note: Proven-in-use arguments are generally not applicable for a reusable SEooC platform intended for integration into various target applications and environments.

   For the software platform as a whole, tailoring is achieved by clearly defining which work products are relevant and providing a reasoned argument for omitting others. This is documented in the platform safety plan and the ISO 26262 reference documentation.

   Additional tailoring may apply at the module or feature level, particularly for SEooC developments where reuse of existing qualified components is the main driver. Such tailoring is documented in the respective module safety plans.

   When safety activities are tailored because an element is developed as SEooC:
   a) The SEooC development must be based on a requirements specification derived from well-defined assumptions about its intended use and context, including all relevant external interfaces.
   b) These assumptions must be validated when the SEooC is integrated into its target application.

   This approach ensures that safety activities are focused, efficient, and appropriate to the context of a reusable software platform, while maintaining compliance with ISO 26262 requirements and intent.

   **Planning safety activities:**

   In the safety plan the nomination of the safety manager and the project manager is documented.
   The planning of safety activities is done as for the project defined in the :need:`wp__project_mgt` by using issues in the :need:`wp__issue_track_system`.
   It should contain for each issue:

   * objective - as part of the issue description
   * dependencies on other activities or information - by links to the respective issues
   * responsible person for the activity - as issue assignee
   * required resources for the activity - by selecting a team label (or "project") pointing to a team of committers dedicated to the issue resolution
   * duration in time, including start and end point - by selecting a milestone
   * UID of the resulting work products - stated in the issue title

   The planning of safety activities is divided into the

   * platform SEooC planning, dealing with all work products needed only once for the platform. This is included in :need:`wp__platform_safety_plan`
   * module SEooC planning, dealing with all work products needed for each module development (initiated by a change request), included in :need:`wp__module_safety_plan`. This module safety planning also includes the planning of OSS component qualification based on :need:`gd_guidl__component_classification`.

   Templates exists to guide this: :need:`gd_temp__platform_safety_plan`, :need:`gd_temp__module_safety_plan`.
   These include linkage to the project planning according to the defined issue structuring schema.

   **Reporting safety activities:**

   Reporting is based on work products and documents status and supported by the safety plan templates and document management.
   A safety plan is completed and the safety package can be released when all planned work products and documents are in status "valid".

   **Planning safety activities for subsequent releases**

   After the first release of the platform or a module with full safety coverage (i.e. all work products are in "valid" state) there will be further development.
   This further development is initiated by creating a feature/component change request including a change impact analysis (see :need:`doc_concept__change_process`).
   As part of the "implementation and monitoring of the change request", the documents affected by the change will be set back to "draft"
   and the implementation (change of work products) planned by issues, as appropriate to the size of the change. At least the change request issue will be linked
   to the updated safety plan. Note that there may be more than one change request for a module per release cycle.

   **Planning supporting processes:**

   Supporting processes (Requirements Management, Configuration Management, Change Management, Documentation Management, Tool Management) are planned within the :need:`wp__platform_mgmt`

   **Planning integration and verification:**

   Integration on the target hardware is not done in the scope of the SW platform project, but SW/SW integration up to the feature level is performed and its test results are part of the :need:`wp__verification_platform_ver_report`.

   The integration on the target hardware done by the user is supported by delivering a set of SW integration tests which were already run successfully on a reference HW platform.
   This is planned by the respective work products:

   * :need:`wp__verification_feat_int_test`
   * :need:`wp__verification_platform_int_test`

   Verification planning is documented in :need:`wp__verification_plan`
   Any unspecified functions, such as code for debugging or instrumentation, must either be deactivated or removed prior to release, unless their presence does not affect safety compliance.

   **Scheduling of formal document reviews and safety audit:**

   Scheduling is done in the same way as for all work products definition by issues. The respective work products are :need:`wp__fdr_reports` and  :need:`wp__audit_report`
   A person responsible for carrying out the functional safety audit shall be appointed as part of the scheduling process. This person has to have the required skillset and knowledge.
   The functional safety auditor may appoint one or more assistants to support the audit.
   These assistants may not be fully independent from the developers of the relevant item, elements, or work products, but must possess at least a basic level of independence.
   The auditor is responsible for appraising the input from any assistants to ensure that the audit remains objective and that an unbiased opinion is provided.
   The planning and follow-up of the audit shall also take into account the type of report to be issued—whether it is an acceptance, conditional acceptance (with required corrective actions and conditions for acceptance), or a rejection.
   Any conditions or corrective actions identified in the report must be addressed and tracked to completion as part of the Safety Management process.

   **Planning of dependent failures and safety analyses:**

   In cases where the components consist of sub-components there will be more than one architecture level. DFA and Safety analysis will then be done on these multiple levels. See the respective work products:

   * feature level: :need:`wp__feature_fmea` and :need:`wp__feature_dfa`
   * component level: :need:`wp__sw_component_fmea` and :need:`wp__sw_component_dfa`

   **Provision of the confidence in the use of software tools:**

   Tool Management planning is part of the :need:`wp__platform_mgmt`. The respective work product to be planned as an issue  of the generic safety plan is the :need:`wp__tool_verification_report`, which contains tool evaluation and if applicable qualification of the SW platform toolchain.
   Components developed in different programming languages will have different toolchains. They will be qualified once for the SW platform.

   **(OSS) Component qualification planning:**

   Based on the component classification as described in :need:`gd_guidl__component_classification`,
   the qualification of the component is planned as part of the :need:`gd_temp__module_safety_plan`.
   The template contains guidance how to do this and to document in the "OSS (sub-)component <name> Workproducts" list.
   As an alternative the module safety manager can also decide to use the :ref:`external_tsf`
   to reach enough trust in an externally provided (OSS) to use it for safety related functionality
   in the scope of the SW platform. This approach is also documented in the module safety plan.


.. gd_guidl:: Safety manual generation
   :id: gd_guidl__saf_man
   :status: valid
   :version: 1
   :complies: std_req__iso26262__system_6411[version==1],
              std_req__iso26262__system_6412[version==1],
              std_req__iso26262__system_6413[version==1],
              std_req__iso26262__system_6414[version==1],
              std_req__iso26262__system_6421[version==1],
              std_req__iso26262__system_6422[version==1],
              std_req__iso26262__software_641[version==1],
              std_req__iso26262__software_642[version==1],
              std_req__iso26262__software_645[version==1],
              std_req__iso26262__support_12421[version==1]

   | The safety manual collects several workproducts and adds some additional content mainly to instruct the user of
   | a SEooC (in this project on platform and module level) to safely use it in the context of the user's own safety
   | element.
   | Its main content is described in :need:`wp__platform_safety_manual` and :need:`wp__module_safety_manual`
   | A template exists to guide the definition of the safety manual on platform and module level (:need:`gd_temp__safety_manual`).

.. gd_guidl:: Safety package automated generation
   :id: gd_guidl__saf_package
   :status: valid
   :version: 1
   :complies: std_req__iso26262__management_6481[version==1], std_req__iso26262__management_6482[version==1]

   | The safety package shall be generated progressively and automatically compiling the work products.
   | One of the checks to perform on the platform safety package is to check completeness of the
   | process compliance to standards, which can be seen from standard linkage charts in :ref:`external_standards`.


Tailoring
^^^^^^^^^

.. gd_guidl:: Safety Mgt Tailored
   :id: gd_guidl__saf_tailored
   :status: valid
   :version: 1
   :complies: std_req__iso26262__support_12423[version==1],
              std_req__iso26262__management_6453[version==1],
              std_req__iso26262__management_6454[version==1],
              std_req__iso26262__management_6456[version==1],
              std_req__iso26262__management_64610[version==1],
              std_req__iso26262__management_64121[version==1],
              std_req__iso26262__management_64122[version==1],
              std_req__iso26262__management_64123[version==1],
              std_req__iso26262__management_64124[version==1],
              std_req__iso26262__management_64125[version==1],
              std_req__iso26262__management_64126[version==1],
              std_req__iso26262__management_64127[version==1],
              std_req__iso26262__management_64128[version==1],
              std_req__iso26262__management_64129[version==1],
              std_req__iso26262__management_641210[version==1],
              std_req__iso26262__management_641211[version==1],
              std_req__iso26262__management_641212[version==1],
              std_req__iso26262__management_641213[version==1]

   This part of the guideline links to all the requirements which are not fulfilled by the
   safety management process. Make sure these are tailored out in the safety/security/quality plans
   for your project (documented in the PMP). Reasoning given below must be confirmed there.

   The reasoning is:

   - for "support" standard requirements: The requirement is not applicable for an ASIL_B process
   - for "management" standard requirements: 6453 - not proven in use argument, 6454 - no HW part of SW platform, 6456 - no confidence in use, 64610 - no distributed development
   - for "management" standard requirements 6412*: No assessment planned, as also no finalized safety case is planned
