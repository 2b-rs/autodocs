..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

06-xx
~~~~~

.. std_req:: 06-04 Training material
   :id: std_req__aspice_40__iic-06-04
   :status: valid
   :version: 1

   Training material may have the following characteristics:

   - Updated and available for new releases
   - Coverage of system, application, operations, maintenance as appropriate to the application
   - Course listings and availability

.. std_req:: 06-50 Integration Sequence Instruction
   :id: std_req__aspice_40__iic-06-50
   :status: valid
   :version: 1

   Integration Sequence Instruction may have the following characteristics:

   - Identification of required physical elements (e.g., hardware,
     mechanical, wiring elements), and software executables and
     application parameters (being a technical implementation solution for
     configurability-oriented requirements)
   - necessary sequence or ordering of integration
   - preconditions for starting system integration

.. std_req:: 06-51 Tailoring guideline
   :id: std_req__aspice_40__iic-06-51
   :status: valid
   :version: 1

   Tailoring guideline may have the following characteristics:

   - Criteria for tailoring,
   - Proceeding of tailoring describing how to derive and document the defined process from the standard process
     including responsibility for tailoring and corresponding approval
   - Requirements for the defined process to ensure integrity and consistency of the defined process
   - Subset of process assets that is essential for the defined process

.. std_req:: 06-52 Backup and recovery mechanism information
   :id: std_req__aspice_40__iic-06-52
   :status: valid
   :version: 1

   Backup and recovery mechanism information may have the following characteristics:

   - Description / confirmation of existing backup and recovery mechanisms
   - References to corresponding procedures or regulations


.. needextend:: "c.this_doc()" 
   :+tags: aspice40_iic06
