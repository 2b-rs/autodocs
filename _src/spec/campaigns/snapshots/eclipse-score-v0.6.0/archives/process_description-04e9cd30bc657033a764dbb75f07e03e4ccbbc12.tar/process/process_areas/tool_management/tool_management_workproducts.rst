..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Tool Management Work Products
#############################

.. workproduct:: Platform Tool Management Plan
   :id: wp__tlm_plan
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__org_management_554[version==1],
              std_req__aspice_40__iic-16-03[version==1],
              std_req__aspice_40__iic-01-52[version==1],
              std_req__aspice_40__iic-10-52[version==1]

   Tool Management Plan (Part of the Platform Management Plan)

.. workproduct:: Tool Verification Report
   :id: wp__tool_verification_report
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__support_1151[version==1], std_wp__iso26262__support_1152[version==1], std_wp__isosae21434__org_management_554[version==1]

   According to the safety tool process, each tool's confidence level (TCL) must be determined.
   In addition security topics must be considered, as tool user manuals, access control for tools,
   proper tool documentation, guidelines, protection against malware introduction, etc.

   Based on TCL the appropriate qualification methods shall be applied. For the project
   the method **validation of software tool** must be used.
