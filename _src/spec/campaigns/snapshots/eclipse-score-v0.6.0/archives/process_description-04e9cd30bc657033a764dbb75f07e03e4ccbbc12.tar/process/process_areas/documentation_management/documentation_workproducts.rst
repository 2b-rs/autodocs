..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Documentation Management Work Products
######################################

.. workproduct:: Documentation Management Plan
   :id: wp__document_mgt_plan
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__support_1051[version==1], std_wp__iso26262__support_1052[version==1], std_req__aspice_40__iic-01-52[version==1]

   Document Management Plan (Part of the Platform Management Plan)

   Defines the documentation strategy which covers the following aspects:

   * How to review, update, (re-)approve documentations?
   * What is the status of a document and how are changes identified?
   * How to ensure the availability of the documents over time?
   * How to ensure the controlled distribution of documents?
   * How to avoid distribution of obsolete documents?
   * Which formal elements are used?
   * List of all documents including their status
