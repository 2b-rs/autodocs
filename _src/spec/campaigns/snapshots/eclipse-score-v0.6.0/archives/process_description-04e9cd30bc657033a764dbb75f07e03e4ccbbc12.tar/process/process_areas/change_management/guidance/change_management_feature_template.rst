..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _chm_feature_templates:

Feature Template
================

.. gd_temp:: Feature Request Template
   :id: gd_temp__change_feature_request
   :status: valid
   :version: 1
   :complies: std_req__aspice_40__SUP-10-BP1[version==1],
              std_req__aspice_40__SUP-10-BP2[version==1],
              std_req__aspice_40__SUP-10-BP3[version==1],
              std_req__aspice_40__SUP-10-BP5[version==1],
              std_req__aspice_40__iic-18-57[version==1],
              std_req__iso26262__support_8422[version==1],
              std_req__iso26262__support_8431[version==1],
              std_req__iso26262__support_8432[version==1],
              std_req__iso26262__management_644[version==1],
              std_req__isopas8926__4431[version==1],
              std_req__aspice_40__iic-13-16[version==1],
              std_req__aspice_40__iic-14-02[version==1]

   for the content see :need:`doc__feature_name`
