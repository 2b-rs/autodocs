..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

04-xx
~~~~~

.. std_req:: 04-02 Domain architecture
   :id: std_req__aspice_40__iic-04-02
   :status: valid
   :version: 1

   Definition not available yet in PAM4.0 document.

.. std_req:: 04-04 Software Architecture
   :id: std_req__aspice_40__iic-04-04
   :status: valid
   :version: 1

   Software Architecture may have the following characteristics:

   - A justifying rationale for the chosen architecture.
   - Individual functional and non-functional behavior of the software
     component
   - Settings for application parameters (being a technical implementation
     solution for configurability-oriented requirements)
   - Technical characteristics of interfaces for relationships between software components such as:

     - Synchronization of Processes and tasks
     - Programming language call
     - APIs
     - Specifications of SW libraries
     - Method definitions in an object- oriented class definitions or
       UML/SysML interface classes
     - Callback functions, “hooks”

   - Dynamics of software components and software states such as:

     - Logical software operating modes (e.g, start-up, shutdown, normal
       mode, calibration, diagnosis, etc.)
     - intercommunication (processes, tasks, threads) and priority
     - time slices and cycle time
     - interrupts with their priorities
     - interactions between software components

   - Explanatory annotations, e.g, with natural language, for single elements
     or entire diagrams/models.

.. std_req:: 04-05 Software detailed design
   :id: std_req__aspice_40__iic-04-05
   :status: valid
   :version: 1

   Software detailed design may have the following characteristics:

   - Elements of a software detailed design:

     - Control flow definition
     - Format of input/output data
     - Algorithms
     - Defined data structures
     - Justified global variables
     - Explanatory annotations, e.g, with natural language, for single
       elements or entire diagrams/models

   - Examples for expression languages, depending on the complexity or criticality of a software unit:

     - natural language or informal languages
     - semi-formal languages (e.g, UML, SysML)
     - formal languages (e.g, model-based approach)

.. std_req:: 04-51 ML architecture
   :id: std_req__aspice_40__iic-04-51
   :status: valid
   :version: 1

   - An ML architecture is basically a special part of a software architecture (see 04-04). Additionally

     - ML architecture describes the overall structure of the ML-based software element
     - ML architecture specifies ML architectural elements including an ML model and other ML architectural elements, provided to train, deploy, and test the ML model.
     - describes interfaces within the ML-based software element and to other software elements
     - ML architecture describes details of the ML model like used layers, activation functions, loss function, and backpropagation
     - ML architecture contains defined hyperparameter ranges and initial values for training start
     - resource consumption objectives are defined
     - ML architecture contains allocated ML requirements

.. needextend:: "c.this_doc()"
   :+tags: aspice40_iic04
