..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

SUP.1 Quality Assurance
-----------------------

The purpose of the Quality Assurance Process is to provide independent and objective assurance that work products
and processes comply with defined criteria and that non-conformances are resolved and further prevented.

Process outcomes
~~~~~~~~~~~~~~~~

1. Quality assurance is performed independently and objectively without conflicts of interest.
2. Criteria for the quality of work products and process performance are defined.
3. Conformance of work products and process performance with the defined criteria and
   targets is verified, documented and communicated to the relevant parties.
4. Non-conformances are tracked, resolved, and further prevented.
5. Non-conformances are escalated to appropriate levels of management.
6. Management ensures that escalated non-conformances are resolved.

Base practices
~~~~~~~~~~~~~~

.. std_req:: SUP.1.BP1: Ensure independence of quality assurance
   :id: std_req__aspice_40__SUP-1-BP1
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-16-50[version==1]

   Ensure that quality assurance is performed independently and objectively without conflicts of interest.

   .. note::

      Possible inputs for evaluating the independence may be assignment to financial and/or organizational
      structure as well as responsibility for processes that are subject to quality assurance (no self-monitoring).

.. std_req:: SUP.1.BP2: Define criteria for quality assurance
   :id: std_req__aspice_40__SUP-1-BP2
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-18-07[version==1]

   Define quality criteria for work products as well as for process tasks and their performance.

   .. note::

      Quality criteria may consider internal and external inputs such as customer requirements, standards, milestones, etc.

.. std_req:: SUP.1.BP3: Assure quality of work products
   :id: std_req__aspice_40__SUP-1-BP3
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-18-07[version==1],
           std_req__aspice_40__iic-13-52[version==1],
           std_req__aspice_40__iic-13-18[version==1],
           std_req__aspice_40__iic-13-19[version==1],
           std_req__aspice_40__iic-14-02[version==1]

   Identify work products subject to quality assurance according to the quality criteria.
   Perform appropriate activities to evaluate the work products against the defined quality criteria and document the results.

   .. note::

      Quality assurance activities may include reviews, problem analysis and
      lessons learned that improve the work products for further use.

.. std_req:: SUP.1.BP4: Assure quality of process activities
   :id: std_req__aspice_40__SUP-1-BP4
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-18-07[version==1],
           std_req__aspice_40__iic-13-52[version==1],
           std_req__aspice_40__iic-13-18[version==1],
           std_req__aspice_40__iic-13-19[version==1],
           std_req__aspice_40__iic-14-02[version==1]

   Identify processes subject to quality assurance according to the quality criteria.
   Perform appropriate activities to evaluate the processes against their defined quality criteria and
   associated target values and document the results.

   .. note::

      Quality assurance activities may include process assessments, problem analysis, regular check of methods, tools, and
      the adherence to defined processes, and consideration of lessons learned.

.. std_req:: SUP.1.BP5: Summarize and communicate quality assurance activities and results
   :id: std_req__aspice_40__SUP-1-BP5
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-16-50[version==1],
           std_req__aspice_40__iic-18-52[version==1],
           std_req__aspice_40__iic-18-07[version==1],
           std_req__aspice_40__iic-13-52[version==1],
           std_req__aspice_40__iic-13-18[version==1],
           std_req__aspice_40__iic-13-19[version==1],
           std_req__aspice_40__iic-14-02[version==1]

   Regularly report performance, non-conformances, and trends of quality assurance activities to all affected parties.

.. std_req:: SUP.1.BP6: Ensure resolution of non-conformances
   :id: std_req__aspice_40__SUP-1-BP6
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-18-52[version==1],
           std_req__aspice_40__iic-18-07[version==1],
           std_req__aspice_40__iic-13-52[version==1],
           std_req__aspice_40__iic-13-18[version==1],
           std_req__aspice_40__iic-13-19[version==1],
           std_req__aspice_40__iic-14-02[version==1]

   Analyze, track, correct, resolve, and further prevent non-conformances found in quality assurance activities.

   .. note::

      Non-conformances detected in work products may be entered into the problem resolution management process (SUP.9).

   .. note::

      Non-conformances detected in the process definition or implementation may be entered into a process improvement process (PIM.3).

.. std_req:: SUP.1.BP7: Escalate non-conformances
   :id: std_req__aspice_40__SUP-1-BP7
   :status: valid
   :version: 1
   :links: std_req__aspice_40__iic-16-50[version==1],
           std_req__aspice_40__iic-18-52[version==1],
           std_req__aspice_40__iic-13-52[version==1],
           std_req__aspice_40__iic-14-02[version==1]

   Escalate relevant non-conformances to appropriate levels of management and other relevant stakeholders to facilitate their resolution.

   .. note::

      The decision whether to escalate non-conformances may be based on criteria such as delay of resolution, urgency, and risk.


.. needextend:: "c.this_doc()" 
   :+tags: aspice40_sup1
