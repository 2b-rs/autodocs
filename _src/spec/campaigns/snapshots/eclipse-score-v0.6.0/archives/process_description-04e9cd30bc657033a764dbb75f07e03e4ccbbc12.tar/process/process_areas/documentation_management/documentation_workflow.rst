..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Documentation Management Workflow
#################################

For a detailed explanation of workflows and their role within the process model, please refer to the :ref:`processes_introduction`.

The main work product is the documentation management plan, which is a part of the platform
management plan. Thus the work flow :need:`wf__platform_cr_mt_platform_mgmt_plan` applies.

The documentation management plan should contain the strategy to manage the identified
documentations in an effective and repeatable way for the project life cycle.
