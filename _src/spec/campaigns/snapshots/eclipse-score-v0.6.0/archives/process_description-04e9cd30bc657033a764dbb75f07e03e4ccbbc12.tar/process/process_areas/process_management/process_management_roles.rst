..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Roles
#####

For process management no additional roles need to be defined.

Contributing Roles:

   * :need:`Contributor <rl__contributor>`
   * :need:`Process Community <rl__process_community>`
   * :need:`Safety External Auditor <rl__safety_external_auditor>`
   * :need:`Security External Auditor <rl__security_external_auditor>`
   * :need:`Project Lead <rl__project_lead>`

A detailed overview of the responsibility for the steps of the requirement process is listed here:

:ref:`workflow_process_management_requirements`
