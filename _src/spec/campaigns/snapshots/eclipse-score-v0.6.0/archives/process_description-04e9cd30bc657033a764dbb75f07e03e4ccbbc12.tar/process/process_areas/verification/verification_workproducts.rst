..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _verification_work_products:

Verification Work Products
##########################

Platform
********

.. workproduct:: Verification Plan
   :id: wp__verification_plan
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__support_951[version==1],
              std_wp__iso26262__support_952[version==1],
              std_wp__iso26262__support_1252[version==1],
              std_wp__isosae21434__development_1056[version==1]

   Verification planning for each phase of the safety lifecycle must detail the work products,
   objectives, methods, criteria, environments, equipment, resources, actions for anomalies, and
   regression strategies, considering method adequacy, complexity, prior experiences, and
   technology maturity or risks.
   This also covers the work product Verification Specification.

.. workproduct:: Platform Integration Test
   :id: wp__verification_platform_int_test
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__support_952[version==1], std_wp__isosae21434__development_1057[version==1]

   Platform Integration Testing verifies Stakeholder Requirements performed on reference HW.
   Depending on the nature of the project, respective tailoring (e.g. for reduced requirements
   coverage) has to be reflected in the :need:`wp__verification_plan` and :need:`wp__platform_safety_plan`.

   If software partitioning (operating system processes) is used to implement freedom from interference
   effectiveness evidence shall be generated during integration tests.


.. workproduct:: Platform Verification Report
   :id: wp__verification_platform_ver_report
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__software_1053[version==1],
              std_wp__iso26262__support_953[version==1],
              std_wp__iso26262__analysis_752[version==1],
              std_wp__iso26262__analysis_852[version==1],
              std_wp__isosae21434__development_1054[version==1],
              std_wp__isosae21434__development_1057[version==1]

   Verification Report contains:

   - List of requirements (stakeholder and feature) and architecture tested by which test
     (can be several levels), passed/failed and completeness verdict, including normal
     operation and failure reactions
   - The list of requirements may also contain other verification methods like "Analysis"
   - Formal evidence about the performed DFA
   - Formal evidence about the performed Safety Analyses
   - Test result per test case from
     :need:`wp__verification_platform_int_test` and :need:`wp__verification_feat_int_test`
     with status passed/failed/not_run
   - Test log per executed test case from
     :need:`wp__verification_platform_int_test` and :need:`wp__verification_feat_int_test`
     with status passed/failed including a link to the matching retained execution log artifacts for the specific release version

Feature
*******

.. workproduct:: Feature Integration test
   :id: wp__verification_feat_int_test
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__software_1051[version==1], std_wp__iso26262__support_952[version==1]

   Integration Testing verifies feature requirements and architecture:

   - all interfaces from Static view and
   - all flows from Dynamic View and
   - performance and resource consumption: i.e. RAM and processor usage
     on reference HW
   - If software partitioning (operating system processes) is used to implement freedom from interference
     effectiveness evidence shall be generated during integration tests.


Module
******

.. workproduct:: Module Verification Report
   :id: wp__verification_module_ver_report
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__software_952[version==1],
              std_wp__iso26262__software_1053[version==1],
              std_wp__iso26262__support_953[version==1],
              std_wp__iso26262__support_1253[version==1],
              std_wp__iso26262__analysis_752[version==1],
              std_wp__iso26262__analysis_852[version==1],
              std_wp__iso26262__support_1252[version==1],
              std_wp__isopas8926__4526[version==1],
              std_wp__iso26262__software_app_c_56[version==1]

   Verification Report contains:

   - List of requirements (and architecture/detailed design tags) tested by which test
     (can be several levels), passed/failed and completeness verdict, including normal
     operation and failure reactions
   - The list of requirements may also contain other verification methods like "Analysis"
   - Structural Coverage (C0 and C1, from unit testing on host) per unit
   - Static Code Analysis (including compiler warnings, automated checking of coding guidelines
     and additional checks)
   - Formal evidence about the performed DFA
   - Formal evidence about the performed Safety Analyses
   - Software component qualification verification report
   - Test result per test case from
     :need:`wp__verification_sw_unit_test` and :need:`wp__verification_comp_int_test`
     with status passed/failed/not_run
   - Test log per test case from
     :need:`wp__verification_sw_unit_test` and :need:`wp__verification_comp_int_test`
     with status passed/failed/not_run including a link to the matching retained execution log artifacts for the specific release version

   It also serves as SW Component Qualification Verification Report for pre-existing Open Source
   Projects developed and maintained outside of the project to which this process is applied to.
   It is also described in the :need:`gd_temp__mod_ver_report` as a dedicated section.

Component
*********

.. workproduct:: Component Integration test
   :id: wp__verification_comp_int_test
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__software_1051[version==1],
              std_wp__iso26262__support_952[version==1],
              std_wp__isopas8926__4525[version==1],
              std_wp__iso26262__software_app_c_55[version==1]

   Component Integration Testing verifies the component architecture and component requirements:

   - all interfaces from Static view and
   - all flows from Dynamic View
   - integration of units into components based on detailed design
   - detailed design of complex units

   Performance (i.e. RAM and processor usage) is only tested on reference HW.

   As an optional part component integration tests can cover additional testing for complex units
   touching specifically the detailed design. This is needed where :need:`wp__verification_sw_unit_test`
   is not sufficient to cover the measures defined in the implementation of the :need:`wp__verification_plan`.

.. workproduct:: Unit test
   :id: wp__verification_sw_unit_test
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__software_951[version==1],
              std_wp__iso26262__support_952[version==1],
              std_wp__isopas8926__4525[version==1],
              std_wp__iso26262__software_app_c_55[version==1]

   Unit testing verifies detailed design (traced to).
   Respective tooling is defined in :need:`wp__platform_mgmt`, :need:`wp__verification_plan` and integrated in CI/Build.
   Unit testing is in responsible of the :need:`rl__contributor` providing the :need:`wp__sw_implementation`.
   The compiled tests run against the actual source code compiled for the component or reference integration and their
   targeted HW architecture (e.g. arm64 or x86).

Inspection
**********

Inspection activities on requirement, architecture and detailed design are handled within these process areas.

The work products are handled within these process areas:

     * :ref:`requirements_engineering` implementing :need:`wp__requirements_inspect`
     * :ref:`arch_design_process` implementing :need:`wp__sw_arch_verification`
     * :ref:`implementation` implementing :need:`wp__sw_implementation_inspection`

Tool Verification
*****************

As part of tool management as supporting function it is handled as follows

     * :need:`wf__tool_create_tool_verification_report` describes implementation of :need:`wp__tool_verification_report`

It is planned in the :need:`wp__platform_mgmt`
