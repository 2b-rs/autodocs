..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

01-xx
~~~~~

.. std_req:: 01-03 Software Component
   :id: std_req__aspice_40__iic-01-03
   :status: valid
   :version: 1

   Software Component may have the following characteristics:

   - Software element in the software architecture above the software unit
     level.
   - Represented by a design model element or executable code such as
     libs or scripts and a configuration description, if applicable.


.. std_req:: 01-50 Integrated Software
   :id: std_req__aspice_40__iic-01-50
   :status: valid
   :version: 1

   Integrated Software may have the following characteristics:

   - Software executable (e.g, simulator with stubbing, debug-able, object
     code) including:

     - application parameter files (being a technical implementation solution for configurability-oriented requirements)
     - all configured software elements

.. std_req:: 01-52 Configuration item list
   :id: std_req__aspice_40__iic-01-52
   :status: valid
   :version: 1

   Configuration item list may have the following characteristics:

   - Items under configuration control
   - The name of work products and an associated reference (to file, to tool artifact)
   - Configuration item attributes and properties

.. std_req:: 01-53 Trained ML model
   :id: std_req__aspice_40__iic-01-53
   :status: valid
   :version: 1

   - The trained ML model is the output of the training process. It consists of the software representing the ML architecture, the set of weights which were optimized during the training, and the final set of hyperparameters.

.. std_req:: 01-54 Hyperparameter
   :id: std_req__aspice_40__iic-01-54
   :status: valid
   :version: 1


   - Hyperparameters are used to control the ML model which has to be trained, e.g.:
        - Learn rate of training
        - Scaling of network (number of layers or neurons per layer)
        - Loss function
   - Minimum characteristics:
        - Description
        - Initial value
        - Final value upon communicating the results of the ML training

.. needextend:: "c.this_doc()"
   :+tags: aspice40_iic01
