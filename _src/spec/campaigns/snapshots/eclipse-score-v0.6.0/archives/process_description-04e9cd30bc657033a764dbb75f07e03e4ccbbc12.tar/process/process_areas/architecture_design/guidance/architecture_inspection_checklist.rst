..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _architecture_inspection_checklist:

Architecture Inspection Checklist Template
==========================================

.. gd_chklst:: Architecture Inspection Checklist Template
    :id: gd_chklst__arch_inspection_checklist
    :status: valid
    :version: 1
    :tags: architecture_design
    :complies: std_req__iso26262__software_647[version==1],
               std_req__iso26262__software_743[version==1],
               std_req__iso26262__software_749[version==1],
               std_req__iso26262__software_7413[version==1],
               std_req__aspice_40__iic-15-51[version==1],
               std_req__aspice_40__SWE-2-BP4[version==1],
               std_req__aspice_40__iic-13-51[version==1],
               std_req__aspice_40__SWE-2-BP5[version==1]

    For the content see here:

    - `Component Architecture Inspection Checklist <https://eclipse-score.github.io/module_template/main/score/component_example/docs/architecture/chklst_arc_inspection.html>`__
    - `Feature Architecture Inspection Checklist <https://eclipse-score.github.io/module_template/main/docs/features/feature_example/architecture/chklst_arc_inspection.html>`__

    These two documents have the same questions, but different scope and document naming.
