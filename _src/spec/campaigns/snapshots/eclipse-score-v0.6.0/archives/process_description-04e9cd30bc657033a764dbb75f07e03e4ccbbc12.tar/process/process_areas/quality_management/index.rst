..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _quality_management:

Quality Management
##################

.. toctree::
   :maxdepth: 1

   quality_getstrt
   quality_concept
   guidance/index
   quality_roles
   quality_workflow
   quality_workproducts

.. needextend:: docname is not None and "process_areas/quality_management" in docname
   :+tags: quality_management
