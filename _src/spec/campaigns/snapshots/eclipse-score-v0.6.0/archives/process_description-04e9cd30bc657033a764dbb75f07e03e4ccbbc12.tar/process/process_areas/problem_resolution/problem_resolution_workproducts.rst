..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Problem Resolution Work Products
################################

.. workproduct:: Platform Problem Resolution Plan
   :id: wp__prm_plan
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__iso26262__support_851[version==1]

   Problem Resolution Plan (Part of the Platform Management Plan)
