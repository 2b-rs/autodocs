..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Roles
#####

.. role:: Safety Manager
   :id: rl__safety_manager
   :status: valid
   :version: 1
   :contains: rl__committer[version==1]

   The safety manager is responsible for making sure that ISO26262 is complied to in the project. He/She shall lead and monitor the safety relevant activities of the project.

   This role is assigned through a transparent, meritocratic election process similar to committer elections.
   Only existing committers are eligible. Nominations must include evidence of relevant contributions and safety expertise.
   The election must be public, archived, and follow Eclipse Foundation principles of openness and neutrality.
   The criteria for nomination and election must be documented and published on the project’s website.

   Required skills

   * Degree: Master's degree in electrical engineering/computer science/mathematics, or similar degree, or comparable work experience
   * Solid understanding of functional safety management
   * Knowledge in project management
   * Deep understanding of quality criteria and the correlating methods and procedures to achieve and verify them
   * Technical know-how of embedded systems
   * Preferred training: Automotive Functional Safety Expert (AFSE) or similar

   Knowledge of standards

   * ISO 26262

   Experience

   * 3 years of experience in the management of safety topics
   * Experience in managing projects
   * Experience in managing safety anomalies

   Responsibility

   * Creating the Safety Plan
   * Functional Safety related project status reporting
   * Creation and Monitoring of completeness of the safety package
   * Reporting of safety anomalies
   * Verify, that the preconditions for the "release for production", which are  part of the release notes, are fulfilled, and the correctness, completeness and consistency of the release notes
   * Coaching the project team w.r.t all questions related to functional safety
   * Planning of safety audit
   * Approval of OSS component classification and safety analyses (incl. DFA)
   * Approval of the Safety Package
   * Creating the safety manuals on platform and module level
   * Performing/approval of formal document reviews on safety plans, safety package and safety analysis (incl. DFA)
   * Checking that every person in his team has sufficient safety skills for his role

   Authority

   * Escalation of planning topics to the project manager defined in the safety plan
   * Initiate the publication of a safety anomaly
   * Recommend the Release of a SW platform or a module
   * Refusing the approval of work products as defined in the workflows
   * Refusing the approval of his team's role nomination (i.e. requesting that the role will be withdrawn)

.. role:: Safety External Auditor
   :id: rl__safety_external_auditor 
   :status: valid
   :version: 1

   Required skills, Knowledge of standards, Experience

   * External Auditor comes from organization specialized in safety audits and assessment, thus sufficient skill should be guaranteed by the sending organization.
   * For performing the formal document reviews also a safety manager from another Eclipse Safety project can play the role of an external auditor, in this case the same skills apply as for the safety manager.

   Responsibility

   * Performing and reporting of safety audit

   Authority

   * Decision on the passing or failing of an audit
