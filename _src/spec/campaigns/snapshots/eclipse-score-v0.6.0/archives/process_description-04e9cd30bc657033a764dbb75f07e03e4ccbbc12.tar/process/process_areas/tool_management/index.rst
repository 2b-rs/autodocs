..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _tool_management:

Tool Management
###############

.. toctree::
   :maxdepth: 1

   tool_management_getstrt
   tool_management_concept
   guidance/index
   tool_management_roles
   tool_management_workflow
   tool_management_workproducts

.. needextend:: docname is not None and "docs/process/tool_management" in docname
   :+tags: tool_management
