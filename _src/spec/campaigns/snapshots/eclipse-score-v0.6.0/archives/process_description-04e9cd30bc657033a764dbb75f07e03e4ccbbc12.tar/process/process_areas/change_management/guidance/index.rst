..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Guidance
########

.. toctree::
   :maxdepth: 1

   change_management_guideline
   change_management_checklist
   change_management_feature_template
   change_management_component_template
   change_management_impact_analysis_template
   change_management_reqs
   change_management_decision_record_template
