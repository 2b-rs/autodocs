..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _prm_checklist:

Problem Checklist
#################

.. gd_chklst:: Problem Review Checklist
   :id: gd_chklst__problem_cr_review
   :status: valid
   :version: 1
   :tags: problem_resolution
   :complies:

   | **1. Purpose**
   | The purpose of this checklist is to collect the topics to be checked during a Problem report from any contributor.
   | It will not be filled out but considered during the review and monitoring to closure of the Problem Report.
   |
   | **2. Checklist**
   |

   See also :ref:`review_concept` for further information about reviews in general and inspection in particular.

   .. list-table:: Problem Report Review Checklist
      :header-rows: 1
      :widths: 10,30,6

      * - Id
        - Topic
        - Status [FAIL|PASS]
      * - 1
        - Does the Problem Report follow the template?
        -

      * - 2
        - Are all required topics of the Problem template filled?
        -

      * - 3
        - Does the Problem report have a UID as specified?
        -

      * - 4
        - Does the Problem report have a title as specified?
        -

      * - 5
        - Does the Problem report have a status as specified?
        -

      * - 6
        - Does the Problem report have a submitter as specified?
        -

      * - 7
        - Does the Problem report have a description as specified?
        -

      * - 8
        - Does the Problem report have a stakeholder as specified?
        -

      * - 9
        - Does the Problem report have a category as specified?
        -

      * - 10
        - Does the Problem report have a classification as specified?
        -

      * - 11
        - Does the Problem report have the affected release versions as specified?
        -

      * - 12
        - Does the Problem report have an expected closure date as specified?
        -

      * - 13
        - Does the Problem report have the solution measures specified, verified and reported?
        -

      * - 14
        - If the Problem report is not closed and pending solution measures are open, escalated to the :need:`rl__safety_manager` or :need:`rl__security_manager`?
        -
