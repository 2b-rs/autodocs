..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Roles
#####

For change management no additional roles need to be defined.

Contributing Roles:

   * :need:`Contributor <rl__contributor>`
   * :need:`Architecture Team <rl__architecture_community>`
   * :need:`Platform Team <rl__platform_team>`
   * :need:`Project Lead <rl__project_lead>`
   * :need:`Delivery Team <rl__delivery_team>`

A detailed overview of the responsibility for the steps of the requirement process is listed here:

:ref:`workflow_chm_requirements`
