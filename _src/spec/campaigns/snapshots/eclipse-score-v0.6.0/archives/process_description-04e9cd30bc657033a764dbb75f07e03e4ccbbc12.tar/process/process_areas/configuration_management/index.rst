..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _process_configuration_management:

Configuration Management
========================

.. toctree::
   :maxdepth: 1

   configuration_getstrt
   configuration_concept
   guidance/index
   configuration_roles
   configuration_workflow
   configuration_workproducts

.. needextend:: docname is not None and "process_areas/configuration_management" in docname
   :+tags: configuration_management
