..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _problem_workflows:

Problem Resolution Workflows
############################

For a detailed explanation of workflows and their role within the process model, please refer to the :ref:`processes_introduction`.

.. workflow:: Create Problem Report
   :id: wf__problem_create_pr
   :status: valid
   :version: 1
   :responsible: rl__contributor[version==1]
   :approved_by: rl__committer[version==1]
   :supported_by: rl__project_lead[version==1],
                  rl__safety_manager[version==1],
                  rl__security_manager[version==1],
                  rl__quality_manager[version==1]
   :input: wp__issue_track_system[version==1], wp__prm_plan[version==1]
   :output: wp__issue_track_system[version==1]
   :contains: gd_temp__problem_template[version==1], gd_chklst__problem_cr_review[version==1], gd_guidl__problem_problem[version==1]
   :has: doc_concept__problem_process[version==1], doc_getstrt__problem_process[version==1]

   The Problem Report is created.

   For creating the Problem Report template must be used.

   To start the review and the analysis the Problem status is changed to "in review"

.. workflow:: Analyze Problem Report
   :id: wf__problem_analyze_pr
   :status: valid
   :version: 1
   :responsible: rl__contributor[version==1]
   :approved_by: rl__committer[version==1]
   :supported_by: rl__project_lead[version==1],
                  rl__safety_manager[version==1],
                  rl__security_manager[version==1],
                  rl__quality_manager[version==1]
   :input: wp__issue_track_system[version==1], wp__prm_plan[version==1]
   :output: wp__issue_track_system[version==1]
   :contains: gd_temp__problem_template[version==1], gd_chklst__problem_cr_review[version==1], gd_guidl__problem_problem[version==1]
   :has: doc_concept__problem_process[version==1], doc_getstrt__problem_process[version==1]

   The Problem Report is analyzed.

   Until the template is not filled out properly, the Problem may be set back to “open” from the
   :need:`Committer <rl__committer>`.

   If the Problem shall be resolved, the Problem status is set to "in implementation", otherwise
   to "rejected".

   The author of the Problem Report may cancel it, thus the status is set to "rejected".

.. workflow:: Initiate and Monitor Problem Resolution
   :id: wf__problem_initiate_monitor_pr
   :status: valid
   :version: 1
   :responsible: rl__contributor[version==1]
   :approved_by: rl__committer[version==1]
   :supported_by: rl__project_lead[version==1],
                  rl__safety_manager[version==1],
                  rl__security_manager[version==1],
                  rl__quality_manager[version==1]
   :input: wp__issue_track_system[version==1], wp__prm_plan[version==1]
   :output: wp__issue_track_system[version==1]
   :contains: gd_temp__problem_template[version==1], gd_chklst__problem_cr_review[version==1], gd_guidl__problem_problem[version==1]
   :has: doc_concept__problem_process[version==1], doc_getstrt__problem_process[version==1]

   The Problem Resolution is implemented and monitored.

   This may require Change Requests or other activities, including creating ISSUEs and PRs.
   These are linked to the Problem and monitored until closure.

   The Problem Resolution is done, if all linked activities has been closed and confirmed.
   Before closing the Problem Resolution, :need:`Committer <rl__committer>` must check the
   correctness.

   The :need:`Committer <rl__committer>` may still reject it, thus the status is set to "rejected".

   The author of the Problem Report may cancel it, thus the status is set to "rejected".

.. workflow:: Close Problem Resolution
   :id: wf__problem_close_pr
   :status: valid
   :version: 1
   :responsible: rl__committer[version==1]
   :approved_by: rl__project_lead[version==1]
   :supported_by: rl__safety_manager[version==1], rl__security_manager[version==1], rl__quality_manager[version==1]
   :input: wp__issue_track_system[version==1], wp__prm_plan[version==1]
   :output: wp__issue_track_system[version==1]
   :contains: gd_temp__problem_template[version==1], gd_chklst__problem_cr_review[version==1], gd_guidl__problem_problem[version==1]
   :has: doc_concept__problem_process[version==1], doc_getstrt__problem_process[version==1]

   The Problem Resolution is closed.

   The Problem Resolution is closed only, if the implementation is sufficient. That is verified
   by the :need:`Committer <rl__committer>` finally.

   Otherwise the :need:`Committer <rl__committer>` keeps the status "in implementation".

.. needextend:: docname is not None and "process_areas/problem_resolution" in docname
   :+tags: problem_resolution

RAS(IC) for Problem Resolution:
*******************************

.. needtable:: RASIC Overview for Problem Resolution
   :tags: problem_resolution
   :filter: "problem_resolution" in tags and type == "workflow" and is_external == False
   :style: table
   :sort: status
   :columns: id as "Activity";responsible as "Responsible";approved_by as "Approver";supported_by as "Supporter"
   :colwidths: 30,30,30,30
