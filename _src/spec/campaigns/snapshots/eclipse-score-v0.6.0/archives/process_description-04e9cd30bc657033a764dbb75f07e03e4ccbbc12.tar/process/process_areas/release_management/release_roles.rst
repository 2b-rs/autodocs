..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Roles
#####

For Release Management no additional roles need to be defined.

Contributing Roles:

   * :need:`Committer <rl__committer>`
   * :need:`Project Lead <rl__project_lead>`
   * :need:`Release Team <rl__release_team>`

A detailed overview of the responsibility for the steps of the Release Management process
is listed here: :need:`doc_concept__rel_process`
