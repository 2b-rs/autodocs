..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

08-xx
~~~~~

.. std_req:: 08-53 Scope of work
   :id: std_req__aspice_40__iic-08-53
   :status: valid
   :version: 1

   Scope of work may have the following characteristics:

   - Summary of deliverables for a project
   - Intended use for the deliverables
   - Main functions to be realized
   - Target delivery date and major milestones
   - Work products and activities that are not in scope of the project as needed
   - Target markets
   - Applicable standards and legal requirements
   - Reuse options
   - Integration of third party deliveries

.. std_req:: 08-54 Feasibility analysis
   :id: std_req__aspice_40__iic-08-54
   :status: valid
   :version: 1

   Feasibility analysis may have the following characteristics:

   - Statement about the ability of the project to achieve
     the project objectives with available resources

.. std_req:: 08-55 Risk measure
   :id: std_req__aspice_40__iic-08-55
   :status: valid
   :version: 1

   Risk measure may have the following characteristics:

   - Identifies
       - the risk to be mitigated, avoided, or shared (transferred)
       - the activities to mitigate, avoid, or share (transfer) the risk
       - the originator of the measure
       - criteria for successful implementation
       - criteria for cancellation of activities
       - frequency of monitoring
   - Risk treatment alternatives:
       - treatment option selected- avoid/reduce/transfer
       - alternative descriptions
       - recommended alternative(s)
       - justifications

.. std_req:: 08-56 Schedule
   :id: std_req__aspice_40__iic-08-56
   :status: valid
   :version: 1

   Schedule may have the following characteristics:

   - Identifies the activities to be performed
   - Identifies the expected, and actual, start and completion date for required activities against progress/completion of activities
   - Identifies dependencies between activities and critical path
   - Has a mapping to scheduled resources and input data
   - Identifies resource allocation, resource workload, and critical resources

   .. note::

      A schedule is consistent with the defined work packages, see 14-10

.. std_req:: 08-58 Verification Measure Selection Set
   :id: std_req__aspice_40__iic-08-58
   :status: valid
   :version: 1

   Verification Measure Selection Set may have the following characteristics:

   - Include criteria for re-verification in the case of changes (regression).
   - Identification of verification measures, also for regression testing.

.. std_req:: 08-60 Verification Measure
   :id: std_req__aspice_40__iic-08-60
   :status: valid
   :version: 1

   Verification Measure may have the following characteristics:

   - A verification measure can be a test case, a measurement, a
     calculation, a simulation, a review, an optical inspection, or an analysis
   - The specification of a verification measure includes

     - pass/fail criteria for verification measures (test completion and ending criteria)
     - a definition of entry and exit criteria for the verification measures, and abort and re-start criteria

   - Techniques (e.g., black-box and/or white-box-testing, equivalence
     classes and boundary values, fault injection for Functional Safety,
     penetration testing for Cybersecurity, back-to-back testing for model-based development, ICT)
   - Necessary verification environment & infrastructure
   - Necessary sequence or ordering

.. std_req:: 08-61 Resource allocation
   :id: std_req__aspice_40__iic-08-61
   :status: valid
   :version: 1

   Resource allocation may have the following characteristics:

   - Detailed / named resources are allocated to process tasks
   - Overall resource workload is considered (e.g., allocation of resources to multiple projects)

   .. note::

      Work breakdown structure may be used to refine the detailed resource allocation

   .. note::

      A resource allocation may be integrated in a/ be a part of the schedule, see 08-56

   .. note::

      Resources to be allocated are e.g., personnel/human resources for project roles and physical and material resources such as (special/limited) equipment, tool, licenses, test hardware, test vehicle, climate chambers etc.

.. std_req:: 08-62 Communication matrix
   :id: std_req__aspice_40__iic-08-62
   :status: valid
   :version: 1

   Communication matrix may have the following characteristics:

   - List of relevant process internal / external stakeholders
   - Roles and contact information of the parties involved
   - Definition of required interfaces between stakeholders
   - Communication subject
   - Communication means and frequency
   - Documentation needs of the communication (e.g., type of communication record)

.. std_req:: 08-63 Process Monitoring Method
   :id: std_req__aspice_40__iic-08-63
   :status: valid
   :version: 1

   Process Monitoring Method may have the following characteristics:

   - Measures including criteria for monitoring effectiveness, suitability, and adequacy of the standard process
   - Method for collecting and analyzing the monitoring measures

.. std_req:: 08-64 ML test approach
   :id: std_req__aspice_40__iic-08-64
   :status: valid
   :version: 1

   - The ML test approach describes
        - ML test scenarios with distribution of data characteristics (e.g., gender, weather conditions, street conditions within the ODD) defined by ML requirements
        - quantity of each ML test scenario inside the test data set
        - expected test result per test datum
        - pass/fail criteria for the ML testing
        - entry and exit criteria for the ML testing
        - the required ML testing infrastructure and environment configuration

.. std_req:: 08-65 ML training and validation approach
   :id: std_req__aspice_40__iic-08-65
   :status: valid
   :version: 1

   Process Monitoring Method may have the following characteristics:

   - ML Training and Validation approach describes at least:
         - entry and exit criteria of the ML training
         - approaches for hyperparameter tuning / optimization to be used in the training
         - approach for data set creation and modification
         - training environment, including required training hardware (e.g., GPU, or supercomputer to be used)
         - interface adapter for provision of input data and storage of output data
         - if required, actions to organize the data set and training environment
   - The ML training and validation approach may additionally include robustification methods like random dropout

.. std_req:: 08-66 Measures against deviations in quantitative process analysis
   :id: std_req__aspice_40__iic-08-66
   :status: valid
   :version: 1

   Measures against deviations in quantitative process analysis may have the following characteristics:

   - Definition of counter measures actions to address each assignable cause of special causes of variation,
     or common causes of variation
   - Effective implementation of these counter measures


.. needextend:: "c.this_doc()"
   :+tags: aspice40_iic08
