..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Security Manual Templates
=========================
.. gd_temp:: Platform Security Manual Template
   :id: gd_temp__platform_security_manual
   :status: valid
   :version: 1
   :complies: std_req__isosae21434__development_10421[version==1], std_req__isosae21434__development_10422[version==1]

   For the content see here: :need:`doc__platform_security_manual`

.. gd_temp:: Module Security Manual Template
   :id: gd_temp__module_security_manual
   :status: valid
   :version: 1
   :complies: std_req__isosae21434__development_10421[version==1], std_req__isosae21434__development_10422[version==1]

   For the content see here: `Module Security Manual Template <https://eclipse-score.github.io/module_template/main/docs/manuals/security_manual.html>`__
