..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Security Management Work Products
#################################
.. workproduct:: Platform Security Plan
   :id: wp__platform_security_plan
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_651[version==1],
              std_wp__isosae21434__maintenance_13331[version==1],
              std_wp__isosae21434__continual_8331[version==1],
              std_wp__isosae21434__continual_8332[version==1],
              std_wp__isosae21434__prj_management_653[version==1]

   Plan to manage and guide the execution of the security activities of a project including dates, milestones, tasks, deliverables, responsibilities (including the Security Manager appointment)  and resources.

   This Platform Security Plan also takes into account the eclipse organization's rules relevant for security development.

   Guidelines on how an change impact analysis shall be concluded on each item or element involved together with it's connected items or elements.

   For the template see here: :need:`doc__platform_security_manual`

   This is on following level:

   * Project/Platform (contains definitions how security planning is performed generally in the project)

.. workproduct:: Module Security Plan
   :id: wp__module_security_plan
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_651[version==1]

   Plan to manage and guide the execution of the security activities of a project including dates, milestones, tasks, deliverables, responsibilities (including the Security Manager appointment) and resources.

   Guidelines on how an impact analysis shall be concluded on each item or element involved together with it's connected items or elements.

   For the template see here: `Module Security Manual Template <https://eclipse-score.github.io/module_template/main/docs/manuals/security_manual.html>`__

   This is on following level:

   * Module (contains activities planning based on a Change Request)

.. workproduct:: Platform Security Package
   :id: wp__platform_security_package
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_652[version==1]

   Compiled security relevant work products. For platform OoC.

   Note that the Platform Security Package does not contain an argument that the platform is safe and secure.

.. workproduct:: Module Security Package
   :id: wp__module_security_package
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_652[version==1]

   Compiled security relevant work products. For Module OoC.

   Note that the Module Security Package does not contain an argument that the module is safe and secure.

.. workproduct:: Formal Document Review Reports
   :id: wp__fdr_reports_security
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_654[version==1]

   Review that a work product provides sufficient and convincing evidence of their contribution to the achievement of security considering the corresponding objectives and requirements of ISO SAE 21434.

   Will contain formal review report for Security Plan, Security Package and Security Analyses.

   For the different review checklist see here:
     - Review checklist for Security Plans: :need:`doc__platform_name_security_plan_fdr` and `Module Security Plan Formal Review Checklist <https://eclipse-score.github.io/module_template/main/docs/security_mgt/module_security_plan_fdr.html>`__
     - Review checklist for Security Packages: :need:`doc__platform_name_security_package_fdr` and `Module Security Package Formal Review Checklist <https://eclipse-score.github.io/module_template/main/docs/security_mgt/module_security_package_fdr.html>`__

.. workproduct:: Process Security Audit Report
   :id: wp__audit_report_security
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__org_management_555[version==1]

   Examination of an implemented process with regard to the process objectives and that those match the ISO SAE 21434.
   (Currently tailored out, needs discussion)

.. workproduct:: Platform Security Manual
   :id: wp__platform_security_manual
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_654[version==1]

   The Security Manual describes:

   * the assumed platform requirements (security related, including for post-development);
   * the security concept of the OoC (i.e. which attack paths are taken care of);
   * the assumptions of use (of the features);
   * a link to the user manual;
   * the reactions of the implemented functions under threatened operating conditions; and
   * a description of known vulnerabilities with corresponding workaround measures.

   This is on platform level. Only one manual for the entire platform.

   For template see here: :need:`doc__platform_security_manual`

.. workproduct:: Module Security Manual
   :id: wp__module_security_manual
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__prj_management_654[version==1]

   The Security Manual describes:

   * the assumed platform requirements (security related, including for post-development);
   * the security concept of the OoC (i.e. which attack paths are taken care of);
   * the assumptions of use (of the modules's components);
   * a link to the user manual;
   * the reactions of the implemented functions under threatened operating conditions; and
   * a description of known vulnerabilities with corresponding workaround measures.

   This is on module level. One manual per each module.

   For template see here: `Module Security Manual Template <https://eclipse-score.github.io/module_template/main/docs/manuals/security_manual.html>`__

.. workproduct:: Platform Software Bill of Material (SBOM)
   :id: wp__sw_platform_sbom
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__continual_8631[version==1]

   Platform Software Bill of Material
   - comprehensive inventory of software components to ensure security, integrity, and compliance.

.. workproduct:: Module Software Bill of Material (SBOM)
   :id: wp__sw_module_sbom
   :status: valid
   :version: 1
   :tags: doc_lifecycle_model_2
   :complies: std_wp__isosae21434__continual_8631[version==1]

   Module Software Bill of Material
   - comprehensive inventory of software components to ensure security, integrity, and compliance.
