..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Guideline
#########

.. gd_guidl:: Working model
   :id: gd_guidl__platform_mgmt_plan
   :status: valid
   :version: 1
   :complies: std_req__aspice_40__MAN-3-BP1[version==1],
              std_req__aspice_40__MAN-3-BP2[version==1],
              std_req__aspice_40__MAN-3-BP3[version==1],
              std_req__aspice_40__MAN-3-BP4[version==1],
              std_req__aspice_40__MAN-3-BP5[version==1],
              std_req__aspice_40__MAN-3-BP6[version==1],
              std_req__aspice_40__MAN-3-BP7[version==1],
              std_req__aspice_40__MAN-3-BP8[version==1],
              std_req__aspice_40__MAN-3-BP9[version==1],
              std_req__aspice_40__MAN-3-BP10[version==1],
              std_req__aspice_40__iic-15-06[version==1]

This document describes the general guidances for Platform Management based on the concept which is defined :need:`[[title]]<doc_concept__platform_process>`.

General Hints
=============

A template of the Platform Management Plan for <Project> is described in the :ref:`Platform Management Plan Template <platform_templates>`.

An iterative and incremental development model shall be used.

The project life cycle model shall consider three phases:
Concept, Development and Maintenance (compare: :ref:`general_concepts_lifecycle`)
Within each phase iterative working model shall be applied.

The traceability shall consider the  :ref:`general_concepts_traceability` based on the
:ref:`general_concepts_building_blocks`.

Templates
---------

The content of the Platform Management Plan shall consider the
:ref:`Platform Management Plan Template <platform_templates>`.

Activities for Platform Management Plan
=======================================

Create/Maintain Platform Management Plan
----------------------------------------

The platform management is created and maintained by the :need:`Project Lead <rl__project_lead>`.
As it is a container, this activity is valid for all addressed plan documents.

It may consider:

* Identifies activities to be performed
* Identifies the expected, and actual, start and completion date for required activities against progress/completion of activities
* Identifies dependencies between activities and critical path
* Has a mapping to scheduled resources and input data
* Identifies resource allocation, resource workload, and critical resources
* Information needed to perform
* Documents ownership for activities e.g., by domains
* Documents critical dependencies to other work packages
* Defines/Identifies work products to be generated
* Documents input and output work products
* Documents the critical dependencies between defined work products
* Integration of third party deliveries
* Applicable standards and legal requirements

Especially for the Project Management Plan, the following topics may considered:

The scope of the work is defined. The scope may include:

* Roadmap - Main features to be realized including
* Schedule - target delivery date and major milestones
* Release dates including major summary of deliverables
* Operational environment, infrastructure
* Reference Hardware, Project Samples

The stakeholders/stakeholder groups and organisation are defined. These may include:

* Involved parties
* Weight/importance of each stakeholder (group)
* Representative(s) for each stakeholder (group)
* Information needs of each stakeholder (group)
* Required competences, skills, knowledge

Communication and reporting pathes are described. These may include:

* E-mails
* Collaboration tools, like Slack, Teams, etc.
* Meetings and Meeting Notes
* Blog
* Webpages

Escalation pathes are described. These may include:

* Defined mechanisms to report and confirm escalation relevant issues
* Identifies stakeholders to be included in the escalation path
* Identifies levels of escalation

Training pathes are described. These may include:

* Tutorials
* Training materials
* Online Trainings, Video material


Monitor/Improve Platform Management Plan
----------------------------------------

:need:`Project Lead <rl__project_lead>` is responsible for the monitoring of the
work products and activities against the platform management plan. If deviations are detected,
the plan must be adjusted. Deviations may include estimates, resources, schedules, plans,
interfaces, etc. as defined in the scope of work.

The status of the project is regularly reported.


Tailoring
=========

.. gd_guidl:: Platform Management Plan Requirements Tailored
   :id: gd_guidl__platform_mgmt_plan_req_tailored
   :status: valid
   :version: 1
   :complies: std_req__aspice_40__MAN-5-BP1[version==1],
              std_req__aspice_40__MAN-5-BP2[version==1],
              std_req__aspice_40__MAN-5-BP3[version==1],
              std_req__aspice_40__MAN-5-BP4[version==1],
              std_req__aspice_40__MAN-5-BP5[version==1],
              std_req__aspice_40__MAN-5-BP6[version==1],
              std_req__aspice_40__MAN-5-BP7[version==1],
              std_req__aspice_40__iic-15-09[version==1],
              std_req__aspice_40__iic-15-51[version==1],
              std_req__aspice_40__iic-08-55[version==1]

   This part of the guideline links to all the requirements which are not fulfilled by the
   platform management plan process. Make sure these are tailored out in the corresponding sub-plans
   e.g. project management plan, etc. for your project (documented in the PMP).
   Reasoning given below must be confirmed there.

   The reasoning is:

   - Main deliveries are source code, which is not a product, thus product risk management and process risk is not applicable (for safety and security related risk separate processes as safety/security analysis exists).
