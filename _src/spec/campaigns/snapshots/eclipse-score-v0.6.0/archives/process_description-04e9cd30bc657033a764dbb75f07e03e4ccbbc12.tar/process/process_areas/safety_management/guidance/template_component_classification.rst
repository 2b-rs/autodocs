..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Component Classification Template
=================================

.. gd_temp:: Component Classification Template
   :id: gd_temp__component_classification
   :status: valid
   :version: 1
   :complies: std_req__isopas8926__441[version==1],
              std_req__isopas8926__4421[version==1],
              std_req__isopas8926__4422[version==1],
              std_req__isopas8926__4423[version==1],
              std_req__isopas8926__4424[version==1],
              std_req__isopas8926__4425[version==1],
              std_req__isopas8926__4426[version==1],
              std_req__isopas8926__4427[version==1],
              std_req__isopas8926__4428[version==1],
              std_req__isopas8926__4429[version==1],
              std_req__isopas8926__44210[version==1],
              std_req__iso26262__software_743[version==1],
              std_req__aspice_40__iic-12-03[version==1],
              std_req__aspice_40__iic-15-07[version==1]

   For the content see here: `Component Classification Template <https://eclipse-score.github.io/module_template/main/score/component_example/docs/component_classification.html>`__
