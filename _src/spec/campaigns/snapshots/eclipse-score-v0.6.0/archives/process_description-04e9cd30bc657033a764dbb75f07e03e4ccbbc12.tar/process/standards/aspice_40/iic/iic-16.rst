..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

16-xx
~~~~~

.. std_req:: 16-00 Repository
   :id: std_req__aspice_40__iic-16-00
   :status: valid
   :version: 1

   Repository may have the following characteristics:

   Charcteristics according to Wikipedia, as the PAM 4.0 is lacking it in the IIC.
   A software repository, or repo for short, is a storage location for software packages.
   Often a table of contents is also stored, along with metadata.
   A software repository is typically managed by source or version control, or repository managers.
   Package managers allow automatically installing and updating repositories, sometimes called "packages".

.. std_req:: 16-03 Configuration management system
   :id: std_req__aspice_40__iic-16-03
   :status: valid
   :version: 1

   Configuration management system may have the following characteristics:

   - Supports the configuration management for the scope of the configuration item list contents
   - Correct configuration of products
   - Can recreate any release or test configuration
   - Ability to report configuration status
   - Has to cover all relevant tools

.. std_req:: 16-06 Process repository
   :id: std_req__aspice_40__iic-16-06
   :status: valid
   :version: 1

   Process repository may have the following characteristics:

   - Contains process descriptions
   - Supports multiple presentations of process assets

.. std_req:: 16-50 Organizational structure
   :id: std_req__aspice_40__iic-16-50
   :status: valid
   :version: 1

   Organizational structure may have the following characteristics:

   - Disciplinary reporting line
   - Organizational units and sub-units, if applicable

.. std_req:: 16-52 ML data management system
   :id: std_req__aspice_40__iic-16-52
   :status: valid
   :version: 1

   - The ML data management system is part of the configuration management system (see 16-03) and
   - Supports data management activities like data collection, description, ingestion, exploration, profiling, labeling/annotation, selection, structuring and cleansing
   - Provides the data for different purposes, e.g., training, testing
   - Supports the relevant sources of ML data

.. needextend:: "c.this_doc()"
   :+tags: aspice40_iic16
